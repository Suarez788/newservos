# Starting point for an encounter. Stops encounter_level from continuing to tick up. Summons and handles encounter entity


scoreboard players set @s encounter_level 6

summon mannequin ~ ~50 ~ {Silent:1b,Invulnerable:1b,CustomNameVisible:1b,main_hand:"right",pose:"standing",hide_description:true,Tags:["encounter_entity"],CustomName:{"color":"white","text":"Zackattack4100"},active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:20,show_particles:0b,show_icon:0b,ambient:1b}],profile:{"name":"Zackattack4100","id":[I;-1844603805,-1056750311,-1862562732,-1993295109],"properties":[{"name":"textures","value":"ewogICJ0aW1lc3RhbXAiIDogMTc4MzI5MDQ3MjM1MSwKICAicHJvZmlsZUlkIiA6ICI5MjBkOTQ2M2MxMDM0NTE5OTBmYjhjNTQ4OTMwYmFmYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJaYWNrYXR0YWNrNDEwMCIsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9mMGNhZjU2YjgyN2UzNWJhNjlhMjcxMDgyYWM3ODY1MWYyZmQ2MGRkYzZmN2MxZmM1N2YyY2FlYWMzYWU3YWU5IgogICAgfQogIH0KfQ=="}]},main_hand:"right"}

spreadplayers ~ ~ 25 50 false @e[tag=encounter_entity]

tellraw @a[distance=..50] ["",{"text":"<"},{"text":"Zackattack4100","obfuscated":true},{"text":"> Leave this place"}]

execute as @e[tag=encounter_entity] at @s run playsound minecraft:ambient.cave master @a ~ ~1 ~ 4 0 1