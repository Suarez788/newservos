# Handles the end of the encounter for the encounter entity (as & at)

tp @s ~ ~-1000 ~
kill @s

scoreboard players set @a[scores={encounter_level=6}] encounter_level 0