# Handles the end of an encounter when a player approaches the entity
# Runs AS the encounter entity AT the encounter entity


particle minecraft:white_smoke ~ ~1 ~ 0.25 0.33 0.25 0.02 200
particle minecraft:sculk_soul ~ ~1 ~ 0 0 0 0 1

function limbo:events/encounter/end
