# Tomb of Oblivion: Initial start function


# Reset advancement to allow right-click detection again
advancement revoke @s only limbo:listeners/tomb_of_oblivion_used

# Cooldown gate
execute if score @s tomb_cooldown matches 1.. run function limbo:items/tomb/cooldown_gate
execute if score @s tomb_cooldown matches 1.. run return 0

# Valid target check
execute if entity @e[distance=1..5,limit=1,sort=nearest] run function limbo:items/tomb/target_check_passed
execute unless entity @e[distance=1..5] run function limbo:items/tomb/target_not_found