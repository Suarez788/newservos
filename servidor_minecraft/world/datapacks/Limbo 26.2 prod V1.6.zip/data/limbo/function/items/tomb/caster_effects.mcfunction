# Tomb of Oblivion: Cosmetic effects for caster/user


particle dust_color_transition{from_color:[0.77,0.42,1.0],scale:3,to_color:[0.0,0.0,0.0]} ~ ~ ~ 0.6 0.01 0.6 0 50 force @a
particle minecraft:white_ash ~ ~1 ~ 0.7 0.8 0.7 0 200 force @a

playsound minecraft:block.end_portal.spawn master @s ~ ~1 ~ 3 0
playsound minecraft:block.respawn_anchor.deplete master @s ~ ~1 ~ 3 0
playsound minecraft:block.beacon.power_select master @s ~ ~1 ~ 3 0