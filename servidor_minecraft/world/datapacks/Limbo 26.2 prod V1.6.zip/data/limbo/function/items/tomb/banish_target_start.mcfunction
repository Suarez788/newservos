# Tomb of Oblivion: Banished target initial teleport


# Effect
effect give @s minecraft:slow_falling 2 1 true
effect give @s minecraft:glowing 2 1 true
effect give @s minecraft:darkness 2 1 true
effect give @s minecraft:blindness 2 1 true

# To Limbo
execute unless dimension limbo:dimension run scoreboard players set @s banished_tp_cooldown 10
execute unless dimension limbo:dimension run tag @s add tomb_tp_surface
execute unless dimension limbo:dimension run execute in limbo:dimension run tp @s ~ ~400 ~ ~ ~

# To Overworld
execute if dimension limbo:dimension run scoreboard players set @s banished_tp_cooldown 10
execute if dimension limbo:dimension run tag @s add tomb_tp_surface
execute if dimension limbo:dimension run execute in minecraft:overworld run tp @s ~ ~400 ~ ~ ~