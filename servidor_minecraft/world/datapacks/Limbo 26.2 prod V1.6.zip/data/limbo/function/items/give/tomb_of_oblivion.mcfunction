# This file poles the Tomb of Oblivion loot table to give 1 to the user


loot give @s loot limbo:sorrowlands/structure/relic/tomb_of_oblivion