# Tomb of Oblivion: Item holder target effects


# Targeting effects
execute as @s at @e[distance=1.1..5,limit=1,sort=nearest] run particle enchant ~ ~1.5 ~ 0 0 0 0.50 1
execute as @s at @e[distance=1.1..5,limit=1,sort=nearest] run particle minecraft:electric_spark ~ ~1.5 ~ 0 0 0 1 1
execute as @s at @e[distance=1.1..5,limit=1,sort=nearest] run particle dust{color:[0.77,0.42,1.0],scale:1.5} ~ ~1 ~ 0.15 0.15 0.15 0 1
execute as @e[distance=1.1..5,limit=1,sort=nearest] run effect give @s minecraft:glowing 1 1 true
