# Tomb of Oblivion: Cosmetic effects on banished target


particle flash{color:[0.784,0.706,0.902,1.00]} ~ ~ ~ 0 0 0 0 0 force @a[distance=..250]
particle minecraft:sculk_soul ~ ~1.1 ~ 0.1 0.1 0.1 0.01 1 force @a[distance=..250]
particle minecraft:dragon_breath ~ ~1 ~ 0.5 0.5 0.5 0 5 force @a[distance=..250]
particle minecraft:portal ~ ~1 ~ 0 0 0 2 500 force @a[distance=..250]