# This file applies the effects to the Edge of Eternity arrow when fired


# Increase arrow damage (insta-kill level)
data modify entity @s damage set value 1000000.0d

# Removing crit (just for visuals)
data modify entity @s crit set value 0b

# Remove pierce
data modify entity @s PierceLevel set value 0b

# Particle(s)
particle flash{color:[0.784,0.706,0.902,1.00]} ~ ~ ~ 0 0 0 0 1 force @a[distance=..1000]

# Sound event(S)
playsound minecraft:item.spear.lunge_3 master @a[distance=..100] ~ ~ ~ 1 0
playsound minecraft:block.respawn_anchor.deplete master @a[distance=..100] ~ ~ ~ 1 2

# Tag arrow to track trail
tag @s add edge_of_eternity
