# Normal key: Ending effects


scoreboard players set @s normal_key_used 1
scoreboard players set @s master_key_used 0

spawnpoint @s ~ ~ ~

effect give @s minecraft:slow_falling 2 1 true
effect give @s minecraft:darkness 2 1 true
effect give @s minecraft:blindness 2 1 true

particle minecraft:reverse_portal ~ ~1 ~ 0 0 0 5 25 force @a[distance=..250]
particle dust{color:[0.77,0.42,1.0],scale:0.75} ~ ~1 ~ 0.3 0.5 0.3 0 10 force @a[distance=..250]

playsound minecraft:block.vault.insert_item_fail master @s ~ ~1 ~ 2 1.5
playsound minecraft:event.mob_effect.bad_omen master @s ~ ~1 ~ 3 0
playsound minecraft:block.trial_spawner.spawn_item_begin master @s ~ ~1 ~ 3 0