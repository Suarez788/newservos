# This file poles the Master Limbo Key loot table to give 1 to the user


loot give @s loot limbo:peaks/structure/relic/master_key