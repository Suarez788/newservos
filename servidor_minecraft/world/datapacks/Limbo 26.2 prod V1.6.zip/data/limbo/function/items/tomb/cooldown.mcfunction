# Tomb of Oblivion: Cooldown start 


scoreboard players set @s tomb_cooldown 12000

tellraw @s ["",{"text":"LIMBO","bold":true,"obfuscated":true,"color":"#CC99FF"},{"text":": ","color":"#CC99FF"},{"text":"You must rest","bold":true,"italic":true,"color":"#CC99FF"},{"text":"...","color":"#CC99FF"}]

tag @s add tomb_cooldown