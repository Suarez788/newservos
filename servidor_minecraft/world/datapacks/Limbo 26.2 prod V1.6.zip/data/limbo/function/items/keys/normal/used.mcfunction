# Normal key: Initial function


# Initial cosmetic effects
function limbo/items/keys/normal/start_effect

# Removing 1 normal key from user 
clear @s minecraft:poisonous_potato[minecraft:custom_data={limbo_normal_key:1b,limbo_item:1b}] 1


# TO LIMBO
execute unless dimension limbo:dimension run scoreboard players set @s normal_tp_cooldown 10
execute unless dimension limbo:dimension run tag @s add normal_tp_surface
execute unless dimension limbo:dimension run execute in limbo:dimension run tp @s ~ ~400 ~ ~ ~


# TO OVERWORLD
execute if dimension limbo:dimension run scoreboard players set @s normal_tp_cooldown 10
execute if dimension limbo:dimension run tag @s add normal_tp_surface
execute if dimension limbo:dimension run execute in minecraft:overworld run tp @s ~ ~400 ~ ~ ~


# Reset advancement
advancement revoke @s only limbo:listeners/keys/normal_key_used