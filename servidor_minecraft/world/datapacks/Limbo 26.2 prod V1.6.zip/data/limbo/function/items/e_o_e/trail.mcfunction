# This file adds a particle trail to the Edge of Eternity arrow

particle minecraft:dragon_breath ~ ~ ~ 0 0 0 0.01 2 force @a[distance=1..1000]