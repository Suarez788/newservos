# Master key: Starting cosmetic effects


particle dust{color:[0.77,0.42,1.0],scale:0.75} ~ ~1 ~ 0.3 0.5 0.3 0 10 force @a

playsound minecraft:block.portal.trigger master @s ~ ~1 ~ 3 2
playsound minecraft:entity.zombie_villager.converted master @s ~ ~1 ~ 3 2
playsound minecraft:entity.illusioner.mirror_move master @s ~ ~1 ~ 3 0.75