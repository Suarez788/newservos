# This file poles the basic limbo key loot table to give 1 to the user


loot give @s loot limbo:general/limbo_key