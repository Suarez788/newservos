# Tomb of Oblivion: Target not found fallback


tellraw @s ["",{"text":"LIMBO","bold":true,"obfuscated":true,"color":"#CC99FF"},{"text":": ","color":"#CC99FF"},{"text":"No target in range","underlined":false,"color":"#CC99FF"},{"text":"...","color":"#CC99FF"}]

playsound minecraft:item.book.page_turn master @s ~ ~1 ~ 1 0.9