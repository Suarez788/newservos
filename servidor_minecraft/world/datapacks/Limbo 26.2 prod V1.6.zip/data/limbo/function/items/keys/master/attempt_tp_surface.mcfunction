# Master key: Secondary teleport 


# Stop if chunk not loaded
execute unless loaded ~ ~ ~ run return 0

# Decrement cooldown
scoreboard players remove @s master_tp_cooldown 1

# Try surface teleport
execute positioned over motion_blocking_no_leaves run tp @s ~ ~ ~ ~ ~

# Second cosmetic effects
execute positioned over motion_blocking_no_leaves run function limbo:items/keys/master/end_effect

# Clean up
tag @s remove master_tp_surface
scoreboard players reset @s master_tp_cooldown