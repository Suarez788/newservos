# Tomb of Oblivion: Cosmetic effects for banished target


playsound minecraft:entity.lightning_bolt.thunder master @a[distance=..100000] ~ ~1 ~ 100000 0
playsound minecraft:ambient.cave master @s ~ ~1 ~ 5 1

particle minecraft:reverse_portal ~ ~1 ~ 0 0 0 1 500 force @a