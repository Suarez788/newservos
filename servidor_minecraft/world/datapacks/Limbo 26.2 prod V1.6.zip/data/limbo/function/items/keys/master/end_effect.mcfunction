# Master key: Ending effects


scoreboard players set @s master_key_used 1
execute if entity @s[scores={normal_key_used=1}] in minecraft:overworld run spawnpoint @s ~ ~ ~ ~ ~
scoreboard players set @s normal_key_used 0

effect give @s minecraft:slow_falling 2 1 true

particle dust{color:[0.77,0.42,1.0],scale:0.75} ~ ~1 ~ 0.3 0.5 0.3 0 10 force @a[distance=..250]

playsound minecraft:entity.illusioner.mirror_move master @s ~ ~1 ~ 3 0.75
playsound minecraft:entity.zombie_villager.converted master @s ~ ~1 ~ 3 2