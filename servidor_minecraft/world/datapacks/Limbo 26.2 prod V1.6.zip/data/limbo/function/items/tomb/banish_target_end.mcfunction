# Tomb of Oblivion: Banished target secondary teleport


# Stop if chunk not loaded
execute unless loaded ~ ~ ~ run return 0

# Decrement cooldown
scoreboard players remove @s banished_tp_cooldown 1

# Try surface teleport
execute positioned over motion_blocking_no_leaves run tp @s ~ ~ ~ ~ ~

# Cosmetic effects
execute positioned over motion_blocking_no_leaves run function limbo:items/tomb/banished_effects

# Clean up
tag @s remove tomb_tp_surface
tag @s remove banished
scoreboard players reset @s banished_tp_cooldown