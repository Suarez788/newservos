# Tomb of Oblivion: Cooldown complete


tellraw @s ["",{"text":"LIMBO","bold":true,"obfuscated":true,"color":"#CC99FF"},{"text":": ","color":"#CC99FF"},{"text":"You are ready","bold":true,"color":"#CC99FF"},{"text":"...","color":"#CC99FF"}]

particle minecraft:sculk_soul ~ ~1 ~ 0.6 0.2 0.6 0.01 5

playsound minecraft:block.enchantment_table.use master @s ~ ~1 ~ 1 0

tag @s remove tomb_used
tag @s remove tomb_cooldown