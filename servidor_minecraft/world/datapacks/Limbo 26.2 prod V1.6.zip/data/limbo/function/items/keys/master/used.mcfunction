# Master key: Intitial function


# Initial cosmetic effects
function limbo/items/keys/master/start_effect

# TO LIMBO
execute unless dimension limbo:dimension run scoreboard players set @s master_tp_cooldown 10
execute unless dimension limbo:dimension run tag @s add master_tp_surface
execute unless dimension limbo:dimension run execute in limbo:dimension run tp @s ~ 400 ~ ~ ~


# TO OVERWORLD
execute if dimension limbo:dimension run scoreboard players set @s master_tp_cooldown 10
execute if dimension limbo:dimension run tag @s add master_tp_surface
execute if dimension limbo:dimension run execute in minecraft:overworld run tp @s ~ 400 ~ ~ ~


# Reset advancement
advancement revoke @s only limbo:listeners/keys/master_key_used