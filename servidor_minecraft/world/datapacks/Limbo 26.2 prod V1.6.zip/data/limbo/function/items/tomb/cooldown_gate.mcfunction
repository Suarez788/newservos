# Tomb of Oblivion: Cooldown not over fallback


tellraw @s {"text":"Tomb of Oblivion must recharge...","color":"red"}

playsound minecraft:item.book.page_turn master @s ~ ~1 ~ 1 0.9