# Tomb of Oblivion: Target found, in range, and cooldown completed


# Tag nearest entity (not self) as banished
execute as @e[distance=1..5,limit=1,sort=nearest] run tag @s add banished

# Caster cosmetic effects
function limbo:items/tomb/caster_effects

# Victim cosmetic effects
execute as @e[tag=banished] at @s run function limbo:items/tomb/target_effects

# Banish target to Limbo
execute as @e[tag=banished] at @s run function limbo:items/tomb/banish_target_start

# Start cooldown for user
function limbo:items/tomb/cooldown