# This function is to give players a score so the targeter function works immediately

# Set players initial cooldown to 0
scoreboard players set @s tomb_cooldown 0