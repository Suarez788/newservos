# This file poles the Edge of Eternity loot table to give 1 to the user


loot give @s loot limbo:plains/structure/relic/edge_of_eternity