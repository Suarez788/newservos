# Function file for the install toast


playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~1 ~ 100 0 1

tellraw @s ["",{"text":"Thank you for installing ","color":"yellow"},{"text":"Limbo","bold":true,"color":"#C8B4E6"},{"text":"\n\n"},{"text":"-","bold":true,"color":"gray"},{"text":" Warning:","bold":true,"color":"red"},{"text":" Uninstalling ","color":"yellow"},{"text":"Limbo","bold":true,"color":"#C8B4E6"},{"text":" is not possible without a ","color":"yellow"},{"text":"complete","underlined":true,"color":"yellow"},{"text":" world reset.","color":"yellow"},{"text":"\n\n"},{"text":"-","bold":true,"color":"gray"},{"text":" Created by:","color":"yellow"},{"text":" Zackattack4100","color":"#FF4B00"}]
