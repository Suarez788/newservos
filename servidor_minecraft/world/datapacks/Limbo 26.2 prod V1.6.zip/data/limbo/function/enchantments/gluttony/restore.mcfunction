# This file is for giving the user of the Gluttony enchantment some hunger back 

effect give @s minecraft:saturation 2 0 true