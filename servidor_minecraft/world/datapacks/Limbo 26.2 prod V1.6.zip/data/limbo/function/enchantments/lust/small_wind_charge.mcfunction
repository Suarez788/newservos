# Summons a small wind charge

execute positioned ~ ~1.6 ~ run summon wind_charge ^0.5 ^ ^1 {Tags:["limbo_small_wind_charge"]}
