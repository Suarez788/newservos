# Runs when the player lands on the ground again after dashing

scoreboard players set @s dash 0