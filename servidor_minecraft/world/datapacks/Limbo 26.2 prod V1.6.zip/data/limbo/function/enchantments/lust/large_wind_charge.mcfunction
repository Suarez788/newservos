# Summons a large wind charge

execute positioned ~ ~1.6 ~ run summon breeze_wind_charge ^-0.5 ^ ^1 {Tags:["limbo_large_wind_charge"]}
