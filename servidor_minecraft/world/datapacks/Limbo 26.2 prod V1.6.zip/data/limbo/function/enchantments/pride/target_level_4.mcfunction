# This file is the effects for being hit at level 4 Pride


particle minecraft:explosion ~ ~1 ~ 0 0 0 1 1 force @a[distance=..500]
particle minecraft:electric_spark ~ ~1 ~ 0 0 0 2 10 force @a[distance=..500]
particle minecraft:firework ~ ~1 ~ 0 0 0 1 100 force @a[distance=..500]

playsound minecraft:item.mace.smash_ground_heavy player @a[distance=..100] ~ ~1 ~ 1 0.75