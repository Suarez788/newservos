# This file runs when a Wrath enchantment crit happens


particle minecraft:explosion ~ ~1 ~ 0 0 0 0 1 force
particle dust_color_transition{from_color:[0.784,0.706,0.902],to_color:[0.000,0.000,0.000],scale:2} ~ ~1.25 ~ 0.33 0.33 0.33 0 10 normal

playsound minecraft:entity.wither.break_block master @a[distance=..15] ~ ~ ~ 0.5 0 0.25