# Macro function to restore players rotation

$rotate @s ~ $(pitch)

data remove storage limbo:double_jump_temp rotation