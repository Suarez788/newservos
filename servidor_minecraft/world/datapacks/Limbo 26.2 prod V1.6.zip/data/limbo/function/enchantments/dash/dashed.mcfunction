# Plays when a player preforms a double jump


# Gate
scoreboard players set @s dash 1


# Effects
playsound minecraft:entity.phantom.flap master @s ~ ~ ~ 1 2 1

particle minecraft:cloud ~ ~-0.1 ~ 0.2 0 0.2 0.025 15