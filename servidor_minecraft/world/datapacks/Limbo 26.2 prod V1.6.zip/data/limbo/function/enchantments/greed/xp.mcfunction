# This file summons an xp orb

summon experience_orb ^ ^ ^0.25 {Count:1,Value:5,Motion:[0.0,1.0,0.0],Tags:["limbo_xp_orb"]}