# This file is the effects for being hit at level 1 Pride


particle minecraft:electric_spark ~ ~1 ~ 0 0 0 2 10
particle minecraft:flame ~ ~1 ~ 0 0 0 0.25 25

playsound minecraft:entity.player.attack.knockback player @a[distance=..25] ~ ~1 ~ 1 0.6