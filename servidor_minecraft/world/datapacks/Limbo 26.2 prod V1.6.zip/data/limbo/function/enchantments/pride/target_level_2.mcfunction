# This file is the effects for being hit at level 2 Pride


particle minecraft:electric_spark ~ ~1 ~ 0 0 0 2 10
particle minecraft:soul_fire_flame ~ ~1 ~ 0 0 0 0.25 25

playsound minecraft:entity.dragon_fireball.explode player @a[distance=..25] ~ ~1 ~ 1 2
