# Effects file for the Updraft enchantment


# Particles
particle minecraft:cloud ~ ~ ~ 0.1 0.1 0.1 0.05 2

# Sounds
playsound minecraft:entity.horse.breathe master @s ~ ~ ~ 0.5 0.5 0
