# Effects file for the Afterburner enchantment


# Particles
particle minecraft:campfire_signal_smoke ^ ^ ^-0.25 0 0 0 0.001 2 force @a[distance=..100]
particle minecraft:campfire_cosy_smoke ^ ^ ^-0.25 0 0 0 0.01 2 force @a[distance=..100]

# Sounds
playsound minecraft:entity.horse.breathe master @s ~ ~ ~ 1 0 0
