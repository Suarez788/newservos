# This file is the effects for being hit at level 3 Pride


particle minecraft:electric_spark ~ ~1 ~ 0 0 0 2 10
particle minecraft:copper_fire_flame ~ ~1 ~ 0 0 0 0.25 30

playsound minecraft:entity.iron_golem.damage player @a[distance=..25] ~ ~1 ~ 1 0.5
