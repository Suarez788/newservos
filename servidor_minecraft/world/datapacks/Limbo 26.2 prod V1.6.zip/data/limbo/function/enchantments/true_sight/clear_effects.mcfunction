# This file clears negative effects from the user


particle minecraft:white_smoke ~ ~1 ~ 0.25 0.5 0.25 0 10

effect clear @s minecraft:blindness
effect clear @s minecraft:darkness
effect clear @s minecraft:nausea
