# Rotate player for double jump

data modify storage limbo:double_jump_temp rotation.pitch set from entity @s Rotation[1]

rotate @s ~ 0