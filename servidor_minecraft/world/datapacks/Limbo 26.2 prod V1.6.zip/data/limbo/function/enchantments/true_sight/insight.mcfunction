# This file sets the boss bar


execute at @e[type=!#limbo:non_entities,distance=1..10,sort=nearest,limit=1] run particle minecraft:electric_spark ~ ~1 ~ 0.33 0.5 0.33 0.1 2

# Boss bar
bossbar set limbo:true_sight players @s
execute store result bossbar limbo:true_sight max run attribute @e[type=!#limbo:non_entities,distance=1..10,limit=1,sort=nearest] minecraft:max_health get 1
execute store result bossbar limbo:true_sight value run data get entity @e[type=!#limbo:non_entities,distance=1..10,sort=nearest,limit=1] Health 1

execute if entity @e[type=!#limbo:non_entities,distance=10..] run bossbar set limbo:true_sight visible false
execute if entity @e[type=!#limbo:non_entities,distance=1..10] run bossbar set limbo:true_sight visible true
