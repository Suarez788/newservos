# This file makes the target glow

effect give @e[type=!#limbo:non_entities,distance=1..10,sort=nearest,limit=1] minecraft:glowing 1 1 true