# File for Balista enchantment: post arrow effects including increasing arrow velocity


# Remove arrow gravity
data modify entity @s NoGravity set value 1b

# the 2000 and .001 are for scaling the value. the product of these is by what factor the arrow's motion will be scaled so in this case 2000*.001 = 2
execute store result entity @s Motion[0] float .001 run data get entity @s Motion[0] 3000
execute store result entity @s Motion[1] float .001 run data get entity @s Motion[1] 3000
execute store result entity @s Motion[2] float .001 run data get entity @s Motion[2] 3000
