# Effects file for the Landfall enchantment


# Particles
particle minecraft:campfire_signal_smoke ^ ^ ^-0.15 1 1 1 0.005 5 force @a[distance=..250]
particle minecraft:flame ^ ^ ^-0.15 1 1 1 0.05 5 force @a[distance=..250]
particle minecraft:large_smoke ^ ^ ^-0.15 1 1 1 0.05 5 force @a[distance=..250]

# Sounds
playsound minecraft:entity.horse.breathe master @s ~ ~ ~ 3 0 0
