# File for Ranger enchantment: post arrow effects including increasing arrow velocity


data modify entity @s crit set value 0b

# Final value is motion scaled
execute store result entity @s Motion[0] float .001 run data get entity @s Motion[0] 2000
execute store result entity @s Motion[1] float .001 run data get entity @s Motion[1] 2000
execute store result entity @s Motion[2] float .001 run data get entity @s Motion[2] 2000
