# Runs when the player lands on the ground again after dashing

scoreboard players set @s double_jump 0