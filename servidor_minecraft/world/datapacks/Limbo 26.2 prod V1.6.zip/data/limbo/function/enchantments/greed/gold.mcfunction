# This file summons gold


particle dust{color:[1.000,0.843,0.000],scale:1} ~ ~1 ~ 0.5 0.5 0.5 0 10 force @s

execute positioned ~ ~0.75 ~ run summon item ^ ^ ^1 {Motion:[0.0,1.0,0.0],Item:{id:"minecraft:raw_gold",count:1}}
