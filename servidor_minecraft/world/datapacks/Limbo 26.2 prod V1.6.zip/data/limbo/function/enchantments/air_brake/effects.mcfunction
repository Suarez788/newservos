# Effects file for the Air Brake enchantment


# Particles
particle minecraft:white_smoke ~ ~ ~ 0.1 0.1 0.1 0.025 1
