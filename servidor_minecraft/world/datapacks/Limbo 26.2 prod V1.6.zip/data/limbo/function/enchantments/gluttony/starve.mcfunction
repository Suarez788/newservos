# This file is for giving the victim of the Gluttony enchantment the hunger effect

effect give @s minecraft:hunger 2 0 true