# This file plays when an entity it hit with Storm Dancer

summon lightning_bolt ~1.1 ~ ~ {Tags:["limbo_lightning_bolt"]}

particle minecraft:white_smoke ~ ~1 ~ 0 0 0 0.5 5