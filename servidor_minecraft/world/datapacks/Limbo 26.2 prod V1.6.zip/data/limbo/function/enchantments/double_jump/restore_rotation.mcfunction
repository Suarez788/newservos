# Restore players rotation

function limbo:enchantments/double_jump/restore_rotation_macro with storage limbo:double_jump_temp rotation