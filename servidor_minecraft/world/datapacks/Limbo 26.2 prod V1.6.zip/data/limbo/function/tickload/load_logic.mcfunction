# The server will load this file when a player joins the game or when using the reload command


# Universal scoreboards
scoreboard objectives add normal_jump minecraft.custom:minecraft.jump {"text":"normal_jump","color":"#C8B4E6"}
scoreboard objectives add normal_key_used dummy {"text":"normal_key_used","color":"#C8B4E6"}
scoreboard objectives add master_key_used dummy {"text":"master_key_used","color":"#C8B4E6"}
scoreboard objectives add random_ff dummy {"text":"random_ff","color":"#C8B4E6"}


# Teleport scorboards
scoreboard objectives add master_tp_cooldown dummy {"text":"master_tp_cooldown","color":"#C8B4E6"}
scoreboard objectives add normal_tp_cooldown dummy {"text":"normal_tp_cooldown","color":"#C8B4E6"}
scoreboard objectives add banished_tp_cooldown dummy {"text":"banished_tp_cooldown","color":"#C8B4E6"}


# Tomb of Oblivion
scoreboard objectives add tomb_cooldown dummy {"text":"tomb_cooldown","color":"#C8B4E6"}


# Dash enchantment
scoreboard objectives add dash dummy {"text":"dash","color":"#C8B4E6"}


# Double Jump enchantment
scoreboard objectives add double_jump dummy {"text":"double_jump","color":"#C8B4E6"}


# Bossbar for True Sight enchantment
bossbar add limbo:true_sight {"text":"Health","bold":true,"color":"#C8B4E6"}
bossbar set limbo:true_sight color purple
bossbar set limbo:true_sight style progress


# Encounter scoreboards
scoreboard objectives add encounter_level dummy {"text":"encounter_level","color":"#C8B4E6"}
scoreboard objectives add encounter_duration dummy {"text":"encounter_duration","color":"#C8B4E6"}
