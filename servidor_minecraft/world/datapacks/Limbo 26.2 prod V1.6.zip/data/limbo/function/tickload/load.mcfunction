# This file ensures that the load file always runs



# Function file (below)
function limbo:tickload/load_logic