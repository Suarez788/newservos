# The server will run all commands in this file every tick (20 ticks per second)



# Arrow processor
function limbo:general/arrows/checker


# Dimensional transport listeners 
# Master key surface teleport listener
execute as @a[tag=master_tp_surface,scores={master_tp_cooldown=1..}] at @s run function limbo:items/keys/master/attempt_tp_surface

# Normal key surface teleport listener
execute as @a[tag=normal_tp_surface,scores={normal_tp_cooldown=1..}] at @s run function limbo:items/keys/normal/attempt_tp_surface

# Tomb of Oblivion banished target teleport listener
execute as @e[tag=tomb_tp_surface,scores={banished_tp_cooldown=1..}] at @s run function limbo:items/tomb/banish_target_end


# Tomb of Oblivion cooldown
execute as @a[scores={tomb_cooldown=1..}] run scoreboard players remove @s tomb_cooldown 1
execute as @a[scores={tomb_cooldown=1}] at @s run function limbo:items/tomb/cooldown_done
execute as @a[scores={tomb_cooldown=..0}] at @s if items entity @s weapon.mainhand minecraft:enchanted_book[minecraft:custom_data~{tomb_of_oblivion:1b}] run function limbo:items/tomb/targeter


# Jump predicate checker (for Dash and Double Jump enchantments)
execute as @a[scores={normal_jump=1..}] if predicate limbo:jump_check run scoreboard players set @s normal_jump 0


# Lust enchantment wind charge particles
execute as @e[tag=limbo_small_wind_charge] at @s run particle minecraft:white_smoke ~ ~ ~ 0 0 0 0 1
execute as @e[tag=limbo_large_wind_charge] at @s run particle minecraft:smoke ~ ~ ~ 0 0 0 0 1


# Edge of Eternity trail and cleanup
execute as @e[tag=edge_of_eternity] at @s run function limbo:items/e_o_e/trail
kill @e[type=minecraft:arrow,nbt={inGround:1b},tag=edge_of_eternity]


# True Sight enchantment bossbar safeguard (clear boss bar if not wearing enchanted helmet)
execute as @a unless items entity @s armor.* *[minecraft:enchantments~[{enchantment:"limbo:true_sight"}]] run bossbar set limbo:true_sight visible false


##########
# EVENTS
##########

# Encounter
# Tick up the encounter level
execute as @a[scores={encounter_level=..4}] at @s if dimension limbo:dimension if predicate limbo:encounter_tick_chance run scoreboard players add @s encounter_level 1

# Begin encounter
execute as @a[scores={encounter_level=5}] at @s run function limbo:events/encounter/start

# Ensure encounter entity is looking at target
execute as @e[tag=encounter_entity] at @s run tp @s ~ ~ ~ facing entity @a[limit=1,sort=nearest]

# End encounter early via interaction
execute as @e[tag=encounter_entity] at @s if entity @a[distance=..15,limit=1,sort=nearest] run function limbo:events/encounter/interact

# End encounter
scoreboard players add @e[tag=encounter_entity] encounter_duration 1
execute as @e[tag=encounter_entity,scores={encounter_duration=200..}] at @s run function limbo:events/encounter/end
