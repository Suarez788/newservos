# This file ensures that the tick file always runs



# Function file (below)
function limbo:tickload/tick_logic