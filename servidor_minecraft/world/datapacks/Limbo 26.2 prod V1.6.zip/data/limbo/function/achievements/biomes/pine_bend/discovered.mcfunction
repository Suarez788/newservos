# Function file for when a player enters a Pine Bend biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Where the pines whisper","italic":true,"color":"gray"}

title @s title {"text":"Pine Bend","color":"#190064"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Pine Bend","color":"#190064"}]
