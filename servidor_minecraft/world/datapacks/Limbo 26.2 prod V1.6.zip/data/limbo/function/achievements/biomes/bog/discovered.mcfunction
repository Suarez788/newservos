# Function file for when a player enters a Bog biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Still water, still souls","italic":true,"color":"gray"}

title @s title {"text":"Bog","color":"#0f3200"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Bog","color":"#0f3200"}]
