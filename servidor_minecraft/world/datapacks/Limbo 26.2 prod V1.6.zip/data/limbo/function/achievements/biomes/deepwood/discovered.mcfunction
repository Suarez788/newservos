# Function file for when a player enters a Deepwood biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The root of despair","italic":true,"color":"gray"}

title @s title {"text":"Deepwood","color":"#003c28"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Deepwood","color":"#003c28"}]
