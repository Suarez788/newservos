# Function file for when a player enters a Plains biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Home of the forgotten","italic":true,"color":"gray"}

title @s title {"text":"Plains","color":"#c8b4e6"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Plains","color":"#c8b4e6"}]
