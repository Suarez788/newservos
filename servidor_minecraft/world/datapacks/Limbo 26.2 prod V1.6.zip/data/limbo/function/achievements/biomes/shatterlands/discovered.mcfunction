# Function file for when a player enters a Shatterlands biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times

title @s title {"text":"Shatterlands","color":"#191919"}

title @s subtitle {"text":"The great divide","italic":true,"color":"gray"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Shatterlands","color":"#191919"}] 