# Function file for when a player enters an Ocean biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The deep remembers everything","italic":true,"color":"gray"}

title @s title {"text":"Ocean","color":"#0000ff"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Ocean","color":"#0000ff"}]
