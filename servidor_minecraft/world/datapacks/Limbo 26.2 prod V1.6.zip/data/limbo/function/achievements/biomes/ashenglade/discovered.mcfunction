# Function file for when a player enters an Ashenglade biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The fire never left","italic":true,"color":"gray"}

title @s title {"text":"Ashenglade","color":"#E1E1E1"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Ashenglade","color":"#e1e1e1"}]
