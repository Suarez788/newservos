# This file is for the rewards for finding all the biomes of Limbo


execute as @s at @s run particle minecraft:firework ~ ~1 ~ 0 0 0 2 1000