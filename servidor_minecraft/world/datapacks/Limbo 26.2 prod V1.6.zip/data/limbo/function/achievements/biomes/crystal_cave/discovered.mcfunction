# Function file for when a player enters a Crystal Cave biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"A tomb of violet glass","italic":true,"color":"gray"}

title @s title {"text":"Crystal Cave","color":"#4b004b"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Crystal Cave","color":"#4b004b"}]
