# Function file for when a player enters a Shriekwood biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The trees still scream","italic":true,"color":"gray"}

title @s title {"text":"Shriekwood","color":"#96e196"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Shriekwood","color":"#96e196"}]
