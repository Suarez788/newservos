# Function file for when a player enters a Shattered Peaks biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The final horizon","italic":true,"color":"gray"}

title @s title {"text":"Shattered Peaks","color":"#646464"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Shattered Peaks","color":"#646464"}]
