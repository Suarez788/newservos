# Function file for when a player enters a Crossroads biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"All roads have an end","italic":true,"color":"gray"}

title @s title {"text":"The Crossroads","color":"#e14b00"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Crossroads","color":"#e14b00"}]
