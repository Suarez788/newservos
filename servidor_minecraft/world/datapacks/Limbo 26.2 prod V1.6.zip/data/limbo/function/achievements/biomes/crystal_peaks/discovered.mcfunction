# Function file for when a player enters a Crystal Peaks biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Spire of the absent stars","italic":true,"color":"gray"}

title @s title {"text":"Crystal Peaks","color":"#af00af"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Crystal Peaks","color":"#af00af"}]
