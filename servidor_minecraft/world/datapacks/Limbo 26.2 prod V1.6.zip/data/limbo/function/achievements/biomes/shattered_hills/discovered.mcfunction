# Function file for when a player enters a Shattered Hills biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Fractured by time","italic":true,"color":"gray"}

title @s title {"text":"Shattered Hills","color":"#323232"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Shattered Hills","color":"#323232"}]
