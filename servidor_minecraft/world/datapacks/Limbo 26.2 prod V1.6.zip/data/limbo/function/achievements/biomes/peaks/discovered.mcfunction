# Function file for when a player enters a Peaks biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The summit of broken dreams","italic":true,"color":"gray"}

title @s title {"text":"Peaks","color":"#ff0000"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Peaks","color":"#ff0000"}]
