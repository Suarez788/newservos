# Function file for when a player enters Limbo for the first time



