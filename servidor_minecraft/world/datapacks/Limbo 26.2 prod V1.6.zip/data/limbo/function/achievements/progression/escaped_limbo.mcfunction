# Function file for when a player escapes Limbo for the first time


particle minecraft:dragon_breath ~ ~1 ~ 0 0 0 1 1000 force @s
