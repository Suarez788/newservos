# This file is for setting the time on the title command for the 'Biome Announcment' system


# | Duration | Fade in duration | Fade out duration |
title @s times 20 20 50