# Function file for when a player enters a Sunken Hollow biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Where water sleeps","italic":true,"color":"gray"}

title @s title {"text":"Sunken Hollow","color":"#32c8c8"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Sunken Hollow","color":"#32c8c8"}]
