# Function file for when a player enters a Depths biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Where all light is lost","italic":true,"color":"gray"}

title @s title {"text":"Depths","color":"#0f0019"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Depths","color":"#0f0019"}]
