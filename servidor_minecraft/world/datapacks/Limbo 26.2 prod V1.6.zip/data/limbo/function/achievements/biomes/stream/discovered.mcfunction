# Function file for when a player enters a Stream biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The water knows the way","italic":true,"color":"gray"}

title @s title {"text":"Stream","color":"#73a0aa"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Stream","color":"#73a0aa"}]
