# Function file for when a player enters a Wraithwood biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The lost still wander","italic":true,"color":"gray"}

title @s title {"text":"Wraithwood","color":"#643296"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Wraithwood","color":"#643296"}]
