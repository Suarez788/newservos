# Function file for when a player enters a Highlands biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Closer to nowhere","italic":true,"color":"gray"}

title @s title {"text":"Highlands","color":"#c8c8c8"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Highlands","color":"#c8c8c8"}]
