# Function file for when a player enters a Sorrowlands biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"The land of rot","italic":true,"color":"gray"}

title @s title {"text":"Sorrowlands","color":"#50462d"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Sorrowlands","color":"#50462d"}]
