# Function file for when a player enters a Jagged Sea biome in Limbo for the first time


execute as @s at @s run function limbo:sounds/biome_discovered

function limbo:achievements/title_times


title @s subtitle {"text":"Even waves can sink","italic":true,"color":"gray"}

title @s title {"text":"Jagged Sea","color":"#4141a5"}

tellraw @s ["",{"text":"Achievement unlocked: ","color":"yellow"},{"text":"The Jagged Sea","color":"#4141a5"}]
