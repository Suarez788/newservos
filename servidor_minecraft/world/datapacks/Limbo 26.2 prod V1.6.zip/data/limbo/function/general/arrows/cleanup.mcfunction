# This file removes arrows after they hit the ground

kill @s