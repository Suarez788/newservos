# This file removes the crit modifier from arrows fired

data modify entity @s crit set value 0b