# This file processes all arrows fired in order to test for specific arrows fired

tag @s add processed


# Edge of Eternity check
execute if items entity @s contents *[minecraft:custom_data~{limbo_edge_of_eternity:1b,limbo_item:1b}] at @s run function limbo:items/e_o_e/launch
