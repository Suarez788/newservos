# This file checks all arrows fired to process them accordingly
# Tick uplinked

execute as @e[type=#arrows,tag=!processed] run function limbo:general/arrows/processor
