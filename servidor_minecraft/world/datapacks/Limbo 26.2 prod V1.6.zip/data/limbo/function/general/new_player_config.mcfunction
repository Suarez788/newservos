# This file is ran when a player gets the advancement "inital_join" which is given to them upon joining the world for the first time

scoreboard players set @s encounter_level 0