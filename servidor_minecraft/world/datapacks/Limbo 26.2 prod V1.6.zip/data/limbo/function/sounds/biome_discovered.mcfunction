# File for the sounds event that plays when a player enters a Limbo biome for the first time


playsound minecraft:entity.zombie_villager.converted master @s ~ ~1 ~ 100 0 1
