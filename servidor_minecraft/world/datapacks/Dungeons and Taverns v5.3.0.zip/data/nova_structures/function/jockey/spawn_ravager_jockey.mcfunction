summon minecraft:ravager ~ ~ ~ {PersistenceRequired:1b,Passengers:[{id:"minecraft:pillager",PersistenceRequired:1b,equipment:{mainhand:{id:"crossbow",count:1}}}]}
kill @s