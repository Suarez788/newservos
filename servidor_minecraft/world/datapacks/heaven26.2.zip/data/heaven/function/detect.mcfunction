execute as @a store result score @s Height run data get entity @s Pos[1]

#teleportation
#execute as @a[nbt={Dimension:"minecraft:overworld"}] at @s if score @s Height >= GoHeaven Height in heaven:sky run forceload add ~ ~
execute as @a[nbt={Dimension:"minecraft:overworld"}] at @s if score @s Height >= GoHeaven Height in heaven:sky run tp ~ 16 ~
#execute as @a[nbt={Dimension:"heaven:sky"}] at @s run forceload remove ~ ~

execute as @a[nbt={Dimension:"heaven:sky"}] at @s if score @s Height <= GoOverworld Height in minecraft:overworld run tp @s ~ 350 ~

#Anti Gravity Arrows
execute as @e[nbt={inGround:0b, item:{components:{"minecraft:potion_contents":{custom_color:1625851}},count:1,id:"minecraft:tipped_arrow"}}] at @s run data modify entity @s NoGravity set value 1b
