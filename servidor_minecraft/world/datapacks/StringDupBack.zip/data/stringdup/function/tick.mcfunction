execute as @e[type=item] if data entity @s Item.components.minecraft:custom_data.stringDrop at @s run function stringdup:dropstring
execute as @e[type=item] if data entity @s Item.components.minecraft:custom_data.stringToggleFalse at @s run function stringdup:togglefalse
execute as @e[type=item] if data entity @s Item.components.minecraft:custom_data.stringToggleTrue at @s run function stringdup:toggletrue


