setblock ~ ~ ~ tripwire[disarmed=true]
kill @s