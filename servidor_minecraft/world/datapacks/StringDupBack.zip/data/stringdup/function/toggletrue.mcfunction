setblock ~ ~ ~ tripwire[disarmed=true]
playsound minecraft:block.tripwire.detach master @p
kill @s