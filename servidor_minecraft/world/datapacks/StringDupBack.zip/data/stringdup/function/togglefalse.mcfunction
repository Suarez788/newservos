setblock ~ ~ ~ tripwire[disarmed=false]
playsound minecraft:block.tripwire.detach master @p
kill @s