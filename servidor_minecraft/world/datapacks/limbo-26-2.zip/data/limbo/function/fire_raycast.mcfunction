# Remove one from the raycast limit
scoreboard players remove .raycastLimit fire_raycast 1

# Optional: display a particle
particle minecraft:wax_off

# Check if the raycast has hit an entity's hitbox
execute positioned ~-.99 ~-.99 ~-.99 as @e[dx=0,tag=!fire_raycaster] positioned ~.99 ~.99 ~.99 as @s[dx=0] run return run function limbo:fire_raycast_hit

# If the raycast has not hit a wall, and the limit has not been reached, move the raycast forward and run the function again
execute if block ~ ~ ~ #minecraft:replaceable if score .raycastLimit fire_raycast matches 1.. positioned ^ ^ ^0.1 run function limbo:fire_raycast