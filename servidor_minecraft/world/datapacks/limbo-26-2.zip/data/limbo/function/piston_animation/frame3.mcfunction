execute as @a at @s run execute at @e[type=minecraft:marker,limit=1, sort=nearest,name="big_piston"] run clone ~2 ~8 ~2 ~-2 ~8 ~-2 ~-2 ~7 ~-2
execute as @a at @s run execute at @e[type=minecraft:marker,limit=1, sort=nearest,name="big_piston"] run clone ~2 ~9 ~2 ~-2 ~9 ~-2 ~-2 ~8 ~-2
