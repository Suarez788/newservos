# This is the team for no collision
team add noCollision "No Collision"

# Other teams for mobs that may attack other mobs
team add noCollisionCat "No Collision Cat"
team add noCollisionPolar "No Collision Polar Bear"
team add noCollisionSlime "No Collision Polar Slime"
team add noCollisionFox "No Collision Polar Fox"
team add noCollisionAxolotl "No Collision Axolotl"

# Modify the team to have no collision
team modify noCollision collisionRule never
team modify noCollisionAxolotl collisionRule never
team modify noCollisionCat collisionRule never
team modify noCollisionFox collisionRule never
team modify noCollisionPolar collisionRule never
team modify noCollisionSlime collisionRule never

# Messages
tellraw @a {"text":"NoCollision succesfully reload","color":"green"}
tellraw @a {"text":"---------------------------------"}
tellraw @a {"text":"Data pack made by sniffercraft34, click to go to his profile","clickEvent":{"action":"open_url","value":"https://modrinth.com/user/sniffercraft34"}}
tellraw @a {"text":"---------------------------------"}
tellraw @a {"text":"[Click to uninstall]","color":"red","clickEvent":{"action":"run_command","value":"/function no_collision:uninstall"}}
tellraw @a {"text":"Important: When you uninstall, immediately remove the data pack from the folder. If /reload is typed or the world reloads, you must uninstall again!","bold":true,"color":"red"}