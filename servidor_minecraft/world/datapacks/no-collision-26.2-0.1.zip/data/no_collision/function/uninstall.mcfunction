team remove noCollision
team remove noCollisionAxolotl
team remove noCollisionCat
team remove noCollisionFox
team remove noCollisionPolar
team remove noCollisionSlime
tellraw @s {"text":"NoCollision succesfully uninstalled. You may remove it from the data packs folder now.","color":"green"} 
tellraw @s {"text":"This will not work upon reloading, you must uninstall again!","color":"red"}
tellraw @s {"text":"[Reinstall]","color":"green","clickEvent":{"action":"run_command","value":"/reload"}}