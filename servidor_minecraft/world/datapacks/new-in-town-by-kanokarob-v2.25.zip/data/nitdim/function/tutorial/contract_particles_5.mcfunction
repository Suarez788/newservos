particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~10.5 ~ ~ 0 0 4.5 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~-10.5 ~ ~ 0 0 4.5 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~ ~ ~10.5 4.5 0 0 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~ ~ ~-10.5 4.5 0 0 0 10 normal @s

particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~10.5 ~14.5 ~10.5 0 6.5 0 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~10.5 ~14.5 ~-10.5 0 6.5 0 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~-10.5 ~14.5 ~10.5 0 6.5 0 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~-10.5 ~14.5 ~-10.5 0 6.5 0 0 10 normal @s

particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~10.5 ~28 ~ 0 0 4.5 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~-10.5 ~28 ~ 0 0 4.5 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~ ~28 ~10.5 4.5 0 0 0 10 normal @s
particle dust{color:[0.0f,1.0f,0.216f],scale:1.0f} ~ ~28 ~-10.5 4.5 0 0 0 10 normal @s

particle dust{color:[0.471f,0.0f,0.0f],scale:1.0f} ~10.5 ~-1.75 ~10.5 0 0.75 0 0 5 normal @s
particle dust{color:[0.471f,0.0f,0.0f],scale:1.0f} ~10.5 ~-1.75 ~-10.5 0 0.75 0 0 5 normal @s
particle dust{color:[0.471f,0.0f,0.0f],scale:1.0f} ~-10.5 ~-1.75 ~10.5 0 0.75 0 0 5 normal @s
particle dust{color:[0.471f,0.0f,0.0f],scale:1.0f} ~-10.5 ~-1.75 ~-10.5 0 0.75 0 0 5 normal @s

particle dust{color:[0.471f,0.0f,0.0f],scale:1.0f} ~10.5 ~-3 ~ 0 0 4.5 0 10 normal @s
particle dust{color:[0.471f,0.0f,0.0f],scale:1.0f} ~-10.5 ~-3 ~ 0 0 4.5 0 10 normal @s
particle dust{color:[0.471f,0.0f,0.0f],scale:1.0f} ~ ~-3 ~10.5 4.5 0 0 0 10 normal @s
particle dust{color:[0.471f,0.0f,0.0f],scale:1.0f} ~ ~-3 ~-10.5 4.5 0 0 0 10 normal @s