tp ~ 31 ~
execute at @s run place template nitco:generated/natural_ship ~-13 ~-1 ~-5
summon lightning_bolt ~ ~ ~