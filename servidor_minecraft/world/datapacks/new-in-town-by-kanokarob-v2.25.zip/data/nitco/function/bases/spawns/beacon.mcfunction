execute if predicate nitco:chance_30 positioned ^2 ^0.5 ^1 run function nitco:spawns/tyrant_guard
execute if predicate nitco:chance_30 positioned ^-2 ^0.5 ^1 run function nitco:spawns/tyrant_guard
execute positioned ^ ^5 ^ run function nitco:spawns/tyrant_conscript
playsound block.beacon.activate block @a ~ ~ ~ 2.5 1.5
scoreboard players reset @s nitResourceTime