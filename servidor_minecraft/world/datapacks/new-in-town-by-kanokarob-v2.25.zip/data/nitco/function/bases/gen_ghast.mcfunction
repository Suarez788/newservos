tp ~ 31 ~
execute at @s run place template nitco:generated/natural_nursery ~-13 ~-3 ~-13
summon lightning_bolt ~ ~ ~