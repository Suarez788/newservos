###Cosmetics###
playsound minecraft:item.goat_horn.sound.0 block @a ~ ~ ~ 3 1.2

###Clear the base and kill the entity###
execute if entity @s[tag=nitHellShip] run advancement grant @a[distance=..40] only nitco:nitco/trawler_ship
execute if entity @s[tag=nitHellGhast] run advancement grant @a[distance=..40] only nitco:nitco/ghast_nursery
execute if entity @s[tag=nitHellBarracks] run advancement grant @a[distance=..40] only nitco:nitco/black_barracks
execute if entity @s[tag=nitHellBeacon] run advancement grant @a[distance=..40] only nitco:nitco/eternity_beacon
execute if entity @s[tag=nitHellDrill] run advancement grant @a[distance=..40] only nitco:nitco/ancient_drill
execute if entity @s[tag=nitHellFactory] run advancement grant @a[distance=..40] only nitco:nitco/summon_tyrant
tag @s add nitCleared