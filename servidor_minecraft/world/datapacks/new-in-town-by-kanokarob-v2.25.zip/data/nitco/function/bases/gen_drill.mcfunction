tp ~ 9 ~
execute at @s run place template nitco:generated/natural_drill ~-12 ~-8 ~-11
summon lightning_bolt ~ ~ ~