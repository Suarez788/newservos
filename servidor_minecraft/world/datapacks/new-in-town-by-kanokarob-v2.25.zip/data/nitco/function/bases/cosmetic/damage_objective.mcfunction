particle crit ^ ^0.5 ^2.2 0.15 0.15 0.15 0.05 10 normal
particle damage_indicator ^ ^0.5 ^2.2 0.15 0.15 0.15 0.01 5 normal

execute if entity @s[tag=nitObjectiveShip] run playsound entity.iron_golem.hurt block @a ~ ~ ~ 1 0.8
execute if entity @s[tag=nitObjectiveEgg] run playsound entity.turtle.egg_hatch block @a ~ ~ ~ 1 0.6
execute if entity @s[tag=nitObjectiveControls] run playsound entity.iron_golem.hurt block @a ~ ~ ~ 1 0.8
execute if entity @s[tag=nitObjectiveBarracks] run playsound entity.iron_golem.hurt block @a ~ ~ ~ 1 0.8
execute if entity @s[tag=nitObjectivePylon] run playsound block.respawn_anchor.deplete block @a ~ ~ ~ 1 0.7
execute if entity @s[tag=nitObjectiveBeacon] run playsound block.beacon.deactivate block @a ~ ~ ~ 2 1.4
execute if entity @s[tag=nitObjectiveDrill] run playsound entity.iron_golem.hurt block @a ~ ~ ~ 1 0.8
execute if entity @s[tag=nitObjectivePortal] run playsound block.glass.break block @a ~ ~ ~ 1 0.8
execute if entity @s[tag=nitObjectivePortalLarge] run playsound block.glass.break block @a ~ ~ ~ 1 0.8