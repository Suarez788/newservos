execute positioned ^ ^0.5 ^ run function nitco:spawns/tyrant_soldier
execute if predicate nitco:chance_30 positioned ^ ^0.5 ^3 run function nitco:spawns/tyrant_guard
playsound block.portal.travel block @a ~ ~ ~ 0.55 1.6
scoreboard players reset @s nitResourceTime