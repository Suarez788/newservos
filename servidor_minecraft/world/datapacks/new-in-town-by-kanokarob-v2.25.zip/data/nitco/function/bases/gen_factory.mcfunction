tp ~ 107 ~
execute at @s run place template nitco:generated/natural_factory ~-13 ~-2 ~-13
summon lightning_bolt ~ ~ ~