execute positioned ^ ^0.5 ^2 run function nitco:spawns/tyrant_guard
execute if predicate nitco:chance_30 positioned ^ ^0.5 ^-2 run function nitco:spawns/tyrant_guard
playsound block.respawn_anchor.charge block @a ~ ~ ~ 2 1.3
scoreboard players reset @s nitResourceTime