tp ~ 45 ~
execute at @s run place template nitco:generated/natural_beacon ~-10 ~-13 ~-10
summon lightning_bolt ~ ~ ~