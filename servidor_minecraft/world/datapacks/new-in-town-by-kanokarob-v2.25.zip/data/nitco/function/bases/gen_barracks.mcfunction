tp ~ 72 ~
execute at @s run place template nitco:generated/natural_barracks ~-17 ~-4 ~-17
summon lightning_bolt ~ ~ ~