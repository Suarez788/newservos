execute positioned ~ ~0.5 ~2 run function nitco:spawns/tyrant_soldier
execute if predicate nitco:chance_30 positioned ~ ~0.5 ~-2 run function nitco:spawns/tyrant_soldier
playsound block.respawn_anchor.set_spawn block @a ~ ~ ~ 2 1.3
scoreboard players reset @s nitResourceTime