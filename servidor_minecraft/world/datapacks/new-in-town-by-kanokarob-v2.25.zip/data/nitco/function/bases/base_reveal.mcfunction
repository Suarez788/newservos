###Trigger attack if it's your turn###
function nitk:id_match_self
execute if entity @s[scores={nitHellAttacks=1..},tag=nitHellShip] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=2..},tag=nitHellGhast] unless entity @e[tag=nitHellShip,tag=nitID_match,tag=!nitCleared] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=4..},tag=nitHellBarracks] unless entity @e[tag=nitHellGhast,tag=nitID_match,tag=!nitCleared] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=6..},tag=nitHellBeacon] unless entity @e[tag=nitHellBarracks,tag=nitID_match,tag=!nitCleared] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=7..},tag=nitHellDrill] unless entity @e[tag=nitHellBeacon,tag=nitID_match,tag=!nitCleared] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=9..},tag=nitHellFactory] unless entity @e[tag=nitHellDrill,tag=nitID_match,tag=!nitCleared] run tag @s add nitAttackTrigger

###Move if there's a site too close###
scoreboard players set @s nitSpreadLim 0
execute if entity @s[tag=nitAttackTrigger] at @s positioned ~-16 ~ ~-16 if entity @e[tag=nitSite,dx=32,dz=32,y=0,dy=256] run function nitco:spread_bases_2

###Trawler Ship on 1st structure###
tag @s[tag=nitAttackTrigger,tag=nitHellShip] add nitPrepared
execute if entity @s[tag=nitAttackTrigger,tag=nitHellShip,tag=!nitGenerated] at @n[tag=nitCWS,tag=nitID_match,distance=..200] run tellraw @a[distance=..200] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.hell_attack.trawler_ship","fallback":"Your scouts have spotted the Trawler Ship! ","color":"dark_red","bold":false},{"translate":"nitco.hell_attack.trawler_ship.desc","fallback":"Destroy the engine down in the hull!","color":"white","bold":false}]


###Ghast Nursery on 2nd structure###
tag @s[tag=nitAttackTrigger,tag=nitHellGhast] add nitPrepared
execute if entity @s[tag=nitAttackTrigger,tag=nitHellGhast,tag=!nitGenerated] at @n[tag=nitCWS,tag=nitID_match,distance=..200] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.hell_attack.ghast_nursery","fallback":"Your scouts have found the Ghast Nursery! ","color":"dark_red","bold":false},{"translate":"nitco.hell_attack.ghast_nursery.desc","fallback":"Break the Ghast Eggs and destroy the tower's controls!","color":"white","bold":false}]


###Black Barracks on 4th structure###
tag @s[tag=nitAttackTrigger,tag=nitHellBarracks] add nitPrepared
execute if entity @s[tag=nitAttackTrigger,tag=nitHellBarracks,tag=!nitGenerated] at @n[tag=nitCWS,tag=nitID_match,distance=..200] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.hell_attack.black_barracks","fallback":"Your scouts have spied the Black Barracks! ","color":"dark_red","bold":false},{"translate":"nitco.hell_attack.black_barracks.desc","fallback":"Take out the two Armories!","color":"white","bold":false}]


###Eternity Beacon on 6th structure###
tag @s[tag=nitAttackTrigger,tag=nitHellBeacon] add nitPrepared
execute if entity @s[tag=nitAttackTrigger,tag=nitHellBeacon,tag=!nitGenerated] at @n[tag=nitCWS,tag=nitID_match,distance=..200] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.hell_attack.eternity_beacon","fallback":"Your scouts have discovered the Eternity Beacon! ","color":"dark_red","bold":false},{"translate":"nitco.hell_attack.eternity_beacon.desc","fallback":"Break the Pylons and eliminate the Beacon!","color":"white","bold":false}]


###Ancient Drill on 7th structure###
tag @s[tag=nitAttackTrigger,tag=nitHellDrill] add nitPrepared
execute if entity @s[tag=nitAttackTrigger,tag=nitHellDrill,tag=!nitGenerated] at @n[tag=nitCWS,tag=nitID_match,distance=..200] run tellraw @a[distance=..200] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.hell_attack.ancient_drill","fallback":"Your scouts have uncovered the Ancient Drill! ","color":"dark_red","bold":false},{"translate":"nitco.hell_attack.ancient_drill.desc","fallback":"Shut down the mining drill and its controls, and close the portal!","color":"white","bold":false}]


###Portal Factory on 9th structure###
tag @s[tag=nitAttackTrigger,tag=nitHellFactory] add nitPrepared
execute if entity @s[tag=nitAttackTrigger,tag=nitHellFactory,tag=!nitGenerated] at @n[tag=nitCWS,tag=nitID_match,distance=..200] run tellraw @a[distance=..200] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.hell_attack.portal_factory","fallback":"Your scouts have located the Portal Factory! ","color":"dark_red","bold":false},{"translate":"nitco.hell_attack.portal_factory.desc","fallback":"Destroy all four portals to cut off the Tyrant's access to the Overworld!","color":"white","bold":false}]