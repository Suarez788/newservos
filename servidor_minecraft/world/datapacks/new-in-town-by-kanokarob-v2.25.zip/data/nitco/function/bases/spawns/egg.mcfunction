execute if predicate nitco:chance_30 positioned ^ ^0.5 ^2 run function nitco:spawns/tyrant_soldier
execute positioned ~ ~8 ~ run function nitco:spawns/tyrant_conscript
playsound entity.evoker.prepare_summon block @a ~ ~ ~ 2 1.3
scoreboard players reset @s nitResourceTime