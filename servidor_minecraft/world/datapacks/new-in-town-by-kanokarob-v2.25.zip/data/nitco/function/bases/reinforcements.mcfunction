execute if entity @s[tag=nitObjectiveShip,predicate=nitk:in_nether] run function nitco:bases/spawns/ship
execute if entity @s[tag=nitObjectiveEgg] run function nitco:bases/spawns/egg
execute if entity @s[tag=nitObjectiveControls] run function nitco:bases/spawns/controls
execute if entity @s[tag=nitObjectiveBarracks] run function nitco:bases/spawns/barracks
execute if entity @s[tag=nitObjectivePylon] run function nitco:bases/spawns/pylon
execute if entity @s[tag=nitObjectiveBeacon] run function nitco:bases/spawns/beacon
execute if entity @s[tag=nitObjectiveDrill] run function nitco:bases/spawns/drill
execute if entity @s[tag=nitObjectivePortal] run function nitco:bases/spawns/portal
execute if entity @s[tag=nitObjectivePortalLarge] run function nitco:bases/spawns/portal_large
scoreboard players reset @s nitResourceTime