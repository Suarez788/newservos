###Cosmetics###
execute facing entity @p[advancements={nitco:tech/hurt_objective=true}] eyes run function nitco:bases/cosmetic/damage_objective
scoreboard players set @s nitTemp 25

###Spawn chance###
execute if entity @s[tag=nitObjectiveShip] if predicate nitco:chance_10 run function nitco:bases/spawns/ship
execute if entity @s[tag=nitObjectiveEgg] if predicate nitco:chance_10 run function nitco:bases/spawns/egg
execute if entity @s[tag=nitObjectiveControls] if predicate nitco:chance_10 run function nitco:bases/spawns/controls
execute if entity @s[tag=nitObjectiveBarracks] if predicate nitco:chance_10 run function nitco:bases/spawns/barracks
execute if entity @s[tag=nitObjectivePylon] if predicate nitco:chance_10 run function nitco:bases/spawns/pylon
execute if entity @s[tag=nitObjectiveBeacon] if predicate nitco:chance_10 run function nitco:bases/spawns/beacon
execute if entity @s[tag=nitObjectiveDrill] if predicate nitco:chance_10 run function nitco:bases/spawns/drill
execute if entity @s[tag=nitObjectivePortal] if predicate nitco:chance_10 run function nitco:bases/spawns/portal
execute if entity @s[tag=nitObjectivePortalLarge] if predicate nitco:chance_10 run function nitco:bases/spawns/portal_large