scoreboard players reset @s
playsound entity.generic.explode block @a ~ ~ ~ 3 1
playsound entity.iron_golem.death block @a ~ ~ ~ 3 0.8
particle explosion ~ ~1.5 ~ 1.5 1.5 1.5 0 30 normal
particle lava ~ ~1.5 ~ 1.5 1.5 1.5 0.07 10 normal
loot spawn ~ ~1 ~ loot nitco:command/objective
fill ~-1 ~ ~-1 ~1 ~2.2 ~1 air replace barrier
kill @e[tag=nitObjectiveHat,limit=1,sort=nearest]
kill @s