execute store result score @e[tag=nitBaseObjective,limit=1,sort=nearest] nitDamage run attribute @s minecraft:attack_damage get 1
execute if entity @s[predicate=!nitk:on_ground] run scoreboard players add @e[tag=nitBaseObjective,limit=1,sort=nearest] nitDamage 3
execute if entity @s[predicate=!nitk:on_ground] run playsound entity.player.attack.strong player @a ~ ~ ~ 1 1
execute as @e[tag=nitBaseObjective,limit=1,sort=nearest] at @s run function nitco:bases/damage_objective
advancement revoke @s only nitco:tech/hurt_objective