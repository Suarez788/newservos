execute if entity @s[tag=nitObjectivePortalLarge] run function nitco:bases/cosmetic/hitbox_extra_large
execute if entity @s[tag=nitObjectiveShip] run function nitco:bases/cosmetic/hitbox_large
execute if entity @s[tag=nitObjectiveDrill] run function nitco:bases/cosmetic/hitbox_large
execute if entity @s[tag=nitObjectivePortal] run function nitco:bases/cosmetic/hitbox_large
execute if entity @s[tag=nitObjectiveEgg] run function nitco:bases/cosmetic/hitbox_medium
execute if entity @s[tag=nitObjectiveBarracks] run function nitco:bases/cosmetic/hitbox_medium
execute if entity @s[tag=nitObjectiveBeacon] run function nitco:bases/cosmetic/hitbox_medium
execute if entity @s[tag=nitObjectiveControls] run function nitco:bases/cosmetic/hitbox_small
execute if entity @s[tag=nitObjectivePylon] run function nitco:bases/cosmetic/hitbox_small

execute if entity @s[tag=nitObjectivePylon] as @e[tag=nitObjectiveHat,limit=1,sort=nearest] at @s run tp @s ~ ~ ~ ~1 0