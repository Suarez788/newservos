###Spreads special features###
spreadplayers ~ ~ 40 120 false @e[tag=nitCSpecialFeature,tag=nitID_match]

###Repeats spread if features are within 40 blocks of portal###
execute positioned ~-20 ~ ~-20 if entity @e[tag=nitCSpecialFeature,dx=40,dy=40,tag=nitID_match] at @s run function nitco:spread_features