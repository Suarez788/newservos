execute as @e at @s run function nitco:clock_scheduled
schedule function nitco:scheduler 2s