###Checks for the time of day and adds requisite scores at noon###
summon minecraft:item ~-1 ~0.5 ~ {Item:{id:"minecraft:blaze_rod",count:4}}