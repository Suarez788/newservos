###Performs item distribution###
execute if entity @s[tag=nitDenizen] at @e[tag=nitCGoldStor,limit=1,sort=nearest] run summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:gold_ingot",count:4}}
execute if entity @s[tag=nitBasalter] at @e[tag=nitNetherbrickStor,limit=1,sort=nearest] run summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:nether_brick",count:12}}
execute if entity @s[tag=nitShroomer] at @e[tag=nitNetherbrickStor,limit=1,sort=nearest] run summon minecraft:item ~ ~0.5 ~ {Item:{id:"minecraft:nether_brick",count:4}}