execute facing entity @e[tag=nitGhastBalloon,limit=1,sort=nearest] eyes run tp ~ ~ ~
data modify entity @s ExplosionPower set value 0