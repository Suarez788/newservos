effect give @s[type=skeleton] minecraft:weakness 5 0
effect give @s[type=blaze] minecraft:weakness 5 0
effect give @s[type=magma_cube] minecraft:weakness 5 0
effect give @s[type=ghast] minecraft:weakness 5 0
effect give @s[type=hoglin] minecraft:weakness 5 0
effect give @s[type=player,tag=nitDenizen,gamemode=survival] minecraft:fire_resistance 5 0