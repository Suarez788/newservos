###Cosmetics###
setblock ~ ~2 ~ minecraft:soul_campfire replace
particle minecraft:soul_fire_flame ~ ~0.4 ~-0.7 0.1 0.2 0.1 0 5 force

###Upkeep to prevent cheating###
execute unless block ~ ~1 ~ minecraft:blast_furnace run kill @e[type=item,distance=..1,tag=!smithed.entity,tag=!smithed.strict]
execute unless block ~ ~1 ~ minecraft:blast_furnace run setblock ~ ~1 ~ minecraft:blast_furnace

###Replaces a full stack of anything successfully burned with one Netherite Scrap###
execute if block ~ ~1 ~ minecraft:blast_furnace{Items:[{Slot:2b,count:64}]} run data modify block ~ ~1 ~ Items append value {Slot:2b,id:"minecraft:netherite_scrap",count:1}