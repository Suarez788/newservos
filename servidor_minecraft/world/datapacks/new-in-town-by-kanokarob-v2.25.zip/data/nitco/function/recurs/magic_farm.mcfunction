data merge entity @s[predicate=nitco:item_bamboo] {Item:{id:"minecraft:porkchop"}}
data merge entity @s[predicate=nitco:item_nether_wart] {Item:{id:"minecraft:diamond"}}
data merge entity @s[predicate=nitco:item_weeping_vines] {Item:{id:"minecraft:raw_iron"}}