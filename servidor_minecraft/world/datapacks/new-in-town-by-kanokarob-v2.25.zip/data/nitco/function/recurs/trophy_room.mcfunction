advancement revoke @s only nitco:nitco/tech1
tag @s add nitTrophyCheck

execute if entity @s[tag=nitTrophyCheck,tag=!nitAward1,advancements={nitco:nitco/completed_keep=true}] at @e[tag=nitTrophyRoom,distance=..12] run setblock ~4 ~1 ~2 diamond_block
playsound minecraft:entity.player.levelup player @s[tag=nitTrophyCheck,tag=!nitAward1,advancements={nitco:nitco/completed_keep=true}] ~ ~ ~ 20
tag @s[tag=nitTrophyCheck,tag=!nitAward1,advancements={nitco:nitco/completed_keep=true}] add nitAward1

execute if entity @s[tag=nitTrophyCheck,tag=!nitAward2,advancements={nitref:nitref/ender_throne=true}] at @e[tag=nitTrophyRoom,distance=..12] run setblock ~2 ~1 ~4 emerald_block
playsound minecraft:entity.player.levelup player @s[tag=nitTrophyCheck,tag=!nitAward2,advancements={nitref:nitref/ender_throne=true}] ~ ~ ~ 20
tag @s[tag=nitTrophyCheck,tag=!nitAward2,advancements={nitref:nitref/ender_throne=true}] add nitAward2

execute if entity @s[tag=nitTrophyCheck,tag=!nitAward3,advancements={nitref:nitref/completed_city=true}] at @e[tag=nitTrophyRoom,distance=..12] run setblock ~-2 ~1 ~4 netherite_block
playsound minecraft:entity.player.levelup player @s[tag=nitTrophyCheck,tag=!nitAward3,advancements={nitref:nitref/completed_city=true}] ~ ~ ~ 20
tag @s[tag=nitTrophyCheck,tag=!nitAward3,advancements={nitref:nitref/completed_city=true}] add nitAward3

execute if entity @s[tag=nitTrophyCheck,tag=!nitAward4,advancements={nitk:nitk/complete_town=true}] at @e[tag=nitTrophyRoom,distance=..12] run setblock ~-4 ~1 ~2 gold_block
playsound minecraft:entity.player.levelup player @s[tag=nitTrophyCheck,tag=!nitAward4,advancements={nitk:nitk/complete_town=true}] ~ ~ ~ 20
tag @s[tag=nitTrophyCheck,tag=!nitAward4,advancements={nitk:nitk/complete_town=true}] add nitAward4

execute if entity @s[tag=nitTrophyCheck,tag=!nitAward5,advancements={nitk:nitk/complete_castle=true}] at @e[tag=nitTrophyRoom,distance=..12] run setblock ~-4 ~1 ~-2 gold_block
playsound minecraft:entity.player.levelup player @s[tag=nitTrophyCheck,tag=!nitAward5,advancements={nitk:nitk/complete_castle=true}] ~ ~ ~ 20
tag @s[tag=nitTrophyCheck,tag=!nitAward5,advancements={nitk:nitk/complete_castle=true}] add nitAward5

execute if entity @s[tag=nitTrophyCheck,tag=!nitAward6,advancements={nitco:nitco/paradox_box=true}] at @e[tag=nitTrophyRoom,distance=..12] run setblock ~2 ~1 ~-4 emerald_block
playsound minecraft:entity.player.levelup player @s[tag=nitTrophyCheck,tag=!nitAward6,advancements={nitco:nitco/paradox_box=true}] ~ ~ ~ 20
tag @s[tag=nitTrophyCheck,tag=!nitAward6,advancements={nitco:nitco/paradox_box=true}] add nitAward6

execute if entity @s[tag=nitTrophyCheck,tag=!nitAward7,advancements={nitco:nitco/completed_fortress=true}] at @e[tag=nitTrophyRoom,distance=..12] run setblock ~4 ~1 ~-2 diamond_block
playsound minecraft:entity.player.levelup player @s[tag=nitTrophyCheck,tag=!nitAward7,advancements={nitco:nitco/completed_fortress=true}] ~ ~ ~ 20
tag @s[tag=nitTrophyCheck,tag=!nitAward7,advancements={nitco:nitco/completed_fortress=true}] add nitAward7

tag @s remove nitTrophyCheck