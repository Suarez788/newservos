advancement revoke @s only nitco:tech/lift

execute if entity @e[tag=nitLiftTop,distance=..3] run tag @s add nitGoingDown
execute if entity @e[tag=nitLiftBottom,distance=..3] run tag @s add nitGoingUp

execute at @e[tag=nitLiftBottom,sort=nearest,limit=1] run tp @a[tag=nitGoingDown] ~ ~-1 ~-1
execute at @e[tag=nitLiftTop,sort=nearest,limit=1] run tp @s[tag=nitGoingUp] ~ ~-1 ~-1

execute at @s run playsound minecraft:block.lava.extinguish block @s[tag=nitGoingDown] ~ ~ ~ 1
execute at @s run playsound minecraft:block.lava.extinguish block @s[tag=nitGoingUp] ~ ~ ~ 1

tag @s[tag=nitGoingDown] remove nitGoingDown
tag @s[tag=nitGoingUp] remove nitGoingUp