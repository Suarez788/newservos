effect give @p[distance=..1] minecraft:regeneration 1 0
effect give @p[distance=..1] minecraft:saturation 1 0