###Sets up scoreboards for advancements and attacks. Utilizes same objectives as nitk for resources###
scoreboard objectives add nitWarCraft dummy
scoreboard objectives add nitHellAttacks dummy
scoreboard objectives add nitBoxProg dummy
scoreboard objectives add nitKeepCraft dummy
scoreboard objectives add nitDamage dummy
scoreboard objectives add nitBaseHealth dummy
tag @s add nitcoFounder
gamerule minecraft:command_blocks_work true
advancement grant @a[advancements={nitk:nitk/tyrant_defeat=true},predicate=nitk:in_nether] only nitco:nitco/root

###Create the portal###
place template nitco:portal ~-7 ~-5 ~-7
tp @s ~ ~1 ~
fill ~-2 ~-6 ~-2 ~2 ~-6 ~2 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"}

###Place siteplanners###
place template nitco:siteplanner_e ~7 ~1 ~
place template nitco:siteplanner_w ~-7 ~1 ~
place template nitco:siteplanner_n ~ ~1 ~-7
place template nitco:siteplanner_s ~ ~1 ~7

###Remove the strategy###
clear @s written_book[custom_data={nitContractBook:1b,nit_particleType:2b}]

###Assigns the fortress' ID###
execute store result score @s nitID run data get entity @s UUID[0]
scoreboard players operation @e[tag=nitResourceHopper,limit=2,sort=nearest] nitID = @s nitID
tag @s add nitDenizen

###Summons markers for natural structures###
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellBase,nitTyrantEntity,nitHellShip,nitCSpecialFeature,smithed.entity,smithed.strict]}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellBase,nitTyrantEntity,nitHellGhast,nitCSpecialFeature,smithed.entity,smithed.strict]}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellBase,nitTyrantEntity,nitHellBarracks,nitCSpecialFeature,smithed.entity,smithed.strict]}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellBase,nitTyrantEntity,nitHellBeacon,nitCSpecialFeature,smithed.entity,smithed.strict]}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellBase,nitTyrantEntity,nitHellDrill,nitCSpecialFeature,smithed.entity,smithed.strict]}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellBase,nitTyrantEntity,nitHellFactory,nitBossArena,nitCSpecialFeature,smithed.entity,smithed.strict]}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitWithermaw,nitCSpecialFeature,smithed.entity,smithed.strict]}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitBoxCenter,nitCSpecialFeature,smithed.entity,smithed.strict]}
scoreboard players operation @e[tag=nitCSpecialFeature,limit=8,sort=nearest] nitID = @s nitID

###Spreads the natural structures for the matching fortress###
function nitk:id_match_self
execute at @s run function nitco:spread_features

###Summons the War Strategist, who fulfills similar function to Town Planner###
execute at @e[tag=nitWarStrategist] as @s run summon villager ~ ~ ~ {VillagerData:{profession:weaponsmith,level:5,type:swamp},Invulnerable:1b,PersistenceRequired:1b,NoAI:1b,CustomName:{"translate":"nitco.name.war_strategist","fallback":"War Strategist"},Offers:{Recipes:[{buy:{id:feather,count:1},sell:{id:"minecraft:written_book",count:1},maxUses:9999999},{buy:{id:firework_star,count:1,components:{"minecraft:custom_model_data": {floats:[8601010.0f]}, "minecraft:item_name":{"color":"dark_red","fallback":"Tyrannical Heart","italic":false,"translate":"nitk.item.tyrannical_heart"}, "minecraft:enchantment_glint_override": 1b, "minecraft:custom_data": {nitk_tyrantHeart: 1b}}},sell:{id:gold_ingot,count:3},maxUses:9999999},{buy:{id:gold_ingot,count:16},sell:{id:ender_eye,count:1},maxUses:9999999}]},Tags:[nitDenizen,nitCWS,nitEntity,nitTicking,smithed.entity,smithed.strict]}
scoreboard players operation @e[tag=nitCWS,limit=1,sort=nearest] nitID = @s nitID
function nitk:debug/update_all
kill @e[tag=nitWarStrategist]

###Anounces completed process###
tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.contract.success","fallback":"You have successfully launched your Counteroffensive!","color":"white","bold":false}]