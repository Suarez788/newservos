###Checks Location###
execute if entity @s[tag=nitcoFounder] run tellraw @s [{"text":"[回] ","color":"blue","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.contract.warning.founder","fallback":"You have already launched a Counteroffensive. You cannot found another Fortress.","color":"white","bold":false}]
execute unless entity @s[predicate=nitk:in_nether] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.contract.warning.dimension","fallback":"You must take the counteroffensive to the Tyrant's home world!","color":"white","bold":false}]
execute if entity @s[predicate=nitk:in_nether,y=0,dy=50] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.contract.warning.height","fallback":"You are too low to start the counteroffensive. You must build higher!","color":"white","bold":false}]
execute if entity @s[predicate=nitk:in_nether,predicate=nitco:near_nether_roof] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.contract.warning.bedrock","fallback":"You are too near the Nether Roof to start the counteroffensive.","color":"white","bold":false}]
execute if entity @e[tag=nitCWS,distance=..500] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.contract.warning.distance","fallback":"You cannot attack within 500 blocks of another fortress. Venture out farther!","color":"white","bold":false}]
execute unless entity @s[tag=nitcoFounder] if entity @s[predicate=nitk:in_nether,y=51,dy=128,predicate=!nitco:near_nether_roof] unless entity @e[tag=nitCWS,distance=..500] run tag @s add nitClearCondition

###Builds Fortress###
execute if entity @s[tag=nitClearCondition] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitco.contract.begin","fallback":"You begin to build your fortress...","color":"white","bold":false}]
execute if entity @s[tag=nitClearCondition] run function nitco:contract

###Reset Trigger###
tag @s remove nitClearCondition
scoreboard players reset @s nitContract