give @p bucket
data remove block ~ ~0.2 ~ Items

execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/keep/keep ~1 ~-6 ~-7
execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/keep/keep_conn_ew ~-1 ~-2 ~-2

execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/keep/keep ~-15 ~-6 ~-7
execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/keep/keep_conn_ew ~-2 ~-2 ~-2

execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/keep/keep ~-7 ~-6 ~-15
execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/keep/keep_conn_ns ~-2 ~-2 ~-2

execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/keep/keep ~-7 ~-6 ~1
execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/keep/keep_conn_ns ~-2 ~-2 ~-1

function nitco:siteplanner/keep/new_keep_check

scoreboard players add @a[distance=..20] nitKeepCraft 1
advancement grant @a[scores={nitKeepCraft=6..}] only nitco:nitco/completed_keep build-6

execute at @e[tag=nitKeeper] as @s run summon villager ~ ~ ~ {VillagerData:{profession:mason,level:4,type:swamp},Invulnerable:1b,PersistenceRequired:1b,NoAI:1b,CustomName:{"translate":"nitco.name.keeper","fallback":"Nether Keeper"},Offers:{Recipes:[{buy:{id:feather,count:1},sell:{id:"minecraft:written_book",count:1},maxUses:9999999},{buy:{id:nether_brick,count:5},buyB:{id:gold_ingot,count:1},sell:{id: "minecraft:nether_brick", count: 2, components: {"minecraft:custom_model_data": {floats:[8601011.0f]}, "minecraft:item_name":{"color":"red","fallback":"Reinforced Brick","italic":false,"translate":"nitk.item.reinforced_brick"}, "minecraft:enchantment_glint_override": 1b, "minecraft:custom_data": {nitco_strongBrick: 1b}}},rewardExp:0b,maxUses:9999999}]},Tags:[nitEntity,nitTicking,nitDenizen,nitCK,smithed.entity,smithed.strict]}
function nitk:debug/update_all
kill @e[tag=nitKeeper]