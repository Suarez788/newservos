advancement revoke @s only nitco:recipes/recipe_doompump

execute as @e[tag=nitCSitePlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function nitco:siteplanner/build_doompump