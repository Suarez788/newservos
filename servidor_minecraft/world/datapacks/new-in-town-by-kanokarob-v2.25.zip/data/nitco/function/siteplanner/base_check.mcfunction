###Establishes id matches for Tyrant Bases###
function nitk:id_match_war_planner

###Increases the Tyrant Base danger count, then reveals matching base###
scoreboard players add @e[tag=nitHellBase,tag=nitID_match] nitHellAttacks 1

###Increases siteplanning count on player for advancement purposes###
scoreboard players add @a[distance=..50,tag=nitCitizen] nitWarCraft 1