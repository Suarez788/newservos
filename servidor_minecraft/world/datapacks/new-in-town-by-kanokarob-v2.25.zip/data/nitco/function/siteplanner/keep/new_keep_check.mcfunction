###Creates new siteplanners for unoccupied sites adjacent to site newly constructed to the east###
execute if entity @s[tag=nitSiteEast] run fill ~ ~ ~-8 ~18 ~-6 ~8 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace minecraft:acacia_planks
execute positioned ~16 ~ ~-7 as @s[tag=nitSiteEast] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsEast
execute positioned ~1 ~ ~-22 as @s[tag=nitSiteEast] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsNorth
execute positioned ~1 ~ ~8 as @s[tag=nitSiteEast] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteEast] run function nitco:siteplanner/keep/newkeep_e

###Creates new siteplanners for unoccupied sites adjacent to site newly constructed to the west###
execute if entity @s[tag=nitSiteWest] run fill ~ ~ ~-8 ~-16 ~-6 ~8 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace minecraft:acacia_planks
execute positioned ~-30 ~ ~-7 as @s[tag=nitSiteWest] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsWest
execute positioned ~-15 ~ ~-22 as @s[tag=nitSiteWest] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsNorth
execute positioned ~-15 ~ ~8 as @s[tag=nitSiteWest] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest] run function nitco:siteplanner/keep/newkeep_w

###Creates new siteplanners for unoccupied sites adjacent to site newly constructed to the north###
execute if entity @s[tag=nitSiteNorth] run fill ~-8 ~ ~ ~8 ~-6 ~-16 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace minecraft:acacia_planks
execute positioned ~-7 ~ ~-30 as @s[tag=nitSiteNorth] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsNorth
execute positioned ~8 ~ ~-15 as @s[tag=nitSiteNorth] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsEast
execute positioned ~-22 ~ ~-15 as @s[tag=nitSiteNorth] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth] run function nitco:siteplanner/keep/newkeep_n

###Creates new siteplanners for unoccupied sites adjacent to site newly constructed to the south###
execute if entity @s[tag=nitSiteSouth] run fill ~-8 ~ ~ ~8 ~-6 ~16 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace minecraft:acacia_planks
execute positioned ~-7 ~ ~16 as @s[tag=nitSiteSouth] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsSouth
execute positioned ~8 ~ ~1 as @s[tag=nitSiteSouth] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsEast
execute positioned ~-22 ~ ~1 as @s[tag=nitSiteSouth] if entity @e[tag=nitSite,dx=15,y=0,dy=256,dz=15] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteSouth] run function nitco:siteplanner/keep/newkeep_s

###Establishes id matches for hell attack sites###
execute if entity @s[tag=!nitCoBridge] run function nitk:id_match_war_planner
execute if entity @s[tag=!nitCoBridge] run function nitco:siteplanner/base_check

###Cleanup###
tag @a add nitDenizen
tag @e[type=minecraft:villager,distance=..20] add nitDenizen
execute as @e[tag=nitDenizen,distance=..20] at @s run function nitk:id_set_war_planner
tag @s add nitKilled
execute if entity @s[tag=nitSiteEast] run particle large_smoke ~7 ~2 ~ 3 2 3 0.3 200 force
execute if entity @s[tag=nitSiteWest] run particle large_smoke ~-7 ~2 ~ 3 2 3 0.3 200 force
execute if entity @s[tag=nitSiteNorth] run particle large_smoke ~ ~2 ~-7 3 2 3 0.3 200 force
execute if entity @s[tag=nitSiteSouth] run particle large_smoke ~ ~2 ~7 3 2 3 0.3 200 force
playsound minecraft:block.anvil.use block @a ~ ~ ~ 1 0.7
playsound minecraft:entity.villager.work_weaponsmith block @a ~ ~ ~ 2 0.5
playsound minecraft:block.respawn_anchor.set_spawn block @a ~ ~ ~ 2 1 1
playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 2 1