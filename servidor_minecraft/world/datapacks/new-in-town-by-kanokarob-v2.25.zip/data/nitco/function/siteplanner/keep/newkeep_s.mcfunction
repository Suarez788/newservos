###Destroys adjacent defunct site planners###
execute positioned ~-13 ~ ~-1 run tag @e[tag=nitSitePlanner,dx=26,dz=21,y=-64,dy=312] add nitKilled

###Sets new site planners at available positions, if building an initial Keep###
execute if entity @s[tag=!nitSiteExistsSouth,tag=nitCSitePlanner] run place template nitco:keepplanner_s ~ ~ ~13

execute if entity @s[tag=!nitSiteExistsEast,tag=nitCSitePlanner] run place template nitco:keepplanner_e ~5 ~ ~8

execute if entity @s[tag=!nitSiteExistsWest,tag=nitCSitePlanner] run place template nitco:keepplanner_w ~-5 ~ ~8

###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsSouth,tag=nitCKeepPlanner] run place template nitco:keepplanner_s ~ ~ ~15

execute if entity @s[tag=!nitSiteExistsEast,tag=nitCKeepPlanner] run place template nitco:keepplanner_e ~5 ~ ~10

execute if entity @s[tag=!nitSiteExistsWest,tag=nitCKeepPlanner] run place template nitco:keepplanner_w ~-5 ~ ~10