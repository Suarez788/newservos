execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/scout ~1 ~-6 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/scout ~-15 ~-6 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/scout ~-7 ~-6 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/scout ~-7 ~-6 ~1

execute as @e[tag=nitScoutMarker,distance=..20] at @s run function nitk:id_set_war_planner
function nitco:siteplanner/new_sites_check
advancement grant @a[distance=..20] only nitco:nitco/completed_fortress build-scout
advancement grant @a[distance=..6] only nitk:tutorial/build_scout build-scout