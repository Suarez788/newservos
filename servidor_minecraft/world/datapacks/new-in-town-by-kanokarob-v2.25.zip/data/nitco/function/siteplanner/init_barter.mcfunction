advancement revoke @s only nitco:recipes/recipe_barter

execute as @e[tag=nitCSitePlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function nitco:siteplanner/build_barter