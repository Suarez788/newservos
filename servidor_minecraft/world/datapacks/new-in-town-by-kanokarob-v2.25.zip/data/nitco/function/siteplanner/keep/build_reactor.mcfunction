execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/keep/reactor ~3 ~-6 ~-7
execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/keep/keep_conn_ew ~1 ~-2 ~-2

execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/keep/reactor ~-17 ~-6 ~-7
execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/keep/keep_conn_ew ~-4 ~-2 ~-2

execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/keep/reactor ~-7 ~-6 ~-17
execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/keep/keep_conn_ns ~-2 ~-2 ~-4

execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/keep/reactor ~-7 ~-6 ~3
execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/keep/keep_conn_ns ~-2 ~-2 ~1

function nitco:siteplanner/keep/new_keep_check

scoreboard players add @a[distance=..20] nitKeepCraft 1
advancement grant @a[scores={nitKeepCraft=6..}] only nitco:nitco/completed_keep build-6