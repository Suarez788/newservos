###Destroys adjacent defunct site planners###
execute positioned ~-13 ~ ~-1 run tag @e[tag=nitSitePlanner,dx=26,dz=17,y=-64,dy=312] add nitKilled

###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsSouth] run place template nitco:siteplanner_s ~ ~ ~15

execute if entity @s[tag=!nitSiteExistsEast] run place template nitco:siteplanner_e ~7 ~ ~8

execute if entity @s[tag=!nitSiteExistsWest] run place template nitco:siteplanner_w ~-7 ~ ~8