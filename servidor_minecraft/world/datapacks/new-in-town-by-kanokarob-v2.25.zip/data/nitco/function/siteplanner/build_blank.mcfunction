execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/blank ~1 ~-6 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/blank ~-15 ~-6 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/blank ~-7 ~-6 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/blank ~-7 ~-6 ~1

function nitco:siteplanner/new_sites_check