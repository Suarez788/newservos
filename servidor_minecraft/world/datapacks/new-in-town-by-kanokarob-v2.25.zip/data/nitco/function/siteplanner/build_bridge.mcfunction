execute if entity @s[tag=nitSiteEast] unless block ~23 ~-2 ~ bedrock run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteWest] unless block ~-23 ~-2 ~ bedrock run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteNorth] unless block ~ ~-2 ~-23 bedrock run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteSouth] unless block ~ ~-2 ~23 bedrock run tag @s add nitLargeSite

execute if entity @s[tag=nitLargeSite,tag=nitSiteEast] run place template nitco:fortress/bridge ~1 ~-6 ~-3

execute if entity @s[tag=nitLargeSite,tag=nitSiteWest] run place template nitco:fortress/bridge ~-1 ~-6 ~3 180

execute if entity @s[tag=nitLargeSite,tag=nitSiteNorth] run place template nitco:fortress/bridge ~-3 ~-6 ~-1 counterclockwise_90

execute if entity @s[tag=nitLargeSite,tag=nitSiteSouth] run place template nitco:fortress/bridge ~3 ~-6 ~1 clockwise_90

###Altered site checking for single planner placement###
execute if entity @s[tag=nitLargeSite] run tag @s add nitCoBridge
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitLargeSite] run function nitco:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s remove nitSiteExistsEast
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s remove nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s remove nitSiteExistsNorth
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s remove nitSiteExistsSouth
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] positioned ~15 ~ ~ run function nitco:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] positioned ~-15 ~ ~ run function nitco:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] positioned ~ ~ ~-15 run function nitco:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] positioned ~ ~ ~15 run function nitco:siteplanner/new_sites_check

###Builds column below bridge###
execute if entity @s[tag=nitLargeSite,tag=nitSiteEast] positioned ~14 ~-6 ~ run fill ~-3 ~ ~-3 ~3 ~ ~3 repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace acacia_planks
execute if entity @s[tag=nitLargeSite,tag=nitSiteWest] positioned ~-14 ~-6 ~ run fill ~-3 ~ ~-3 ~3 ~ ~3 repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace acacia_planks
execute if entity @s[tag=nitLargeSite,tag=nitSiteNorth] positioned ~ ~-6 ~-14 run fill ~-3 ~ ~-3 ~3 ~ ~3 repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace acacia_planks
execute if entity @s[tag=nitLargeSite,tag=nitSiteSouth] positioned ~ ~-6 ~14 run fill ~-3 ~ ~-3 ~3 ~ ~3 repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace acacia_planks

execute if entity @s[tag=!nitLargeSite] run tellraw @a[distance=..20] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.large_site.warning","fallback":"Not enough room for structure at this site.","color":"white","bold":false}]