###Destroys adjacent defunct site planners###
execute positioned ~-17 ~ ~-13 run tag @e[tag=nitSitePlanner,dx=17,dz=26,y=-64,dy=312] add nitKilled

###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsWest] run place template nitco:siteplanner_w ~-15 ~ ~

execute if entity @s[tag=!nitSiteExistsNorth] run place template nitco:siteplanner_n ~-8 ~ ~-7

execute if entity @s[tag=!nitSiteExistsSouth] run place template nitco:siteplanner_s ~-8 ~ ~7