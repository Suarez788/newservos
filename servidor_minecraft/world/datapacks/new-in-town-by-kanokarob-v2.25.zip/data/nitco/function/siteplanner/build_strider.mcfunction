###Builds the upper fortress platform. Directional###
execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/strider ~1 ~-6 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/strider ~-15 ~-6 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/strider ~-7 ~-6 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/strider ~-7 ~-6 ~1

###Performs standard new site check, then removes the standard support nitPillar###
function nitco:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteEast] run fill ~6 ~-6 ~-2 ~10 ~-6 ~2 minecraft:air
execute if entity @s[tag=nitSiteWest] run fill ~-6 ~-6 ~-2 ~-10 ~-6 ~2 minecraft:air
execute if entity @s[tag=nitSiteNorth] run fill ~-2 ~-6 ~-6 ~2 ~-6 ~-10 minecraft:air
execute if entity @s[tag=nitSiteSouth] run fill ~-2 ~-6 ~6 ~2 ~-6 ~10 minecraft:air

###Updates progressive advancement###
advancement grant @a[distance=..20] only nitco:nitco/completed_fortress build-strider

###Replaces nitPillars from new_sites_check with air and chains, then builds lower dock. Directional###
execute if entity @s[tag=nitSiteEast] run setblock ~9 ~-6 ~1 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteEast] run setblock ~9 ~-6 ~-1 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteEast] run setblock ~7 ~-6 ~1 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteEast] run setblock ~7 ~-6 ~-1 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/strider_dock ~1 31 ~-7

execute if entity @s[tag=nitSiteWest] run setblock ~-9 ~-6 ~1 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteWest] run setblock ~-9 ~-6 ~-1 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteWest] run setblock ~-7 ~-6 ~1 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteWest] run setblock ~-7 ~-6 ~-1 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/strider_dock ~-15 31 ~-7

execute if entity @s[tag=nitSiteNorth] run setblock ~1 ~-6 ~-9 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteNorth] run setblock ~-1 ~-6 ~-9 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteNorth] run setblock ~1 ~-6 ~-7 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteNorth] run setblock ~-1 ~-6 ~-7 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/strider_dock ~-7 31 ~-15

execute if entity @s[tag=nitSiteSouth] run setblock ~1 ~-6 ~9 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteSouth] run setblock ~-1 ~-6 ~9 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteSouth] run setblock ~1 ~-6 ~7 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteSouth] run setblock ~-1 ~-6 ~7 minecraft:repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 40 ~ minecraft:iron_chain"} replace
execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/strider_dock ~-7 31 ~1