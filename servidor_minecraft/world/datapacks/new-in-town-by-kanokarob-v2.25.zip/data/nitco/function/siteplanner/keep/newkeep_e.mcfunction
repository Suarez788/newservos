###Destroys adjacent defunct site planners###
execute positioned ~-1 ~ ~-13 run tag @e[tag=nitSitePlanner,dx=21,dz=26,y=-64,dy=312] add nitKilled

###Sets new site planners at available positions, if building an initial Keep###
execute if entity @s[tag=!nitSiteExistsEast,tag=nitCSitePlanner] run place template nitco:keepplanner_e ~13 ~ ~

execute if entity @s[tag=!nitSiteExistsNorth,tag=nitCSitePlanner] run place template nitco:keepplanner_n ~8 ~ ~-5

execute if entity @s[tag=!nitSiteExistsSouth,tag=nitCSitePlanner] run place template nitco:keepplanner_s ~8 ~ ~5

###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsEast,tag=nitCKeepPlanner] run place template nitco:keepplanner_e ~15 ~ ~

execute if entity @s[tag=!nitSiteExistsNorth,tag=nitCKeepPlanner] run place template nitco:keepplanner_n ~10 ~ ~-5

execute if entity @s[tag=!nitSiteExistsSouth,tag=nitCKeepPlanner] run place template nitco:keepplanner_s ~10 ~ ~5