advancement revoke @s only nitco:recipes/keep/recipe_purehearth

execute as @e[tag=nitCKeepPlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function nitco:siteplanner/keep/build_purehearth