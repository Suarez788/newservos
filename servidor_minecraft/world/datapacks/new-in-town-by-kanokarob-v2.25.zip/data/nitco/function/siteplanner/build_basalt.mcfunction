give @p bucket

execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/basalt ~1 ~-6 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/basalt ~-15 ~-6 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/basalt ~-7 ~-6 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/basalt ~-7 ~-6 ~1

function nitco:siteplanner/new_sites_check
advancement grant @a[distance=..20] only nitco:nitco/completed_fortress build-basalt