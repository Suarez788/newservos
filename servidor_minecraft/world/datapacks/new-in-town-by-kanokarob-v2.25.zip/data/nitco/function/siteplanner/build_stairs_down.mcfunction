execute if entity @s[tag=nitSiteEast] run place template nitco:fortress/stairs_down ~1 ~-12 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitco:fortress/stairs_down ~-1 ~-12 ~7 180

execute if entity @s[tag=nitSiteNorth] run place template nitco:fortress/stairs_down ~-7 ~-12 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitco:fortress/stairs_down ~7 ~-12 ~1 clockwise_90

tag @s add nitCoBridge
execute positioned ~ ~-6 ~ run function nitco:siteplanner/new_sites_check

###Builds column below bridge###
execute if entity @s[tag=nitSiteEast] positioned ~8 ~-12 ~ run fill ~-3 ~ ~-3 ~3 ~ ~3 repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace acacia_planks
execute if entity @s[tag=nitSiteWest] positioned ~-8 ~-12 ~ run fill ~-3 ~ ~-3 ~3 ~ ~3 repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace acacia_planks
execute if entity @s[tag=nitSiteNorth] positioned ~ ~-12 ~-8 run fill ~-3 ~ ~-3 ~3 ~ ~3 repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace acacia_planks
execute if entity @s[tag=nitSiteSouth] positioned ~ ~-12 ~8 run fill ~-3 ~ ~-3 ~3 ~ ~3 repeating_command_block{auto:1b,Command:"fill ~ ~ ~ ~ 20 ~ nether_bricks"} replace acacia_planks