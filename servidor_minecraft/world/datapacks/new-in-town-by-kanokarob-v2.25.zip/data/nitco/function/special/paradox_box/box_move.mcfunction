###Performs appropriate check of player's direction relative to the current progress###
tag @s remove nitBoxResetting
execute if entity @s[scores={nitBoxProg=6}] if entity @p[y_rotation=-45.1..44.9] run scoreboard players add @s nitBoxProg 1
execute if entity @s[scores={nitBoxProg=6}] unless entity @p[y_rotation=-45.1..44.9] run function nitco:special/paradox_box/box_reset
execute if entity @s[scores={nitBoxProg=5},tag=!nitBoxResetting] if entity @p[y_rotation=45.1..134.9] run scoreboard players add @s nitBoxProg 1
execute if entity @s[scores={nitBoxProg=5},tag=!nitBoxResetting] unless entity @p[y_rotation=45.1..134.9] run function nitco:special/paradox_box/box_reset
execute if entity @s[scores={nitBoxProg=4},tag=!nitBoxResetting] if entity @p[y_rotation=-134.9..-45.1] run scoreboard players add @s nitBoxProg 1
execute if entity @s[scores={nitBoxProg=4},tag=!nitBoxResetting] unless entity @p[y_rotation=-134.9..-45.1] run function nitco:special/paradox_box/box_reset
execute if entity @s[scores={nitBoxProg=3},tag=!nitBoxResetting] if entity @p[y_rotation=135.1..-134.9] run scoreboard players add @s nitBoxProg 1
execute if entity @s[scores={nitBoxProg=3},tag=!nitBoxResetting] unless entity @p[y_rotation=135.1..-134.9] run function nitco:special/paradox_box/box_reset
execute if entity @s[scores={nitBoxProg=2},tag=!nitBoxResetting] if entity @p[y_rotation=-89.9..-0.1] run scoreboard players add @s nitBoxProg 1
execute if entity @s[scores={nitBoxProg=2},tag=!nitBoxResetting] unless entity @p[y_rotation=-89.9..-0.1] run function nitco:special/paradox_box/box_reset
execute if entity @s[scores={nitBoxProg=1},tag=!nitBoxResetting] if entity @p[y_rotation=45.1..134.9] run scoreboard players add @s nitBoxProg 1
execute if entity @s[scores={nitBoxProg=1},tag=!nitBoxResetting] unless entity @p[y_rotation=45.1..134.9] run function nitco:special/paradox_box/box_reset
execute if entity @s[scores={nitBoxProg=0},tag=!nitBoxResetting] if entity @p[y_rotation=-45.1..44.9] run scoreboard players add @s nitBoxProg 1
execute if entity @s[scores={nitBoxProg=0},tag=!nitBoxResetting] unless entity @p[y_rotation=-45.1..44.9] run function nitco:special/paradox_box/box_reset
tag @s remove nitBoxResetting

###Moves the box accordingly###
execute if entity @s[scores={nitBoxProg=1..}] run setblock ~ ~ ~ air
execute if entity @s[scores={nitBoxProg=1..}] run particle minecraft:portal ~ ~0 ~ 0.2 0 0.2 0.3 100
execute if entity @s[scores={nitBoxProg=1..7}] at @e[tag=nitBoxCenter] run function nitco:special/paradox_box/box_move_relative
execute if entity @s[scores={nitBoxProg=1..6}] at @s run setblock ~ ~ ~ minecraft:trapped_chest{CustomName:{"translate":"nitk.tutorial.paradox_box","fallback":"Paradox Box"},LootTable:"nitco:chest/paradoxbox"}
execute if entity @s[scores={nitBoxProg=7}] at @s run setblock ~ ~ ~ minecraft:trapped_chest{CustomName:{"translate":"nitk.tutorial.paradox_box","fallback":"Paradox Box"},LootTable:"nitk:items/piece_of_infinity"}
execute if entity @s[scores={nitBoxProg=7}] run particle minecraft:cloud ~ ~0 ~ 0.2 0 0.2 0.3 100

###Plays appropriate sound effect###
execute if entity @s[scores={nitBoxProg=1}] run playsound minecraft:block.end_portal_frame.fill master @p ~ ~ ~ 20 0.1
execute if entity @s[scores={nitBoxProg=2}] run playsound minecraft:block.end_portal_frame.fill master @p ~ ~ ~ 20 0.5
execute if entity @s[scores={nitBoxProg=3}] run playsound minecraft:block.end_portal_frame.fill master @p ~ ~ ~ 20 0.9
execute if entity @s[scores={nitBoxProg=4}] run playsound minecraft:block.end_portal_frame.fill master @p ~ ~ ~ 20 1.3
execute if entity @s[scores={nitBoxProg=5}] run playsound minecraft:block.end_portal_frame.fill master @p ~ ~ ~ 20 1.7
execute if entity @s[scores={nitBoxProg=6}] run playsound minecraft:block.end_portal_frame.fill master @p ~ ~ ~ 20 2.0
execute if entity @s[scores={nitBoxProg=7}] run playsound minecraft:block.end_portal.spawn master @p ~ ~ ~ 20 2
execute if entity @s[scores={nitBoxProg=7}] run advancement grant @p only nitco:nitco/paradox_box