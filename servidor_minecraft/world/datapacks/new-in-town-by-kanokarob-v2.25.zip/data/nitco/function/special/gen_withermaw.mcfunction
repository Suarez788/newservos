tp ~ 72 ~
execute at @s run place template nitco:generated/natural_withermaw ~-14 ~-12 ~-14
#kill @s