###Generate appropriate structure
execute if entity @s[tag=nitHellShip,tag=nitPrepared] run function nitco:bases/gen_ship
execute if entity @s[tag=nitHellGhast,tag=nitPrepared] run function nitco:bases/gen_ghast
execute if entity @s[tag=nitHellBarracks,tag=nitPrepared] run function nitco:bases/gen_barracks
execute if entity @s[tag=nitHellBeacon,tag=nitPrepared] run function nitco:bases/gen_beacon
execute if entity @s[tag=nitHellDrill,tag=nitPrepared] run function nitco:bases/gen_drill
execute if entity @s[tag=nitHellFactory,tag=nitPrepared] run function nitco:bases/gen_factory
execute if entity @s[tag=nitWithermaw] run function nitco:special/gen_withermaw
execute if entity @s[tag=nitBoxCenter] run function nitco:special/paradox_box/boxinit
tag @s[tag=!nitHellBase] add nitGenerated
tag @s[tag=nitHellBase,tag=nitPrepared] add nitGenerated