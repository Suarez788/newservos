execute if entity @s[scores={nitBoxProg=1}] run tp @s ~4 ~ ~-3
execute if entity @s[scores={nitBoxProg=2}] run tp @s ~-4 ~ ~-3
execute if entity @s[scores={nitBoxProg=3}] run tp @s ~ ~ ~6
execute if entity @s[scores={nitBoxProg=4}] run tp @s ~2 ~ ~1
execute if entity @s[scores={nitBoxProg=5}] run tp @s ~-2 ~ ~1
execute if entity @s[scores={nitBoxProg=6}] run tp @s ~ ~ ~-3
execute if entity @s[scores={nitBoxProg=7}] run tp @s ~ ~ ~