tag @s add nitBoxResetting
execute at @s run setblock ~ ~ ~ air
kill @e[type=item,distance=..2,tag=!smithed.entity,tag=!smithed.strict]
execute if entity @s[scores={nitBoxProg=1..}] run particle minecraft:portal ~ ~0 ~ 0.2 0 0.2 0.3 100
tp @s @e[tag=nitBoxCenter,limit=1,sort=nearest]
execute at @s run setblock ~ ~ ~ minecraft:trapped_chest{CustomName:{"translate":"nitk.tutorial.paradox_box","fallback":"Paradox Box"},LootTable:"nitco:chest/paradoxbox"}
scoreboard players set @s nitBoxProg 0
playsound minecraft:block.respawn_anchor.deplete master @p ~ ~ ~ 20 2