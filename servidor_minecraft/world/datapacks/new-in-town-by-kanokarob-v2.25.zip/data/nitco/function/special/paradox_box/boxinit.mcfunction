summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitBoxMarker,smithed.entity,smithed.strict]}
setblock ~ ~ ~ minecraft:trapped_chest{CustomName:{"translate":"nitk.tutorial.paradox_box","fallback":"Paradox Box"},LootTable:"nitco:chest/paradoxbox"}
scoreboard players set @e[tag=nitBoxMarker] nitBoxProg 0