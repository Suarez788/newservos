###Revokes the advancement###
advancement revoke @p only nitco:nitco/paradox_box_open

###Performs movement checks###
execute as @e[tag=nitBoxMarker] at @s run function nitco:special/paradox_box/box_move