###Spreads special features###
spreadplayers ~ ~ 40 120 false @e[tag=nitHellBase,tag=nitID_match]

###Repeats spread if features are within 40 blocks of portal###
execute positioned ~-20 ~ ~-20 if entity @e[tag=nitHellBase,distance=..40,tag=nitID_match] at @s run function nitco:spread_bases_2