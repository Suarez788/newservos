###Runs functions for town, fortress, and city structures structures###
execute if entity @s[tag=nitTownPlanner] as @e[type=minecraft:witch,tag=nitKTP,distance=..1] run function nitk:recurs/modify_witch
execute if entity @s[tag=nitGuardTower] as @e[distance=..100] run function nitk:recurs/guardtower_lookout
execute if entity @s[tag=nitJukebox] run function nitk:recurs/bard_jukebox
execute if entity @s[tag=nitTimeAdd] run execute if entity @a[distance=..1] run function nitk:recurs/stardial_add
execute if entity @s[tag=nitTimeSub] run execute if entity @a[distance=..1] run function nitk:recurs/stardial_sub
execute if entity @s[tag=nitCathedralWater] run function nitk:recurs/cathedral_water
execute if entity @s[tag=nitVisitor] run function nitk:recurs/town_square/visitor_info
execute if entity @s[tag=nitGhastBalloon] as @e[type=ghast,distance=..100] at @s run function nitco:recurs/ghast_balloon
execute if entity @s[tag=nitSoulForge] run function nitco:recurs/soulforge
execute if entity @s[tag=nitHealWater] run function nitco:recurs/healing_water
execute if entity @s[tag=nitScoutMarker] run function nitco:recurs/scout_spyglass
execute if entity @s[tag=nitPurehearth] run function nitco:recurs/purehearth
execute if entity @s[tag=nitObPylon] as @e[distance=..100] run function nitco:recurs/ob_pylon
execute if entity @s[tag=nitInfLava] run function nitref:recurs/infinite_lava
execute if entity @s[tag=nitSlowFall] run function nitref:recurs/slowfall
execute if entity @s[tag=nitDragonologist] run function nitref:recurs/dragonology/dragonologist

###Handles Naturally Generated Features building when loaded###
execute if entity @s[tag=nitKSpecialFeature,tag=!nitGenerated] if loaded ~ ~ ~ run function nitk:special/generate
execute if entity @s[tag=nitCSpecialFeature,tag=!nitGenerated] if loaded ~ ~ ~ run function nitco:special/generate

###Runs the special functions for some natural structures###
execute if entity @s[tag=nitHaroldCage] run function nitk:special/cage_cured

###Performs checks for the invasion progress, then runs appropriate functions###
execute if entity @s[tag=nitRWither] run function nitref:invasion/control

###Enderman Friendliness###
execute if entity @s[team=nitFriendEnd,type=enderman] if entity @a[team=nitFriendEnd,distance=..10] run function nitref:team_handle