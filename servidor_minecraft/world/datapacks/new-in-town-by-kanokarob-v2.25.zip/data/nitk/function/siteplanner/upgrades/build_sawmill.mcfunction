###Builds the upgrade with the same rotation as the original###
execute positioned ~-1 ~ ~ if entity @e[tag=nitRotation,distance=..0.5] run place template nitk:upgrades/sawmill ~8 ~ ~7 180

execute positioned ~1 ~ ~ if entity @e[tag=nitRotation,distance=..0.5] run place template nitk:upgrades/sawmill ~-8 ~ ~-7

execute positioned ~ ~ ~1 if entity @e[tag=nitRotation,distance=..0.5] run place template nitk:upgrades/sawmill ~7 ~ ~-8 clockwise_90

execute positioned ~ ~ ~-1 if entity @e[tag=nitRotation,distance=..0.5] run place template nitk:upgrades/sawmill ~-7 ~ ~8 counterclockwise_90

###Moves and Promotes the Lumberer###
tp @e[tag=nitLumberer,limit=1,sort=nearest] @e[tag=nitLumberSpot,limit=1,sort=nearest]
data modify entity @e[tag=nitLumberer,limit=1,sort=nearest] CustomName set value {"translate":"nitk.name.mill_foreman","fallback":"Mill Foreman"}

###Miner setup###
execute as @e[tag=nitCitizen,distance=..20] at @s run function nitk:id_set_town_planner
function nitk:id_match_town_planner
execute if entity @e[tag=nitLumberStor,tag=nitAtSilo] run tag @e[tag=nitLumberer,tag=nitID_match] add nitAtSilo

###Cleanup###
function nitk:siteplanner/upgrades/cleanup