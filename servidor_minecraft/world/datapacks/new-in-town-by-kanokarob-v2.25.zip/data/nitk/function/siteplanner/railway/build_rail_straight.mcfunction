execute if entity @s[tag=nitSiteEast] positioned ~16 ~-16 ~-7 unless entity @e[tag=nitSite,dx=15,dy=21,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteWest] positioned ~-30 ~-16 ~-7 unless entity @e[tag=nitSite,dx=15,dy=21,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteNorth] positioned ~-7 ~-16 ~-30 unless entity @e[tag=nitSite,dx=15,dy=21,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteSouth] positioned ~-7 ~-16 ~16 unless entity @e[tag=nitSite,dx=15,dy=21,dz=15] run tag @s add nitLargeSite

execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run place template nitk:railway/rail_straight ~1 ~-3 ~-3

execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run place template nitk:railway/rail_straight ~-1 ~-3 ~3 180

execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run place template nitk:railway/rail_straight ~-3 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run place template nitk:railway/rail_straight ~3 ~-3 ~1 clockwise_90

###Altered site planner placement for unidirection###
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] positioned ~15 ~ ~ run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] positioned ~-15 ~ ~ run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] positioned ~ ~ ~-15 run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] positioned ~ ~ ~15 run function nitk:siteplanner/new_rails_check


execute if entity @s[tag=!nitLargeSite] run tellraw @a[distance=..20] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.large_site.warning","fallback":"Not enough room for structure at this site.","color":"white","bold":false}]