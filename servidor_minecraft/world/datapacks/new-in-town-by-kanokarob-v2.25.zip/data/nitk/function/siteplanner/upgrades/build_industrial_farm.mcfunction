###Builds the upgrade###
place template nitk:upgrades/industrial_farm ~-7 ~ ~-7

###Moves and Promotes the Farmer###
tp @e[tag=nitFarmhand,limit=1,sort=nearest] @e[tag=nitFarmerSpot,limit=1,sort=nearest]
data modify entity @e[tag=nitFarmhand,limit=1,sort=nearest] CustomName set value {"translate":"nitk.name.farm_operator","fallback":"Farm Operator"}

###Farmer setup###
execute at @e[tag=nitResourceChest,distance=..20] run setblock ~ ~ ~ chest[facing=north]
execute as @e[tag=nitCitizen,distance=..20] at @s run function nitk:id_set_town_planner

###Cleanup###
function nitk:siteplanner/upgrades/cleanup