advancement revoke @s only nitk:recipes/railway/recipe_rail_ramp_up

execute as @e[tag=nitKRailPlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function nitk:siteplanner/railway/build_rail_ramp_up