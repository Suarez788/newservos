advancement revoke @s only nitk:recipes/upgrades/recipe_town_hall

tag @e[tag=nitSiteWagon,limit=1,sort=nearest] add nitStatus
execute if entity @e[tag=nitStatus,tag=!nitUpgraded,limit=1,sort=nearest] run tag @s add nitClearCondition
execute if entity @s[tag=nitClearCondition] as @e[tag=nitStatus,tag=!nitUpgraded,limit=1,sort=nearest] at @s run function nitk:siteplanner/upgrades/build_town_hall
execute if entity @s[tag=nitClearCondition] at @e[tag=nitKBankPlanner,limit=1,sort=nearest] run function nitk:siteplanner/upgrades/bank_planner_effects
execute if entity @s[tag=nitClearCondition] run advancement grant @a[distance=..20] only nitk:nitk/upgrade_all build-town-hall
execute if entity @s[tag=nitClearCondition] run advancement grant @a[distance=..20] only nitk:nitk/small_loan

execute unless entity @s[tag=nitClearCondition] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.bank.denied","fallback":"There is no site available for upgrade with this recipe in range.","color":"white","bold":false}]
tag @s remove nitClearCondition
tag @e remove nitStatus