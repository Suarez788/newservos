give @p bucket 2

advancement grant @p only nitdim:nitdim/root

execute if entity @s[tag=nitSiteEast] run place template nitk:town/between_portal ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/between_portal ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/between_portal ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/between_portal ~7 ~-3 ~1 clockwise_90

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check