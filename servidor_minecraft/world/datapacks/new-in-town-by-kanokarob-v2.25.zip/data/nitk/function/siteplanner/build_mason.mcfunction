execute if entity @s[tag=nitSiteEast] run place template nitk:town/masonry ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/masonry ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/masonry ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/masonry ~7 ~-3 ~1 clockwise_90

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-masonry

execute as @e[tag=nitResourceChest,distance=..20] at @s run function nitk:id_set_town_planner
function nitk:id_match_town_planner
execute if entity @e[tag=nitWindmill,tag=nitID_match,distance=..100] run tag @e[tag=nitResourceChest,tag=nitID_match] add nitWindmillDouble