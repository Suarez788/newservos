function nitk:siteplanner/large_site_check

execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run place template nitk:town/barn ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run place template nitk:town/barn ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run place template nitk:town/barn ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run place template nitk:town/barn ~7 ~-3 ~1 clockwise_90

execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] positioned ~15 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] positioned ~-15 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] positioned ~ ~ ~-15 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] positioned ~ ~ ~15 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/attacks_check
execute if entity @s[tag=nitLargeSite] run advancement grant @a[distance=..20] only nitk:nitk/complete_town build-barn


execute if entity @s[tag=!nitLargeSite] run tellraw @a[distance=..20] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.large_site.warning","fallback":"Not enough room for structure at this site.","color":"white","bold":false}]

execute as @e[tag=nitResourceChest,distance=..20] at @s run function nitk:id_set_town_planner
function nitk:id_match_town_planner
execute if entity @e[tag=nitWindmill,tag=nitID_match,distance=..100] run tag @e[tag=nitResourceChest,tag=nitID_match] add nitWindmillDouble