execute if entity @s[tag=nitSiteEast] run place template nitk:town/castle/frame ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/castle/frame ~-15 ~-3 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/castle/frame ~-7 ~-3 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/castle/frame ~-7 ~-3 ~1

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check

###Spawns the castle's Squire if there isn't one already###
execute as @e[tag=nitKSq] at @s unless entity @e[tag=nitSquire,distance=..200] run summon villager ~ ~ ~ {VillagerData:{profession:cartographer,level:4,type:"plains"},Invulnerable:1b,PersistenceRequired:1b,NoAI:1b,CustomName:{"translate":"nitk.name.squire","fallback":"Squire"},Offers:{Recipes:[{buy:{id:"minecraft:feather",count:1},sell:{id:"minecraft:written_book",count:1},maxUses:9999999}]},Tags:[nitCitizen,nitSquire,nitEntity,nitTicking,smithed.entity,smithed.strict]}

function nitk:debug/update_all
kill @e[tag=nitKSq]