execute if entity @s[tag=nitSiteEast] run place template nitk:town/windmill ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/windmill ~-15 ~-3 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/windmill ~-7 ~-3 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/windmill ~-7 ~-3 ~1

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-windmill

execute as @e[tag=nitResourceChest,distance=..100] at @s run function nitk:id_set_town_planner
function nitk:id_match_town_planner
tag @e[tag=nitResourceChest,tag=nitID_match] add nitWindmillDouble