kill @e[type=item,distance=..1.2,predicate=nitk:item_dropper,tag=!smithed.entity,tag=!smithed.strict]

###Check for and place new Site Planners###
execute if entity @s[tag=nitKSitePlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitk.site_planner","fallback":"Site Planner"}}
execute if entity @s[tag=nitKWallPlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitk.wall_planner","fallback":"Wall Planner"}}
execute if entity @s[tag=nitKCastlePlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitk.castle_planner","fallback":"Castle Planner"}}
execute if entity @s[tag=nitKBankPlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitk.bank_planner","fallback":"Banking Planner"}}
execute if entity @s[tag=nitPortalPlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitk.portal_reactor","fallback":"Portal Reactor"}}
execute if entity @s[tag=nitKRailPlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitk.rail_planner","fallback":"Rail Planner"}}
execute if entity @s[tag=nitCSitePlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitco.war_planner","fallback":"War Planner"}}
execute if entity @s[tag=nitCKeepPlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitco.keep_planner","fallback":"Keep Planner"}}
execute if entity @s[tag=nitRSitePlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitref.tower_planner","fallback":"Tower Planner"}}
execute if entity @s[tag=nitSSitePlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitsea.ship_planner","fallback":"Ship Planner"}}
execute if entity @s[tag=nitESitePlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitex.shaft_planner","fallback":"Shaft Planner"}}
execute if entity @s[tag=nitISitePlanner] run setblock ~ ~-0.2 ~ dropper[facing=up]{CustomName:{"translate":"nitinv.machine_planner","fallback":"Machine Planner"}}