execute if entity @s[tag=nitSiteEast] run place template nitk:town/villagehuts ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/villagehuts ~-15 ~-3 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/villagehuts ~-7 ~-3 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/villagehuts ~-7 ~-3 ~1

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-villagerhuts

summon minecraft:villager ~ ~ ~ {Tags:[nitEntity,nitTicking,nitCitizen]}
summon minecraft:villager ~ ~ ~ {Age:-24000,Tags:[nitEntity,nitTicking,nitCitizen]}