give @p bucket

execute if entity @s[tag=nitSiteEast] run place template nitk:town/farmplot ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/farmplot ~-15 ~-3 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/farmplot ~-7 ~-3 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/farmplot ~-7 ~-3 ~1

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-farmplot

###Creates farm storage if there isn't one already###
execute as @e[tag=nitFarmhand,limit=1,sort=nearest] at @s unless entity @e[tag=nitFarmStor,distance=..100] run place template nitk:town/farm_storage ~-2 ~ ~3

execute as @e[tag=nitResourceChest,distance=..20] at @s run function nitk:id_set_town_planner
function nitk:id_match_town_planner
execute if entity @e[tag=nitWindmill,tag=nitID_match,distance=..100] run tag @e[tag=nitResourceChest,tag=nitID_match] add nitWindmillDouble