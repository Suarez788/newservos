advancement revoke @s only nitk:recipes/recipe_railway

execute as @e[tag=nitKSitePlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function nitk:siteplanner/build_railway