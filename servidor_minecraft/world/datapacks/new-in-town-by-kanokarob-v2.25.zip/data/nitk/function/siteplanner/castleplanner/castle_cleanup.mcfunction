scoreboard players add @a[distance=..20] nitCastleCraft 1
advancement grant @a[scores={nitCastleCraft=6..}] only nitk:nitk/complete_castle finish-castle
execute as @a[distance=..4] at @s unless block ~ ~1 ~ air rotated ~ 0 run tp @s ^ ^1 ^-2

execute positioned ~7 ~ ~-7 if entity @e[tag=nitSiteCastle,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsEast
execute positioned ~-22 ~ ~-7 if entity @e[tag=nitSiteCastle,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsWest
execute positioned ~-7 ~ ~-22 if entity @e[tag=nitSiteCastle,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsNorth
execute positioned ~-7 ~ ~7 if entity @e[tag=nitSiteCastle,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsSouth

execute if entity @s[tag=nitSiteExistsEast] run place template nitk:town/castle/connection_alt ~4 ~-1 ~-3
execute if entity @s[tag=nitSiteExistsWest] run place template nitk:town/castle/connection_alt ~-4 ~-1 ~3 180
execute if entity @s[tag=nitSiteExistsNorth] run place template nitk:town/castle/connection_alt ~-3 ~-1 ~-4 counterclockwise_90
execute if entity @s[tag=nitSiteExistsSouth] run place template nitk:town/castle/connection_alt ~3 ~-1 ~4 clockwise_90

tag @a add nitCitizen
tag @e[type=minecraft:villager,distance=..20] add nitCitizen
kill @e[type=item,distance=..5,tag=!smithed.entity,tag=!smithed.strict]
particle poof ~ ~2 ~ 3 2 3 0.3 200 force
playsound minecraft:block.anvil.use block @a ~ ~ ~ 5 0.7
playsound minecraft:entity.villager.work_fletcher block @a ~ ~ ~ 5 0.5
playsound minecraft:block.chest.locked block @a ~ ~ ~ 5 0.7 1
playsound minecraft:block.chest.open block @a ~ ~ ~ 5 0.7 1
kill @s