place template nitk:town/castle/ft_tower ~-5 ~-1 ~-5

setblock ~ ~21 ~ minecraft:netherrack
setblock ~ ~22 ~ minecraft:fire

function nitk:siteplanner/castleplanner/castle_cleanup