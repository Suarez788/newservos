###Kills the old resource deposits from the matching town###
function nitk:id_match_town_planner
kill @e[tag=nitResourceHopper,tag=nitID_match,limit=2,sort=nearest,distance=..150]

execute if entity @s[tag=nitSiteEast] run place template nitk:town/silo ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/silo ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/silo ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/silo ~7 ~-3 ~1 clockwise_90

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-silo
advancement grant @a[distance=..6] only nitk:tutorial/build_silo build-silo

execute as @e[tag=nitResourceHopper,limit=2,sort=nearest] at @s run function nitk:id_set_town_planner
tag @e[tag=nitMiner,tag=nitID_match] add nitAtSilo
tag @e[tag=nitLumberer,tag=nitID_match] add nitAtSilo