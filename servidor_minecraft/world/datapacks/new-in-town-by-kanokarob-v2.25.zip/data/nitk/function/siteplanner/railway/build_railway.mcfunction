function nitk:siteplanner/large_site_check

execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run place template nitk:town/railway ~30 ~-3 ~7 180

execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run place template nitk:town/railway ~-30 ~-3 ~-7

execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run place template nitk:town/railway ~7 ~-3 ~-30 clockwise_90

execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run place template nitk:town/railway ~-7 ~-3 ~30 counterclockwise_90

execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] positioned ~15 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] positioned ~-15 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] positioned ~ ~ ~-15 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] positioned ~ ~ ~15 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/attacks_check
execute if entity @s[tag=nitLargeSite] run advancement grant @a[distance=..20] only nitk:nitk/complete_town build-railway


execute if entity @s[tag=!nitLargeSite] run tellraw @a[distance=..20] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.large_site.warning","fallback":"Not enough room for structure at this site.","color":"white","bold":false}]

###Summons the town planner and prepares Conductor recipes###
execute as @e[tag=nitTownPlanner] at @s run summon villager ~ ~ ~ {VillagerData:{profession:cartographer,level:4,type:"plains"},Invulnerable:1b,PersistenceRequired:1b,NoAI:1b,CustomName:{"translate":"nitk.name.town_planner","fallback":"Town Planner"},Offers:{Recipes:[{buy:{id:"minecraft:feather",count:1},sell:{id:"minecraft:written_book",count:1},maxUses:9999999},{buy:{id:gold_ingot,count:4},sell:{id:"minecraft:paper",count:1,components:{"minecraft:custom_model_data": {floats:[8601000.0f]}, "minecraft:item_name": {"color":"blue","fallback":"Building Permit","italic":false,"translate":"nitk.item.building_permit"}, "minecraft:lore": [{"color":"gray","fallback":"The final ingredient","italic":false,"translate":"nitk.item.building_permit.desc.1"}, {"color":"gray","fallback":"in new town structures.","italic":false,"translate":"nitk.item.building_permit.desc.2"}], "minecraft:enchantment_glint_override": 1b, "minecraft:custom_data": {nitk_buildingPermit: 1b}}},maxUses:9999999}]},Tags:[nitCitizen,nitKTP,nitEntity,nitTicking,smithed.entity,smithed.strict,nitKTPnew,nitKTPinformed]}
execute as @e[type=minecraft:villager,tag=nitKTP,limit=1,sort=nearest] at @s run function nitk:id_set_town_planner

execute if entity @s[tag=nitLargeSite] run function nitk:debug/update_all
execute if entity @s[tag=nitLargeSite] run kill @e[tag=nitTownPlanner,limit=1,sort=nearest]