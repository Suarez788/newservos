###Builds Wall from a Site Planner###
execute if entity @s[tag=nitSiteEast,tag=!nitKWallPlanner] run place template nitk:town/wall ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest,tag=!nitKWallPlanner] run place template nitk:town/wall ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth,tag=!nitKWallPlanner] run place template nitk:town/wall ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth,tag=!nitKWallPlanner] run place template nitk:town/wall ~7 ~-3 ~1 clockwise_90

###Builds Wall from a Wall Planner
execute if entity @s[tag=nitSiteEast,tag=nitKWallPlanner] if block ~ ~ ~2 stone_bricks run place template nitk:town/wall ~15 ~-3 ~-5 clockwise_90
execute if entity @s[tag=nitSiteEast,tag=nitKWallPlanner] if block ~ ~ ~-2 stone_bricks run place template nitk:town/wall ~15 ~-3 ~-9 clockwise_90

execute if entity @s[tag=nitSiteWest,tag=nitKWallPlanner] if block ~ ~ ~2 stone_bricks run place template nitk:town/wall ~-1 ~-3 ~-5 clockwise_90
execute if entity @s[tag=nitSiteWest,tag=nitKWallPlanner] if block ~ ~ ~-2 stone_bricks run place template nitk:town/wall ~-1 ~-3 ~-9 clockwise_90

execute if entity @s[tag=nitSiteNorth,tag=nitKWallPlanner] if block ~2 ~ ~ stone_bricks run place template nitk:town/wall ~-5 ~-3 ~-15
execute if entity @s[tag=nitSiteNorth,tag=nitKWallPlanner] if block ~-2 ~ ~ stone_bricks run place template nitk:town/wall ~-9 ~-3 ~-15

execute if entity @s[tag=nitSiteSouth,tag=nitKWallPlanner] if block ~2 ~ ~ stone_bricks run place template nitk:town/wall ~-5 ~-3 ~1
execute if entity @s[tag=nitSiteSouth,tag=nitKWallPlanner] if block ~-2 ~ ~ stone_bricks run place template nitk:town/wall ~-9 ~-3 ~1

###Place Site Planners###
execute if entity @s[tag=nitSiteEast,tag=!nitKWallPlanner] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteEast,tag=!nitKWallPlanner] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest,tag=!nitKWallPlanner] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteWest,tag=!nitKWallPlanner] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteNorth,tag=!nitKWallPlanner] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteNorth,tag=!nitKWallPlanner] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteSouth,tag=!nitKWallPlanner] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth,tag=!nitKWallPlanner] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteEast,tag=nitKWallPlanner] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteWest,tag=nitKWallPlanner] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth,tag=nitKWallPlanner] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteSouth,tag=nitKWallPlanner] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=!nitKWallPlanner] run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteEast,tag=nitKWallPlanner] if block ~ ~ ~2 stone_bricks positioned ~ ~ ~2 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteEast,tag=nitKWallPlanner] if block ~ ~ ~-2 stone_bricks positioned ~ ~ ~-2 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteWest,tag=nitKWallPlanner] if block ~ ~ ~2 stone_bricks positioned ~ ~ ~2 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteWest,tag=nitKWallPlanner] if block ~ ~ ~-2 stone_bricks positioned ~ ~ ~-2 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteNorth,tag=nitKWallPlanner] if block ~2 ~ ~ stone_bricks positioned ~2 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteNorth,tag=nitKWallPlanner] if block ~-2 ~ ~ stone_bricks positioned ~-2 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteSouth,tag=nitKWallPlanner] if block ~2 ~ ~ stone_bricks positioned ~2 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteSouth,tag=nitKWallPlanner] if block ~-2 ~ ~ stone_bricks positioned ~-2 ~ ~ run function nitk:siteplanner/new_sites_check

execute if entity @s[tag=nitSiteEast,tag=nitKWallPlanner] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteEast,tag=nitKWallPlanner] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest,tag=nitKWallPlanner] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteWest,tag=nitKWallPlanner] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteNorth,tag=nitKWallPlanner] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteNorth,tag=nitKWallPlanner] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteSouth,tag=nitKWallPlanner] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth,tag=nitKWallPlanner] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteEast,tag=!nitKWallPlanner] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteWest,tag=!nitKWallPlanner] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth,tag=!nitKWallPlanner] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteSouth,tag=!nitKWallPlanner] run tag @s add nitSiteExistsSouth
function nitk:siteplanner/walls/new_walls_check