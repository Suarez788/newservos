give @p bucket

execute if entity @s[tag=nitSiteEast] run place template nitk:town/town_square ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/town_square ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/town_square ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/town_square ~7 ~-3 ~1 clockwise_90

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-town_square
advancement grant @a[distance=..6] only nitk:tutorial/build_town_square build-town-square

###Prepares first visitor for the next day###
scoreboard players set @e[tag=nitTownSquare,limit=1,sort=nearest,distance=..20] nitResourceTime 6