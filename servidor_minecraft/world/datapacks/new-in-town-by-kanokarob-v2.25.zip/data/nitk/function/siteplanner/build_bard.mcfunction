execute if entity @s[tag=nitSiteEast] run place template nitk:town/bard ~1 ~-3 ~7 counterclockwise_90

execute if entity @s[tag=nitSiteWest] run place template nitk:town/bard ~-1 ~-3 ~-7 clockwise_90

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/bard ~7 ~-3 ~-1 180

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/bard ~-7 ~-3 ~1

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-bard