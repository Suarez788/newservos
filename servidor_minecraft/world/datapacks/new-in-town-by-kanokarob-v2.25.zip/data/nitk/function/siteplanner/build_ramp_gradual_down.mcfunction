execute if entity @s[tag=nitSiteEast] run place template nitk:town/ramp_gradual_down ~1 ~-6 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/ramp_gradual_down ~-1 ~-6 ~7 180

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/ramp_gradual_down ~-7 ~-6 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/ramp_gradual_down ~7 ~-6 ~1 clockwise_90

execute positioned ~ ~-3 ~ run function nitk:siteplanner/new_sites_check