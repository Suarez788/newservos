execute if entity @s[tag=nitSiteEast] positioned ~16 ~ ~-7 unless entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteWest] positioned ~-30 ~ ~-7 unless entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteNorth] positioned ~-7 ~ ~-30 unless entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteSouth] positioned ~-7 ~ ~16 unless entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitLargeSite

execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run place template nitk:town/festival ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run place template nitk:town/festival ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run place template nitk:town/festival ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run place template nitk:town/festival ~7 ~-3 ~1 clockwise_90

execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] positioned ~15 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] positioned ~-15 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] positioned ~ ~ ~-15 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] positioned ~ ~ ~15 run function nitk:siteplanner/new_sites_check


execute if entity @s[tag=!nitLargeSite] run tellraw @a[distance=..20] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.large_site.warning","fallback":"Not enough room for structure at this site.","color":"white","bold":false}]

###Begins festival###
execute if entity @s[tag=nitLargeSite] run scoreboard players set @e[tag=nitFestival,limit=1,sort=nearest,distance=..20] nitResourceSpawn 9
execute if entity @s[tag=nitLargeSite] run execute as @e[tag=nitFestival,limit=1,sort=nearest,distance=..20] run function nitk:recurs/festival