###Destroys adjacent defunct site planners###
execute positioned ~-1 ~ ~-9 run tag @e[tag=nitSitePlanner,tag=!nitKRailPlanner,tag=!nitKBankPlanner,tag=!nitKCastlePlanner,tag=!nitPortalPlanner,dx=17,dz=18,y=-64,dy=312] add nitKilled
execute positioned ~-1 ~-16 ~-9 run tag @e[tag=nitKRailPlanner,dx=17,dz=18,dy=21] add nitKilled

###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsEast] run place template nitk:siteplanner_e ~15 ~ ~

execute if entity @s[tag=!nitSiteExistsNorth] run place template nitk:siteplanner_n ~8 ~ ~-7

execute if entity @s[tag=!nitSiteExistsSouth] run place template nitk:siteplanner_s ~8 ~ ~7