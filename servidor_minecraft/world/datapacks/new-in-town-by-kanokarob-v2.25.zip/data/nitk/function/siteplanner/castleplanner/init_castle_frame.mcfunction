advancement revoke @s only nitk:recipes/castle/recipe_castle_frame

execute as @e[tag=nitKSitePlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function nitk:siteplanner/castleplanner/build_castle_frame