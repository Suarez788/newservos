execute if entity @s[tag=nitSiteEast] run place template nitk:town/ramp_stairs_up ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/ramp_stairs_up ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/ramp_stairs_up ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/ramp_stairs_up ~7 ~-3 ~1 clockwise_90

execute positioned ~ ~6 ~ run function nitk:siteplanner/new_sites_check