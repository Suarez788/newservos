###Handles Site Planner removal###
execute if block ~ ~ ~ fire run tag @s add nitKilled
execute if entity @s[tag=nitKilled] positioned ~ ~-0.2 ~ run function nitk:siteplanner_kill

###Restores damaged Site Planners###
execute unless entity @s[tag=nitKilled] unless block ~ ~-0.2 ~ minecraft:dropper run function nitk:siteplanner/restore