data remove block ~ ~-0.2 ~ Items
particle poof ~ ~ ~ 0.4 0.4 0.4 0.03 30 normal
particle dust{color:[1.0f,0.929f,0.29f],scale:1.2f} ~ ~ ~ 0.4 0.4 0.4 0 20 normal
playsound minecraft:block.anvil.use block @a ~ ~ ~ 5 1.4
playsound minecraft:entity.villager.work_fletcher block @a ~ ~ ~ 5 1.2
playsound minecraft:block.grindstone.use block @a ~ ~ ~ 5 0.7 1
playsound minecraft:item.axe.wax_off block @a ~ ~ ~ 5 0.7 1