execute if entity @s[tag=nitSiteEast] run place template nitk:town/home ~15 ~-3 ~7 180

execute if entity @s[tag=nitSiteWest] run place template nitk:town/home ~-15 ~-3 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/home ~7 ~-3 ~-15 clockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/home ~-7 ~-3 ~15 counterclockwise_90

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-home