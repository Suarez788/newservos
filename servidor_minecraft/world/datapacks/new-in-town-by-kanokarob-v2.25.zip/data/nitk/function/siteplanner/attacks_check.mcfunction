###Establishes id matches for hell attack sites###
function nitk:id_match_town_planner

###Increases the Hell attack danger count, then performs matching attack###
scoreboard players add @e[tag=nitHellSite,tag=nitID_match] nitHellAttacks 1

###Increases siteplanning count on player for advancement purposes###
scoreboard players add @a[distance=..50,tag=nitCitizen] nitSiteCraft 1
advancement grant @a[scores={nitSiteCraft=8..}] only nitk:nitk/hamlet siteplanner-8