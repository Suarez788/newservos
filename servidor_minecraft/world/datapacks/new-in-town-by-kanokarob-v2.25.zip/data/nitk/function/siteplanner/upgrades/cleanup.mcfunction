execute as @e[tag=nitkLampPost,distance=..20] at @s run function nitk:recurs/power_station/lamppost_update
function nitk:recurs/roads/road_update
tag @s add nitUpgraded