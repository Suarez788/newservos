###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsEast,tag=nitKWallPlanner] run place template nitk:wallplanner_e ~15 ~ ~
execute if entity @s[tag=!nitSiteExistsNorth,tag=nitKWallPlanner] if block ~ ~ ~2 stone_bricks run place template nitk:wallplanner_n ~6 ~ ~-5
execute if entity @s[tag=!nitSiteExistsNorth,tag=nitKWallPlanner] if block ~ ~ ~-2 stone_bricks run place template nitk:wallplanner_n ~10 ~ ~-9
execute if entity @s[tag=!nitSiteExistsSouth,tag=nitKWallPlanner] if block ~ ~ ~2 stone_bricks run place template nitk:wallplanner_s ~10 ~ ~9
execute if entity @s[tag=!nitSiteExistsSouth,tag=nitKWallPlanner] if block ~ ~ ~-2 stone_bricks run place template nitk:wallplanner_s ~6 ~ ~5

execute if entity @s[tag=!nitSiteExistsNorth,tag=!nitKWallPlanner] run place template nitk:wallplanner_n ~6 ~ ~-7
execute if entity @s[tag=!nitSiteExistsSouth,tag=!nitKWallPlanner] run place template nitk:wallplanner_s ~6 ~ ~7