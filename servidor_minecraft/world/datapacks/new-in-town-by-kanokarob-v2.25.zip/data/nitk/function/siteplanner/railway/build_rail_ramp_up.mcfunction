execute if entity @s[tag=nitSiteEast] run place template nitk:railway/rail_ramp ~1 ~ ~-3

execute if entity @s[tag=nitSiteWest] run place template nitk:railway/rail_ramp ~-1 ~ ~3 180

execute if entity @s[tag=nitSiteNorth] run place template nitk:railway/rail_ramp ~-3 ~ ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:railway/rail_ramp ~3 ~ ~1 clockwise_90

execute if entity @s[tag=nitSiteEast] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteEast] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest] run tag @s add nitSiteExistsNorth
execute if entity @s[tag=nitSiteWest] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteNorth] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth] run tag @s add nitSiteExistsEast
execute if entity @s[tag=nitSiteSouth] run tag @s add nitSiteExistsWest
execute positioned ~ ~6 ~ run function nitk:siteplanner/new_rails_check