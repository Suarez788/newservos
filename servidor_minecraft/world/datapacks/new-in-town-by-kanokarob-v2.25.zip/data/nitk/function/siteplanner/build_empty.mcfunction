execute if entity @s[tag=nitSiteEast] run place template nitk:town/empty ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest] run place template nitk:town/empty ~-15 ~-3 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/empty ~-7 ~-3 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/empty ~-7 ~-3 ~1

function nitk:siteplanner/new_sites_check