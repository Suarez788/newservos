###Builds the upgrade with the same rotation as the original###
execute positioned ~-1 ~ ~ if entity @e[tag=nitRotation,distance=..0.5] run place template nitk:upgrades/tap_mine ~8 ~-8 ~7 180

execute positioned ~1 ~ ~ if entity @e[tag=nitRotation,distance=..0.5] run place template nitk:upgrades/tap_mine ~-8 ~-8 ~-7

execute positioned ~ ~ ~1 if entity @e[tag=nitRotation,distance=..0.5] run place template nitk:upgrades/tap_mine ~7 ~-8 ~-8 clockwise_90

execute positioned ~ ~ ~-1 if entity @e[tag=nitRotation,distance=..0.5] run place template nitk:upgrades/tap_mine ~-7 ~-8 ~8 counterclockwise_90

###Moves and Promotes the Miner###
tp @e[tag=nitMiner,limit=1,sort=nearest] @e[tag=nitMinerSpot,limit=1,sort=nearest]
data modify entity @e[tag=nitMiner,limit=1,sort=nearest] CustomName set value {"translate":"nitk.name.mine_foremand","fallback":"Mine Foreman"}

###Miner setup###
execute as @e[tag=nitCitizen,distance=..20] at @s run function nitk:id_set_town_planner
function nitk:id_match_town_planner
execute if entity @e[tag=nitStoneStor,tag=nitAtSilo] run tag @e[tag=nitMiner,tag=nitID_match] add nitAtSilo

###Cleanup###
function nitk:siteplanner/upgrades/cleanup