function nitk:siteplanner/large_site_check

execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run place template nitk:town/railway ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run place template nitk:town/railway ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run place template nitk:town/railway ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run place template nitk:town/railway ~7 ~-3 ~1 clockwise_90

execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] positioned ~15 ~ ~ run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] positioned ~-15 ~ ~ run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] positioned ~ ~ ~-15 run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] positioned ~ ~ ~15 run function nitk:siteplanner/new_rails_check
execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/attacks_check
execute if entity @s[tag=nitLargeSite] run advancement grant @a[distance=..20] only nitk:nitk/complete_town build-railway


execute if entity @s[tag=!nitLargeSite] run tellraw @a[distance=..20] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.large_site.warning","fallback":"Not enough room for structure at this site.","color":"white","bold":false}]

execute if entity @s[tag=nitLargeSite] run function nitk:debug/update_all
execute if entity @s[tag=nitLargeSite] run kill @e[tag=nitTownPlanner]