function nitk:siteplanner/large_site_check
execute if entity @s[tag=nitLargeSite] run give @p bucket

execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] run place template nitk:town/mooshroom_habitat ~1 ~-3 ~-7

execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] run place template nitk:town/mooshroom_habitat ~-1 ~-3 ~7 180

execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] run place template nitk:town/mooshroom_habitat ~-7 ~-3 ~-1 counterclockwise_90

execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] run place template nitk:town/mooshroom_habitat ~7 ~-3 ~1 clockwise_90

execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteEast,tag=nitLargeSite] positioned ~15 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteWest,tag=nitLargeSite] positioned ~-15 ~ ~ run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteNorth,tag=nitLargeSite] positioned ~ ~ ~-15 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitSiteSouth,tag=nitLargeSite] positioned ~ ~ ~15 run function nitk:siteplanner/new_sites_check
execute if entity @s[tag=nitLargeSite] run function nitk:siteplanner/attacks_check
execute if entity @s[tag=nitLargeSite] run execute as @e[tag=nitVisitorMooshroom,limit=1,sort=nearest,distance=..250] at @s run function nitk:recurs/town_square/mooshroom_banish
execute if entity @s[tag=nitLargeSite] run tellraw @a[distance=..10] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.mooshroom.thanks","fallback":"The Mooshroom Herd has moved into your new site!","color":"white","bold":false}]


execute if entity @s[tag=!nitLargeSite] run tellraw @a[distance=..20] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.large_site.warning","fallback":"Not enough room for structure at this site.","color":"white","bold":false}]