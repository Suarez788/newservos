###Destroys adjacent defunct site planners###
execute positioned ~-17 ~-16 ~-9 run tag @e[tag=nitKSitePlanner,tag=!nitKBankPlanner,tag=!nitKCastlePlanner,tag=!nitPortalPlanner,dx=17,dz=18,dy=21] add nitKilled

###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsWest] run place template nitk:railplanner_w ~-15 ~ ~

execute if entity @s[tag=!nitSiteExistsNorth] run place template nitk:railplanner_n ~-8 ~ ~-7

execute if entity @s[tag=!nitSiteExistsSouth] run place template nitk:railplanner_s ~-8 ~ ~7