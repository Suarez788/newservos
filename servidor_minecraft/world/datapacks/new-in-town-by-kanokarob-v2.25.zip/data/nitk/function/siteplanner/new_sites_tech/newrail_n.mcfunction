###Destroys adjacent defunct site planners###
execute positioned ~-9 ~-16 ~-17 run tag @e[tag=nitSitePlanner,tag=!nitKBankPlanner,tag=!nitKCastlePlanner,tag=!nitPortalPlanner,dx=18,dz=17,dy=21] add nitKilled

###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsNorth] run place template nitk:railplanner_n ~ ~ ~-15

execute if entity @s[tag=!nitSiteExistsEast] run place template nitk:railplanner_e ~7 ~ ~-8

execute if entity @s[tag=!nitSiteExistsWest] run place template nitk:railplanner_w ~-7 ~ ~-8