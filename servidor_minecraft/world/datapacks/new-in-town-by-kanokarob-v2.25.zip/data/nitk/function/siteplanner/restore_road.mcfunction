execute if block ~ ~-1 ~ #minecraft:dirt run setblock ~ ~-1 ~ dirt_path
scoreboard players operation @s nitRoadType = @e[tag=nitKTR,limit=1,sort=nearest,distance=..300] nitRoadType
execute if score @s nitRoadType matches 2 run setblock ~ ~-1 ~ spruce_planks
execute if score @s nitRoadType matches 3 run setblock ~ ~-1 ~ mud_bricks
execute if score @s nitRoadType matches 4 run setblock ~ ~-1 ~ cobbled_deepslate