###Creates new siteplanners for unoccupied sites adjacent to site newly constructed to the east###
execute positioned ~16 ~ ~-7 as @s[tag=nitSiteEast] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsEast
execute positioned ~1 ~ ~-22 as @s[tag=nitSiteEast] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsNorth
execute positioned ~1 ~ ~8 as @s[tag=nitSiteEast] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteEast] run function nitk:siteplanner/new_sites_tech/newsite_e

###Creates new siteplanners for unoccupied sites adjacent to site newly constructed to the west###
execute positioned ~-30 ~ ~-7 as @s[tag=nitSiteWest] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsWest
execute positioned ~-15 ~ ~-22 as @s[tag=nitSiteWest] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsNorth
execute positioned ~-15 ~ ~8 as @s[tag=nitSiteWest] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsSouth
execute if entity @s[tag=nitSiteWest] run function nitk:siteplanner/new_sites_tech/newsite_w

###Creates new siteplanners for unoccupied sites adjacent to site newly constructed to the north###
execute positioned ~-7 ~ ~-30 as @s[tag=nitSiteNorth] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsNorth
execute positioned ~8 ~ ~-15 as @s[tag=nitSiteNorth] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsEast
execute positioned ~-22 ~ ~-15 as @s[tag=nitSiteNorth] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteNorth] run function nitk:siteplanner/new_sites_tech/newsite_n

###Creates new siteplanners for unoccupied sites adjacent to site newly constructed to the south###
execute positioned ~-7 ~ ~16 as @s[tag=nitSiteSouth] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsSouth
execute positioned ~8 ~ ~1 as @s[tag=nitSiteSouth] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsEast
execute positioned ~-22 ~ ~1 as @s[tag=nitSiteSouth] if entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitSiteExistsWest
execute if entity @s[tag=nitSiteSouth] run function nitk:siteplanner/new_sites_tech/newsite_s

###Removes existing site tags for re-evaluation###
tag @s remove nitSiteExistsEast
tag @s remove nitSiteExistsWest
tag @s remove nitSiteExistsNorth
tag @s remove nitSiteExistsSouth

###Standard site prep and cleanup###
tag @a add nitCitizen
advancement grant @a[distance=..5,tag=nitCitizen,scores={nitTutorialStatus=1..}] only nitk:tutorial/build_site
tag @e[type=minecraft:villager,distance=..20] add nitCitizen
execute as @e[tag=nitCitizen,type=minecraft:villager,distance=..20] at @s run function nitk:id_set_town_planner
execute as @e[tag=nitkLampPost,distance=..20] at @s run function nitk:recurs/power_station/lamppost_update
execute as @e[tag=nitSite,distance=..20] at @s run function nitk:recurs/roads/road_update
tag @s add nitKilled
execute if entity @s[tag=nitSiteEast] run particle poof ~7 ~2 ~ 3 2 3 0.3 200 force
execute if entity @s[tag=nitSiteWest] run particle poof ~-7 ~2 ~ 3 2 3 0.3 200 force
execute if entity @s[tag=nitSiteNorth] run particle poof ~ ~2 ~-7 3 2 3 0.3 200 force
execute if entity @s[tag=nitSiteSouth] run particle poof ~ ~2 ~7 3 2 3 0.3 200 force
playsound minecraft:block.anvil.use block @a[distance=..32] ~ ~ ~ 2 0.7
playsound minecraft:entity.villager.work_fletcher block @a[distance=..32] ~ ~ ~ 2 0.5
playsound minecraft:block.chest.locked block @a[distance=..32] ~ ~ ~ 2 0.7 1
playsound minecraft:block.chest.open block @a[distance=..32] ~ ~ ~ 2 0.7 1