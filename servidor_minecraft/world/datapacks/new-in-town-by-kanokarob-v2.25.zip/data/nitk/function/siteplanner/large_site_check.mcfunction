execute if entity @s[tag=nitSiteEast] positioned ~16 ~ ~-7 unless entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteWest] positioned ~-30 ~ ~-7 unless entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteNorth] positioned ~-7 ~ ~-30 unless entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitLargeSite
execute if entity @s[tag=nitSiteSouth] positioned ~-7 ~ ~16 unless entity @e[tag=nitSite,dx=15,y=-64,dy=312,dz=15] run tag @s add nitLargeSite