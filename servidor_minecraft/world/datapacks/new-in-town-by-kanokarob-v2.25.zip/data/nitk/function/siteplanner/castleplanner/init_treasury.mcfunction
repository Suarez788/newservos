advancement revoke @s only nitk:recipes/castle/recipe_treasury

execute as @e[tag=nitKCastlePlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function nitk:siteplanner/castleplanner/build_treasury