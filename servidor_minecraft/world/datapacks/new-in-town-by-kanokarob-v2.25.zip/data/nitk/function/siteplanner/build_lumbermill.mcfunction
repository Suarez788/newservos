give @p bucket

execute if entity @s[tag=nitSiteEast] run place template nitk:town/lumbermill ~15 ~-3 ~7 180

execute if entity @s[tag=nitSiteWest] run place template nitk:town/lumbermill ~-15 ~-3 ~-7

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/lumbermill ~7 ~-3 ~-15 clockwise_90

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/lumbermill ~-7 ~-3 ~15 counterclockwise_90

function nitk:siteplanner/new_sites_check
function nitk:siteplanner/attacks_check
advancement grant @a[distance=..20] only nitk:nitk/complete_town build-lumbermill
advancement grant @a[distance=..6] only nitk:tutorial/build_resource_sites build-lumbermill

execute as @e[tag=nitCitizen,distance=..20] at @s run function nitk:id_set_town_planner
function nitk:id_match_town_planner
execute if entity @e[tag=nitLumberStor,tag=nitID_match,tag=nitAtSilo] run tag @e[tag=nitLumberer,tag=nitID_match] add nitAtSilo