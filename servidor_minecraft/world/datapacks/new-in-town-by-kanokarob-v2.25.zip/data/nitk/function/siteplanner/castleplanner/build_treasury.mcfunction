place template nitk:town/castle/ft_treasury ~-5 ~-1 ~-5

function nitk:siteplanner/castleplanner/castle_cleanup