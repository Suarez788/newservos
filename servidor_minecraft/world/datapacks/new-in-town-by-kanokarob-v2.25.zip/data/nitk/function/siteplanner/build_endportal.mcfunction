execute if entity @s[tag=nitSiteEast] run place template nitk:town/refugee_endportal ~15 ~-3 ~-7 clockwise_90

execute if entity @s[tag=nitSiteWest] run place template nitk:town/refugee_endportal ~-15 ~-3 ~7 counterclockwise_90

execute if entity @s[tag=nitSiteNorth] run place template nitk:town/refugee_endportal ~-7 ~-3 ~-15

execute if entity @s[tag=nitSiteSouth] run place template nitk:town/refugee_endportal ~7 ~-3 ~15 180

function nitk:siteplanner/new_sites_check