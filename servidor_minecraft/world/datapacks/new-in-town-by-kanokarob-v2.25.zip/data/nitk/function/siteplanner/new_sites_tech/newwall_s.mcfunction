###Sets new site planners at available positions###
execute if entity @s[tag=!nitSiteExistsSouth,tag=nitKWallPlanner] run place template nitk:wallplanner_s ~ ~ ~15
execute if entity @s[tag=!nitSiteExistsEast,tag=nitKWallPlanner] if block ~2 ~ ~ stone_bricks run place template nitk:wallplanner_e ~9 ~ ~10
execute if entity @s[tag=!nitSiteExistsEast,tag=nitKWallPlanner] if block ~-2 ~ ~ stone_bricks run place template nitk:wallplanner_e ~5 ~ ~6
execute if entity @s[tag=!nitSiteExistsWest,tag=nitKWallPlanner] if block ~2 ~ ~ stone_bricks run place template nitk:wallplanner_w ~-5 ~ ~6
execute if entity @s[tag=!nitSiteExistsWest,tag=nitKWallPlanner] if block ~-2 ~ ~ stone_bricks run place template nitk:wallplanner_w ~-9 ~ ~10

execute if entity @s[tag=!nitSiteExistsEast,tag=!nitKWallPlanner] run place template nitk:wallplanner_e ~7 ~ ~6
execute if entity @s[tag=!nitSiteExistsWest,tag=!nitKWallPlanner] run place template nitk:wallplanner_w ~-7 ~ ~6