place template nitk:town/castle/ft_stable ~-5 ~-1 ~-5

execute at @e[tag=nitStableHorse,limit=2,sort=nearest] run summon horse ~ ~ ~

function nitk:siteplanner/castleplanner/castle_cleanup