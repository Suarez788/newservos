###Update the bossbar###
execute store result score @s nitRaidProg run execute if entity @e[tag=nitRaidMob,distance=..100]
execute store result bossbar nitk:town_square_raid value run scoreboard players get @s nitRaidProg

###Victory effects###
execute if entity @s[scores={nitRaidProg=..0}] run function nitk:recurs/town_square/raid_victory
execute if entity @s[scores={nitRaidProg=..0}] run tag @s remove nitRaid
scoreboard players reset @s[scores={nitRaidProg=..0}] nitRaidProg