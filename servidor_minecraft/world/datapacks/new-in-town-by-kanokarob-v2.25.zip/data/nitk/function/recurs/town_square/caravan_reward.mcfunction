###Remove bounty###
execute as @e[type=item,distance=..2,predicate=nitk:on_ground,predicate=nitk:item_gold_ingot_stack] at @s run function nitk:recurs/town_square/item_consume
execute anchored eyes run particle happy_villager ^ ^ ^ 0.3 0.3 0.3 0 5 normal
playsound entity.villager.celebrate neutral @a ~ ~ ~ 3 1
tellraw @a[distance=..10] [{"translate":"nitk.town_square.nomad","fallback":"[Nomadic Caravan]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.thanks","fallback":"Your generosity is appreciated! Please, enjoy my selection.","color":"white","bold":false}]

###Drops loot and leaves###
loot spawn ^ ^0.5 ^1 loot nitk:command/caravan_reward
particle happy_villager ~ ~1 ~ 0.3 0.5 0.3 0 10 normal
particle poof ~ ~1 ~ 0.3 0.5 0.3 0 10 normal
scoreboard players set @e[tag=nitTownSquare,limit=1,sort=nearest] nitResourceSpawn 0
tp @s ~ -100 ~
kill @s