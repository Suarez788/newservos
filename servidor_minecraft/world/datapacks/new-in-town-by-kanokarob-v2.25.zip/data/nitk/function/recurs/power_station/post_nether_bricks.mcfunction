advancement revoke @s only nitk:power_station/post_nether_bricks
clear @s nether_brick_wall[custom_data={nitk_post:7b}]
scoreboard players set @e[tag=nitPostSeller,limit=1,sort=nearest] nitPostType 7

###Performs update###
function nitk:recurs/power_station/posts_update