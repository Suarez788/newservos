###Provides reward loot###
loot give @s loot nitk:command/adventure_reward
playsound entity.experience_orb.pickup player @s ~ ~ ~ 3 1

###Provides XP based on quest###
execute if entity @s[advancements={nitk:adventure/ancient_city_complete=true}] run xp add @s 200 points
execute if entity @s[advancements={nitk:adventure/buried_treasure_complete=true}] run xp add @s 20 points
execute if entity @s[advancements={nitk:adventure/cave_spider_complete=true}] run xp add @s 20 points
execute if entity @s[advancements={nitk:adventure/conduit_complete=true}] run xp add @s 100 points
execute if entity @s[advancements={nitk:adventure/dungeon_complete=true}] run xp add @s 20 points
execute if entity @s[advancements={nitk:adventure/elder_guardian_complete=true}] run xp add @s 200 points
execute if entity @s[advancements={nitk:adventure/evoker_complete=true}] run xp add @s 350 points
execute if entity @s[advancements={nitk:adventure/gapple_complete=true}] run xp add @s 100 points
execute if entity @s[advancements={nitk:adventure/igloo_complete=true}] run xp add @s 50 points
execute if entity @s[advancements={nitk:adventure/iron_golem_complete=true}] run xp add @s 50 points
execute if entity @s[advancements={nitk:adventure/jungle_pyramid_complete=true}] run xp add @s 50 points
execute if entity @s[advancements={nitk:adventure/mushroom_complete=true}] run xp add @s 200 points
execute if entity @s[advancements={nitk:adventure/music_disc_complete=true}] run xp add @s 50 points
execute if entity @s[advancements={nitk:adventure/piglin_brute_complete=true}] run xp add @s 100 points
execute if entity @s[advancements={nitk:adventure/stronghold_library_complete=true}] run xp add @s 20 points
execute if entity @s[advancements={nitk:adventure/trident_complete=true}] run xp add @s 500 points
execute if entity @s[advancements={nitk:adventure/witch_complete=true}] run xp add @s 20 points