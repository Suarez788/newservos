execute if entity @a[distance=..3,predicate=nitk:on_ground] run setblock ~ ~ ~ nether_bricks
execute unless entity @a[distance=..3,predicate=nitk:on_ground] run setblock ~ ~ ~ redstone_block