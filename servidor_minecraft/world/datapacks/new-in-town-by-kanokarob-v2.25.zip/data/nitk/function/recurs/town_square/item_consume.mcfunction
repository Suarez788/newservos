particle poof ~ ~0.2 ~ 0.1 0.1 0.1 0.1 10 normal
kill @s