###Removes bounty###
execute as @e[type=item,distance=..4,predicate=nitk:on_ground,predicate=nitk:item_gold_block_stack] at @s run function nitk:recurs/town_square/item_consume
execute anchored eyes run particle happy_villager ^ ^ ^ 0.3 0.3 0.3 0 5 normal
playsound entity.piglin.celebrate neutral @a ~ ~ ~ 3 1

###Removes visitor###
particle large_smoke ~ ~ ~ 0.5 0.5 0.5 0 20 normal
tellraw @a[distance=..10] [{"translate":"nitk.town_square.piglin","fallback":"[Piglin Posse]","color":"dark_red","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.piglin.thanks","fallback":"Oh boy, thanks for all the shinies! Guess we'll be on our way, then.","color":"white","bold":false}]
scoreboard players set @e[tag=nitTownSquare,limit=1,sort=nearest] nitResourceSpawn 0
tp @s ~ -100 ~
kill @s