effect give @a[distance=..1] minecraft:absorption 1 2
execute if entity @e[type=item,distance=..1,predicate=nitk:item_wither_rose] run tag @s add nitClearCondition
execute if entity @s[tag=nitClearCondition] run effect give @a[distance=..10] bad_omen 60 1
execute if entity @s[tag=nitClearCondition] run kill @e[type=item,distance=..1,predicate=nitk:item_wither_rose]
tag @s remove nitClearCondition