advancement revoke @s only nitk:power_station/lights_glowstone
clear @s glowstone[custom_data={nitk_light:6b}]
scoreboard players set @e[tag=nitLightSeller,limit=1,sort=nearest] nitLightType 6

###Performs update###
function nitk:recurs/power_station/lights_update