###Consume resources###
setblock ~ ~ ~ cauldron
fill ~-3 ~1 ~ ~-3 ~1 ~ air replace hay_block
fill ~3 ~1 ~ ~3 ~1 ~ air replace hay_block
fill ~ ~1 ~-3 ~ ~1 ~-3 air replace hay_block
fill ~ ~1 ~3 ~ ~1 ~3 air replace hay_block

###Summon Mobs###
summon chicken ~-3 ~0.5 ~-2 {Age:-24000}
scoreboard players remove @s nitResourceSpawn 2
execute if score @s nitResourceSpawn matches 2.. run function nitk:recurs/pasture/chicken