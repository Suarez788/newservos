###Randomly determines the meteor type and spreads it safely###
execute store result score @s nitRandom run random value 0..99
scoreboard players set @s nitSpreadLim 0
execute at @s positioned ~-8 ~ ~-8 if entity @e[tag=nitSite,dx=16,dz=16,y=-64,dy=312] run function nitk:spread_hell_2
execute at @s run function nitk:special/special_gen_ground

###Generates the correct meteor structure block###
execute if score @s nitRandom matches 0..24 at @s run place template nitk:meteor/iron ~-4 ~-5 ~-4
execute if score @s nitRandom matches 25..44 at @s run place template nitk:meteor/gold ~-4 ~-5 ~-4
execute if score @s nitRandom matches 45..59 at @s run place template nitk:meteor/redstone ~-4 ~-5 ~-4
execute if score @s nitRandom matches 60..79 at @s run place template nitk:meteor/slime ~-4 ~-5 ~-4
execute if score @s nitRandom matches 80..84 at @s run place template nitk:meteor/deep ~-4 ~-5 ~-4
execute if score @s nitRandom matches 85..89 at @s run place template nitk:meteor/alien ~-4 ~-5 ~-4
execute if score @s nitRandom matches 90..94 at @s run place template nitk:meteor/end ~-4 ~-5 ~-4
execute if score @s nitRandom matches 95..99 at @s run place template nitk:meteor/nether ~-4 ~-5 ~-4

###Marks the meteor as generated###
tag @s add nitGenerated