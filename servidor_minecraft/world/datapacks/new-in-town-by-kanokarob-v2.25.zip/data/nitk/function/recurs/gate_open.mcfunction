scoreboard players set @s nitSuccess 0
playsound block.piston.contract block @a ~ ~ ~ 1 1

execute if block ~ ~ ~ lever[facing=west] run fill ~2 ~-1 ~1 ~2 ~1 ~3 air replace iron_bars
execute if block ~ ~ ~ lever[facing=east] run fill ~-2 ~-1 ~-1 ~-2 ~1 ~-3 air replace iron_bars
execute if block ~ ~ ~ lever[facing=south] run fill ~1 ~-1 ~-2 ~3 ~1 ~-2 air replace iron_bars
execute if block ~ ~ ~ lever[facing=north] run fill ~-1 ~-1 ~2 ~-3 ~1 ~2 air replace iron_bars