###Assigns player root advancement and revokes interaction advancement###
advancement grant @s only nitk:adventure/root
advancement revoke @s only nitk:adventure/adventurer_interact

###Check for completed quest###
scoreboard players add @s nitSuccess 0
execute if entity @s[advancements={nitk:adventure/ancient_city_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/buried_treasure_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/cave_spider_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/conduit_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/dungeon_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/elder_guardian_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/evoker_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/gapple_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/igloo_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/iron_golem_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/jungle_pyramid_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/mushroom_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/music_disc_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/piglin_brute_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/snow_golem_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/stronghold_library_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/trident_complete=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/witch_complete=true}] run scoreboard players add @s nitSuccess 1

###Grants reward if successful quest###
execute if score @s nitSuccess matches 1.. run function nitk:recurs/adventure/rewards

###Revokes quest and complete advancements if succussful quest###
execute if score @s nitSuccess matches 1.. run advancement revoke @s from nitk:adventure/technical_kill_quest
execute if score @s nitSuccess matches 1.. run advancement revoke @s from nitk:adventure/technical_location_quest
execute if score @s nitSuccess matches 1.. run advancement revoke @s from nitk:adventure/technical_loot_quest
execute if score @s nitSuccess matches 1.. run advancement revoke @s from nitk:adventure/technical_other_quest

###Resets player success###
scoreboard players reset @s nitSuccess

###Checks if player already has an incomplete quest###
scoreboard players add @s nitSuccess 0
execute if entity @s[advancements={nitk:adventure/ancient_city_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/buried_treasure_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/cave_spider_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/conduit_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/dungeon_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/elder_guardian_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/evoker_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/gapple_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/igloo_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/iron_golem_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/jungle_pyramid_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/mushroom_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/music_disc_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/piglin_brute_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/snow_golem_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/stronghold_library_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/trident_quest=true}] run scoreboard players add @s nitSuccess 1
execute if entity @s[advancements={nitk:adventure/witch_quest=true}] run scoreboard players add @s nitSuccess 1

###Assigns new random quest###
execute as @e[tag=nitAdventurer,limit=1,sort=nearest] run function nitk:recurs/adventure/random_quest

###Informs of new quest###
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/ancient_city_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.ancient_city","fallback":"Your new quest is to find an Ancient City.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/buried_treasure_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.buried_treasure","fallback":"Your new quest is to find Buried Treasure.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/cave_spider_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.cave_spider","fallback":"Your new quest is to slay a Cave Spider in a Mineshaft.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/conduit_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.conduit","fallback":"Your new quest is to collect a Conduit.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/dungeon_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.dungeon","fallback":"Your new quest is to find loot in a Dungeon chest.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/elder_guardian_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.elder_guardian","fallback":"Your new quest is to slay an Elder Guardian in an Ocean Monument.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/evoker_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.evoker","fallback":"Your new quest is to slay an Evoker in a Woodland Mansion.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/gapple_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.gapple","fallback":"Your new quest is to collect an Enchanted Golden Apple.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/igloo_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.igloo","fallback":"Your new quest is to find a secret chest in an Igloo.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/iron_golem_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.iron_golem","fallback":"Your new quest is to summon an Iron Golem in a village.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/jungle_pyramid_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.jungle_pyramid","fallback":"Your new quest is to find loot in a Jungle Pyramid.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/mushroom_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.mushroom","fallback":"Your new quest is to find a Mushroom Island and explore its Mushroom Fields.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/music_disc_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.music_disc","fallback":"Your new quest is to collect any Music Disc.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/piglin_brute_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.piglin_brute","fallback":"Your new quest is to slay a Piglin Brute in a Bastion Remnant.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/snow_golem_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.snow_golem","fallback":"Your new quest is to summon a Snow Golem in a snowy Village.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/stronghold_library_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.stronghold_library","fallback":"Your new quest is to find loot in a Stronghold Library.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/trident_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.trident","fallback":"Your new quest is to collect a Trident.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run tellraw @s[advancements={nitk:adventure/witch_quest=true}] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.quest.witch","fallback":"Your new quest is to slay a Witch in a Swamp Hut.","color":"white","bold":false}]
execute if score @s nitSuccess matches 0 run playsound ui.cartography_table.take_result neutral @s ~ ~ ~ 3 1

execute if score @s nitSuccess matches 1.. run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.reminder","fallback":"Forgotten your quest? Check the \"New in Town Quests\" advancement tab.","color":"white","bold":false}]
execute if score @s nitSuccess matches 1.. run playsound item.book.page_turn neutral @s ~ ~ ~ 3 1

###Resets player success###
scoreboard players reset @s nitSuccess