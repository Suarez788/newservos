tp @e[tag=nitVisitor,limit=1,sort=nearest] ~ -100 ~
kill @e[tag=nitVisitor,limit=1,sort=nearest]
execute if entity @a[tag=nitCitizen,distance=..100] run function nitk:recurs/town_square/raid_prepare
scoreboard players set @s nitResourceSpawn 0
scoreboard players set @s nitResourceTime 0