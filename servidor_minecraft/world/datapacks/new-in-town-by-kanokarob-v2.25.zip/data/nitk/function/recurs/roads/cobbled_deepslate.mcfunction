advancement revoke @s only nitk:roads/cobbled_deepslate
clear @s cobbled_deepslate[custom_data={nitk_road:4b}]
scoreboard players set @e[tag=nitKTR,limit=1,sort=nearest] nitRoadType 4

###Performs update###
execute as @e[tag=nitSite,distance=..300] at @s run function nitk:recurs/roads/road_update
tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.roads.pave","fallback":"Your towns roads have been re-paved as far as they can.","color":"white","bold":false}]