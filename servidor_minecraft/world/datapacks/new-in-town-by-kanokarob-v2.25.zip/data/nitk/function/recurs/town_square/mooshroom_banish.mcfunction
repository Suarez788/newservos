###Removes bounty###
execute anchored eyes run particle happy_villager ^ ^ ^ 0.3 0.3 0.3 0 5 normal
playsound entity.cow.ambient neutral @a ~ ~ ~ 3 1

###Removes visitor###
particle poof ~ ~ ~ 0.5 0.5 0.5 0 20 normal
scoreboard players set @e[tag=nitTownSquare,limit=1,sort=nearest] nitResourceSpawn 0
tp @s ~ -100 ~
kill @s