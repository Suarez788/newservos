tag @s add nitAngry
damage @s 0.0 generic by @a[distance=..100,limit=1,sort=random]