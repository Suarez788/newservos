execute if block ~ ~ ~ water_cauldron[level=3] if block ~-3 ~1 ~ hay_block run tag @s add nitSuccess
execute if block ~ ~ ~ water_cauldron[level=3] if block ~3 ~1 ~ hay_block run tag @s add nitSuccess
execute if block ~ ~ ~ water_cauldron[level=3] if block ~ ~1 ~-3 hay_block run tag @s add nitSuccess
execute if block ~ ~ ~ water_cauldron[level=3] if block ~ ~1 ~3 hay_block run tag @s add nitSuccess
execute if entity @s[tag=nitSuccess] run function nitk:recurs/pasture/count
tag @s remove nitSuccess