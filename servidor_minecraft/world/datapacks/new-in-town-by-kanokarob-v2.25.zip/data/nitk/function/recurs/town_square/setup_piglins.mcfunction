###Prepare central entity and set bossbar stats###
tag @s add nitRaid
tag @s add nitRaidPiglin
bossbar add nitk:town_square_raid "Town Square Raid"
bossbar set nitk:town_square_raid name {"translate":"nitk.town_square.raid.piglin","fallback":"Piglin Posse Attack","color":"dark_red"}
bossbar set nitk:town_square_raid color red
bossbar set nitk:town_square_raid style notched_12
bossbar set nitk:town_square_raid visible true
bossbar set nitk:town_square_raid players @a[tag=nitCitizen,distance=..100]
scoreboard players add @s nitRaidProg 0
team add nitRaidMobs {"text":"Settlement Raid Mobs","color":"dark_red"}
team modify nitRaidMobs color dark_red

###Summon enemy mobs###
execute as @e[tag=nitSite,limit=24,sort=nearest,distance=..100] run summon piglin_brute ~ ~ ~ {IsImmuneToZombification:1b,Tags:[nitEntity,smithed.entity,smithed.strict,nitRaidMob],CustomName:{"translate":"nitk.name.piglin","fallback":"Piglin Ruffian","color":"dark_red"},attributes:[{id:"minecraft:max_health",base:30.0}],Health:30.0f,Team:"nitRaidMobs",active_effects:[{id:"minecraft:glowing",duration:999999}],equipment:{"mainhand":{id:"minecraft:golden_axe",count:1}},drop_chances:{"mainhand":0.0f},PersistenceRequired:1b}
execute store result score @s nitRaidProg run execute if entity @e[tag=nitRaidMob,distance=..100]
execute store result bossbar nitk:town_square_raid max run scoreboard players get @s nitRaidProg
execute store result bossbar nitk:town_square_raid value run scoreboard players get @s nitRaidProg
spreadplayers ~ ~ 5 40 false @e[tag=nitRaidMob,distance=..100]