###Gives Slow Falling###
execute unless entity @s[predicate=nitk:slow_fall] run playsound minecraft:entity.warden.sonic_charge block @a ~ ~-8 ~ 2 0.6
effect give @s slow_falling 1 1 true