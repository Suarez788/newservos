###Sets road type###
scoreboard players add @s nitRoadType 0
scoreboard players operation @s nitRoadType = @e[tag=nitKTR,limit=1,sort=nearest] nitRoadType

###Fills in Roads###
execute if score @s nitRoadType matches 1 run fill ~-7 ~-5 ~-7 ~7 ~12 ~7 dirt_path replace #nitk:road_blocks
execute if score @s nitRoadType matches 2 run fill ~-7 ~-5 ~-7 ~7 ~12 ~7 spruce_planks replace #nitk:road_blocks
execute if score @s nitRoadType matches 3 run fill ~-7 ~-5 ~-7 ~7 ~12 ~7 mud_bricks replace #nitk:road_blocks
execute if score @s nitRoadType matches 4 run fill ~-7 ~-5 ~-7 ~7 ~12 ~7 cobbled_deepslate replace #nitk:road_blocks