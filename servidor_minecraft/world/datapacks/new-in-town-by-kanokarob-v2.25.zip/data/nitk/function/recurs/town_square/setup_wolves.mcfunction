###Prepare central entity and set bossbar stats###
tag @s add nitRaid
tag @s add nitRaidWolf
bossbar add nitk:town_square_raid "Town Square Raid"
bossbar set nitk:town_square_raid name {"translate":"nitk.town_square.raid.wolf","fallback":"Wolf Pack Attack","color":"gray"}
bossbar set nitk:town_square_raid color white
bossbar set nitk:town_square_raid style notched_20
bossbar set nitk:town_square_raid visible true
bossbar set nitk:town_square_raid players @a[tag=nitCitizen,distance=..100]
scoreboard players set @s nitRaidProg 20
team add nitRaidMobs {"text":"Settlement Raid Mobs","color":"dark_red"}
team modify nitRaidMobs color dark_red

###Summon enemy mobs###
execute as @e[tag=nitSite,limit=20,sort=nearest,distance=..100] run summon wolf ~ ~ ~ {AngerTime:3000,Age:1,Tags:[nitEntity,smithed.entity,smithed.strict,nitRaidMob],CustomName:{"translate":"nitk.name.wolf","fallback":"Angry Wolf","color":"gray"},attributes:[{id:"minecraft:max_health",base:20.0}],Health:20.0f,Team:"nitRaidMobs",active_effects:[{id:"minecraft:glowing",duration:999999}],PersistenceRequired:1b}
execute as @e[tag=nitRaidMob,type=wolf,tag=!nitAngry] run function nitk:recurs/town_square/wolf_anger
execute store result score @s nitRaidProg run execute if entity @e[tag=nitRaidMob,distance=..100]
execute store result bossbar nitk:town_square_raid max run scoreboard players get @s nitRaidProg
execute store result bossbar nitk:town_square_raid value run scoreboard players get @s nitRaidProg
spreadplayers ~ ~ 5 40 false @e[tag=nitRaidMob]