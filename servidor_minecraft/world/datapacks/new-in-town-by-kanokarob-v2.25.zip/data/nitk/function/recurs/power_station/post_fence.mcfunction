advancement revoke @s only nitk:power_station/post_fence
clear @s oak_fence[custom_data={nitk_post:1b}]
scoreboard players set @e[tag=nitPostSeller,limit=1,sort=nearest] nitPostType 1

###Performs update###
function nitk:recurs/power_station/posts_update