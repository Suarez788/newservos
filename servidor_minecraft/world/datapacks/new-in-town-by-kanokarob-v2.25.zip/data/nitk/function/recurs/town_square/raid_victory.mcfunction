###Announce reward###
execute if entity @s[tag=nitRaidWolf] run tellraw @a[tag=nitCitizen,distance=..100] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.wolf.defeat","fallback":"The wolves have been defeated and are retreating with their tails between their legs! Collect your reward at the Town Square!","color":"white","bold":false}]
execute if entity @s[tag=nitRaidWitch] run tellraw @a[tag=nitCitizen,distance=..100] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.witch.defeat","fallback":"The Witch Coven has been defeated, and they've dropped much of their supplies at the Town Square!","color":"white","bold":false}]
execute if entity @s[tag=nitRaidPiglin] run tellraw @a[tag=nitCitizen,distance=..100] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.piglin.defeat","fallback":"The Piglin Posse is retreating to the Nether! They're in such a hurry, some items were left behind at the Town Square!","color":"white","bold":false}]
execute if entity @s[tag=nitRaidWolf] at @e[tag=nitTownSquare,limit=1,sort=nearest] run loot spawn ~ ~1 ~ loot nitk:command/wolf_reward
execute if entity @s[tag=nitRaidWitch] at @e[tag=nitTownSquare,limit=1,sort=nearest] run loot spawn ~ ~1 ~ loot nitk:command/witch_reward
execute if entity @s[tag=nitRaidPiglin] at @e[tag=nitTownSquare,limit=1,sort=nearest] run loot spawn ~ ~1 ~ loot nitk:command/piglin_reward

###Cleanup###
tag @s remove nitRaidWolf
tag @s remove nitRaidWitch
tag @s remove nitRaidPiglin
bossbar set nitk:town_square_raid visible false

###Cosmetics###
playsound ui.toast.challenge_complete player @a ~ ~ ~ 10 1
playsound entity.firework_rocket.launch player @a ~ ~ ~ 10 1
execute at @a[tag=nitCitizen,distance=..100] run particle totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.3 20 normal