advancement revoke @s only nitk:power_station/lights_fire
clear @s campfire[custom_data={nitk_light:5b}]
scoreboard players set @e[tag=nitLightSeller,limit=1,sort=nearest] nitLightType 5

###Performs update###
function nitk:recurs/power_station/lights_update