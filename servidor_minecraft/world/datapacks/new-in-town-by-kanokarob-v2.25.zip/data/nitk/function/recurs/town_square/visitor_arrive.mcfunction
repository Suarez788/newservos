###Select Visitor###
execute store result score @s nitResourceSpawn run random value 1..5

###Summon Visitor###
execute if entity @s[scores={nitResourceSpawn=1}] run summon wandering_trader ~ ~ ~ {Tags:[smithed.entity,smithed.strict,nitEntity,nitTicking,nitVisitor,nitVisitorCaravan],CustomName:{"translate":"nitk.town_square.visitor.nomad","fallback":"Nomad Caravan","color":"green"},NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Invulnerable:1b,Rotation:[90.0f,0.0f]}
execute if entity @s[scores={nitResourceSpawn=2}] run summon mooshroom ~ ~ ~ {Tags:[smithed.entity,smithed.strict,nitEntity,nitTicking,nitVisitor,nitVisitorMooshroom],CustomName:{"translate":"nitk.town_square.visitor.mooshroom","fallback":"Mooshroom Herd","color":"red"},NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Invulnerable:1b,Rotation:[90.0f,0.0f]}
execute if entity @s[scores={nitResourceSpawn=3}] run summon wolf ~ ~ ~ {Tags:[smithed.entity,smithed.strict,nitEntity,nitTicking,nitVisitor,nitVisitorWolf],CustomName:{"translate":"nitk.town_square.visitor.wolf","fallback":"Pack of Wolves","color":"gray"},NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Invulnerable:1b,Rotation:[90.0f,0.0f]}
execute if entity @s[scores={nitResourceSpawn=4}] run summon witch ~ ~ ~ {Tags:[smithed.entity,smithed.strict,nitEntity,nitTicking,nitVisitor,nitVisitorWitch],CustomName:{"translate":"nitk.town_square.visitor.witch","fallback":"Witch Coven","color":"dark_purple"},NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Invulnerable:1b,Rotation:[90.0f,0.0f]}
execute if entity @s[scores={nitResourceSpawn=5}] run summon piglin ~ ~ ~ {Tags:[smithed.entity,smithed.strict,nitEntity,nitTicking,nitVisitor,nitVisitorPiglin],CustomName:{"translate":"nitk.town_square.visitor.piglin","fallback":"Piglin Posse","color":"dark_red"},NoAI:1b,NoGravity:1b,PersistenceRequired:1b,Invulnerable:1b,Rotation:[90.0f,0.0f],IsImmuneToZombification:1b}
execute as @e[tag=nitVisitor,limit=1,sort=nearest] at @s facing entity @e[tag=nitFountainFace,limit=1,sort=nearest] feet run tp ~ ~ ~

###Anounces visitor###
execute if entity @s[scores={nitResourceSpawn=1..}] run tellraw @a[tag=nitCitizen,distance=..100] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.visitor_arrive","fallback":"A visitor has appeared at the stage of the Town Square!","color":"gold","bold":false}]
execute if entity @s[scores={nitResourceSpawn=1..}] run playsound event.raid.horn block @a ~ ~ ~ 10 2