advancement revoke @s only nitk:power_station/lights_torch
clear @s torch[custom_data={nitk_light:1b}]
scoreboard players set @e[tag=nitLightSeller,limit=1,sort=nearest] nitLightType 1

###Performs update###
function nitk:recurs/power_station/lights_update