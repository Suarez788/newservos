###Cows###
execute store result score @s nitResourceSpawn if entity @e[type=cow,distance=..12]
execute if score @s nitResourceSpawn matches 2.. run function nitk:recurs/pasture/cow

###Pigs###
execute store result score @s nitResourceSpawn if entity @e[type=pig,distance=..12]
execute if score @s nitResourceSpawn matches 2.. run function nitk:recurs/pasture/pig

###Sheep###
execute store result score @s nitResourceSpawn if entity @e[type=sheep,distance=..12]
execute if score @s nitResourceSpawn matches 2.. run function nitk:recurs/pasture/sheep
execute as @e[tag=nitNew,distance=..6] run data modify entity @s Color set from entity @e[type=sheep,tag=!nitNew,distance=..12,limit=1,sort=random] Color
tag @e[distance=..6] remove nitNew

###Chickens###
execute store result score @s nitResourceSpawn if entity @e[type=chicken,distance=..12]
execute if score @s nitResourceSpawn matches 2.. run function nitk:recurs/pasture/chicken