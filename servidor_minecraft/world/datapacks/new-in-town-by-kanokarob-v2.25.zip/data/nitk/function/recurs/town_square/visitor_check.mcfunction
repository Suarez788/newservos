###Adds requisite scores###
scoreboard players add @s nitResourceTime 1
scoreboard players set @s[scores={nitResourceTime=9..}] nitResourceTime 7

###Select visitor###
execute if entity @s[scores={nitResourceTime=7}] if entity @a[tag=nitCitizen,distance=..100] run function nitk:recurs/town_square/visitor_arrive

###Sends away visitor/triggers consequence###
execute if entity @s[scores={nitResourceTime=8}] run function nitk:recurs/town_square/visitor_depart