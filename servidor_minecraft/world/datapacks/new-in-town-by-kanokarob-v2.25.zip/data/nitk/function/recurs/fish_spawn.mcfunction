summon minecraft:cod ~ ~ ~ {PersistenceRequired:1b}
summon minecraft:cod ~ ~ ~ {PersistenceRequired:1b}
summon minecraft:cod ~ ~ ~ {PersistenceRequired:1b}
summon minecraft:cod ~ ~ ~ {PersistenceRequired:1b}