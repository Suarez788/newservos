###Gives Levitation###
stopsound @s block block.portal.trigger
playsound block.portal.trigger block @s ~ ~ ~ 0.6 1.4
effect give @s levitation 3 5 true