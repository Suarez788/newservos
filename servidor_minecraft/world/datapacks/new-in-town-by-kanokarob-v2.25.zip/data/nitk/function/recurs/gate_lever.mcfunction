scoreboard players add @s nitSuccess 0

execute if score @s nitSuccess matches 0 if block ~ ~ ~ minecraft:lever[powered=false] run function nitk:recurs/gate_close
execute if score @s nitSuccess matches 1 if block ~ ~ ~ minecraft:lever[powered=true] run function nitk:recurs/gate_open