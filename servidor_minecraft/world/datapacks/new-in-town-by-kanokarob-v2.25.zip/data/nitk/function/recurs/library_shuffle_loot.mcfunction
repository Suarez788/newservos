###Summons new enchantments via loot tables###
setblock ~ ~1 ~ hopper
loot insert ~ ~1 ~ loot nitk:command/library_shuffle

###Assigns new random 3rd trade###
data modify entity @s Offers.Recipes[2].sell set from block ~ ~1 ~ Items[0]

###Assigns new random 4th trade###
data modify entity @s Offers.Recipes[3].sell set from block ~ ~1 ~ Items[1]

###Assigns new random 5th trade###
data modify entity @s Offers.Recipes[4].sell set from block ~ ~1 ~ Items[2]

###Clears the hopper#
data remove block ~ ~1 ~ Items
setblock ~ ~1 ~ air