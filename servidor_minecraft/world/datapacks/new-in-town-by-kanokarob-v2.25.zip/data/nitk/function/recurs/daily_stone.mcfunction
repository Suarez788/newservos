summon minecraft:item ~ ~0.4 ~ {Item:{id:"minecraft:stone",count:12}}
execute if entity @s[tag=nitAtSilo] run summon minecraft:item ~ ~0.4 ~ {Item:{id:"minecraft:stone",count:12}}