particle electric_spark ^ ^0.05 ^0.5 0.1 0.1 0.1 0.1 1 normal
particle electric_spark ^ ^0.05 ^1.0 0.1 0.1 0.1 0.1 1 normal
particle electric_spark ^ ^0.05 ^1.5 0.1 0.1 0.1 0.1 1 normal
particle electric_spark ^ ^0.05 ^2.0 0.1 0.1 0.1 0.1 1 normal
particle electric_spark ^ ^0.05 ^2.5 0.1 0.1 0.1 0.1 1 normal
particle electric_spark ^ ^0.05 ^3.0 0.1 0.1 0.1 0.1 1 normal
particle electric_spark ^ ^0.05 ^3.5 0.1 0.1 0.1 0.1 1 normal
particle electric_spark ^ ^0.05 ^4.0 0.1 0.1 0.1 0.1 1 normal