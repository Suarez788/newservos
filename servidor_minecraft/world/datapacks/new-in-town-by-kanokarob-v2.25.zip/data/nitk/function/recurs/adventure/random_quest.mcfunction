###Determine random number###
execute store result score @s nitRandom run random value 1..18

###Assigns corresponding quest###
execute if score @s nitRandom matches 1 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/ancient_city_quest
execute if score @s nitRandom matches 2 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/buried_treasure_quest
execute if score @s nitRandom matches 3 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/cave_spider_quest
execute if score @s nitRandom matches 4 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/conduit_quest
execute if score @s nitRandom matches 5 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/dungeon_quest
execute if score @s nitRandom matches 6 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/elder_guardian_quest
execute if score @s nitRandom matches 7 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/evoker_quest
execute if score @s nitRandom matches 8 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/gapple_quest
execute if score @s nitRandom matches 9 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/igloo_quest
execute if score @s nitRandom matches 10 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/iron_golem_quest
execute if score @s nitRandom matches 11 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/jungle_pyramid_quest
execute if score @s nitRandom matches 12 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/mushroom_quest
execute if score @s nitRandom matches 13 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/music_disc_quest
execute if score @s nitRandom matches 14 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/piglin_brute_quest
execute if score @s nitRandom matches 15 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/snow_golem_quest
execute if score @s nitRandom matches 16 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/stronghold_library_quest
execute if score @s nitRandom matches 17 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/trident_quest
execute if score @s nitRandom matches 18 run advancement grant @p[scores={nitSuccess=0}] only nitk:adventure/witch_quest

###Reset score###
scoreboard players reset @s nitRandom