advancement revoke @s only nitk:power_station/post_bricks
clear @s brick_wall[custom_data={nitk_post:4b}]
scoreboard players set @e[tag=nitPostSeller,limit=1,sort=nearest] nitPostType 4

###Performs update###
function nitk:recurs/power_station/posts_update