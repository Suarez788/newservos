effect give @s[type=#nitk:guard_tower_mobs] minecraft:weakness 5 0
execute if entity @s[type=creeper,tag=!smithed.entity] run data merge entity @s {Fuse:60}
execute if entity @s[type=ghast,tag=!smithed.entity] run data modify entity @s ExplosionPower set value 0
execute if entity @s[tag=nitTyrantPortal] run scoreboard players remove @s nitResourceTime 40
execute if entity @s[tag=nitWitherPortal] run scoreboard players remove @s nitResourceTime 40
execute if entity @s[tag=nitTyrantSkyPortal] run scoreboard players remove @s nitResourceTime 40
execute if entity @s[tag=nitTyrantBeacon] run scoreboard players remove @s nitResourceTime 40