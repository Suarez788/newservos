###Player elevation###
execute positioned ~-1.5 ~ ~-1.5 as @a[dx=3,dy=13,dz=3] at @s if entity @s[predicate=nitk:on_ground,predicate=!nitk:slow_fall] run function nitk:recurs/tower_ascend
execute positioned ~-1.5 ~ ~-1.5 as @a[dx=3,dy=13,dz=3] at @s if entity @s[predicate=!nitk:on_ground,predicate=!nitk:levitation] run function nitk:recurs/tower_descend

###Cosmetics###
particle dust{color:[0.349f,0.902f,1.0f],scale:1.0f} ~ ~5 ~ 0.75 3 0.75 0.00001 2 normal
particle dolphin ~ ~5 ~ 0.75 3 0.75 0.00001 2 normal