###Summons and randomly places the meteor marker###
summon marker ~ ~ ~ {Tags:[nitMeteor,nitEntity,nitTicking,smithed.entity,smithed.strict]}
spreadplayers ~ ~ 40 200 false @e[tag=nitMeteor,tag=!nitGenerated,limit=1,sort=nearest]

###Determines the meteor type###
execute as @e[tag=nitMeteor,tag=!nitGenerated,limit=1,sort=nearest] at @s run function nitk:recurs/observatory/select_meteor

###Alerts the player###
playsound entity.generic.explode block @a ~ ~ ~ 10 1
tellraw @a[tag=nitCitizen,distance=..100] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.observatory.inform","fallback":"The Observatory saw a meteor land near your town!","color":"white","bold":false}]