###Removes bounty###
execute as @e[type=item,distance=..4,predicate=nitk:on_ground,predicate=nitk:item_cooked_beef_stack] at @s run function nitk:recurs/town_square/item_consume
execute as @e[type=item,distance=..4,predicate=nitk:on_ground,predicate=nitk:item_bone_stack] at @s run function nitk:recurs/town_square/item_consume
execute anchored eyes run particle happy_villager ^ ^ ^ 0.3 0.3 0.3 0 5 normal
playsound minecraft:entity.wolf.ambient neutral @a ~ ~ ~ 3 1

###Removes visitor###
particle poof ~ ~ ~ 0.5 0.5 0.5 0 20 normal
tellraw @a[distance=..10] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.wolf.thanks","fallback":"The wolves have been sated and look to be moving on from your town.","color":"white","bold":false}]
scoreboard players set @e[tag=nitTownSquare,limit=1,sort=nearest] nitResourceSpawn 0
tp @s ~ -100 ~
kill @s