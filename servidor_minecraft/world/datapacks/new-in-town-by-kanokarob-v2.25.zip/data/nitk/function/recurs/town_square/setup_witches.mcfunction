###Prepare central entity and set bossbar stats###
tag @s add nitRaid
tag @s add nitRaidWitch
bossbar add nitk:town_square_raid "Town Square Raid"
bossbar set nitk:town_square_raid name {"translate":"nitk.town_square.raid.witch","fallback":"Witch Coven Attack","color":"dark_purple"}
bossbar set nitk:town_square_raid color purple
bossbar set nitk:town_square_raid style notched_10
bossbar set nitk:town_square_raid visible true
bossbar set nitk:town_square_raid players @a[tag=nitCitizen,distance=..100]
scoreboard players set @s nitRaidProg 10
team add nitRaidMobs {"text":"Settlement Raid Mobs","color":"dark_red"}
team modify nitRaidMobs color dark_red

###Summon enemy mobs###
execute as @e[tag=nitSite,limit=10,sort=nearest,distance=..100] run summon witch ~ ~ ~ {Tags:[nitEntity,smithed.entity,smithed.strict,nitRaidMob],CustomName:{"translate":"nitk.name.witch","fallback":"Coven Witch","color":"dark_purple"},attributes:[{id:"minecraft:max_health",base:30.0}],Health:30.0f,Team:"nitRaidMobs",active_effects:[{id:"minecraft:glowing",duration:999999}],PersistenceRequired:1b}
execute store result score @s nitRaidProg run execute if entity @e[tag=nitRaidMob,distance=..100]
execute store result bossbar nitk:town_square_raid max run scoreboard players get @s nitRaidProg
execute store result bossbar nitk:town_square_raid value run scoreboard players get @s nitRaidProg
spreadplayers ~ ~ 5 40 false @e[tag=nitRaidMob]