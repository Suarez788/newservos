advancement revoke @s only nitk:power_station/post_fence_fancy
clear @s oak_fence[custom_data={nitk_post:2b}]
scoreboard players set @e[tag=nitPostSeller,limit=1,sort=nearest] nitPostType 2

###Performs update###
function nitk:recurs/power_station/posts_update