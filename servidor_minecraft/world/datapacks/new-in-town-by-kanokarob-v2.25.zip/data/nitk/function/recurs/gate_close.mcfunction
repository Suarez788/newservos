scoreboard players set @s nitSuccess 1
playsound block.piston.extend block @a ~ ~ ~ 1 1

execute if block ~ ~ ~ lever[facing=west] run fill ~2 ~-1 ~1 ~2 ~1 ~3 iron_bars replace air
execute if block ~ ~ ~ lever[facing=east] run fill ~-2 ~-1 ~-1 ~-2 ~1 ~-3 iron_bars replace air
execute if block ~ ~ ~ lever[facing=south] run fill ~1 ~-1 ~-2 ~3 ~1 ~-2 iron_bars replace air
execute if block ~ ~ ~ lever[facing=north] run fill ~-1 ~-1 ~2 ~-3 ~1 ~2 iron_bars replace air