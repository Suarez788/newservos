playsound minecraft:block.bell.use master @s ~ ~ ~ 2
tellraw @s[tag=nitInform] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.resources.inform","fallback":"Resources have been transported to your town's hoppers.","color":"white","bold":false}]
tag @s remove nitInform