execute as @e[tag=nitCathedralBell,distance=..5] at @s run effect give @a[distance=..5] instant_health 1 2
execute as @e[tag=nitCathedralBell,distance=..5] at @s run effect give @a[distance=..5] hero_of_the_village 60 0
advancement revoke @s only nitk:nitk/cathedral_bell