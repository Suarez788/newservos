###Informs player of the completed quest###
tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.success","fallback":"You have completed your quest! Return to the Adventurer for your reward!","color":"white","bold":false}]
playsound entity.player.levelup player @s ~ ~ ~ 1 1