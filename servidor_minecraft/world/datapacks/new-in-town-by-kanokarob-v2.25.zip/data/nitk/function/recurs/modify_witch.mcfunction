data merge entity @s {Invulnerable:0b,PersistenceRequired:0b,Tags:[],NoAI:0b,NoGravity:0b}
data remove entity @s CustomName