advancement revoke @s only nitk:power_station/lights_sea
clear @s sea_lantern[custom_data={nitk_light:7b}]
scoreboard players set @e[tag=nitLightSeller,limit=1,sort=nearest] nitLightType 7

###Performs update###
function nitk:recurs/power_station/lights_update