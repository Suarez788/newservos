advancement revoke @s only nitk:power_station/post_cobblestone
clear @s cobblestone_wall[custom_data={nitk_post:3b}]
scoreboard players set @e[tag=nitPostSeller,limit=1,sort=nearest] nitPostType 3

###Performs update###
function nitk:recurs/power_station/posts_update