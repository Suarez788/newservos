###Assign lamp post type###
function nitk:id_set_town_planner
scoreboard players add @s nitPostType 0
scoreboard players add @s nitLightType 0
scoreboard players operation @s nitPostType = @e[tag=nitPostSeller,distance=..100,limit=1,sort=nearest] nitPostType
scoreboard players operation @s nitLightType = @e[tag=nitLightSeller,distance=..100,limit=1,sort=nearest] nitLightType

###Posts##
execute if entity @s[scores={nitPostType=1}] run fill ~ ~ ~ ~ ~1 ~ oak_fence[east=false,west=false,north=false,south=false] replace
execute if entity @s[scores={nitPostType=2}] run place template nitk:town/power_station/post_fence_fancy ~ ~ ~
execute if entity @s[scores={nitPostType=3}] run fill ~ ~ ~ ~ ~1 ~ cobblestone_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitPostType=4}] run fill ~ ~ ~ ~ ~1 ~ brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitPostType=5}] run fill ~ ~ ~ ~ ~1 ~ stone_brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitPostType=6}] run fill ~ ~ ~ ~ ~1 ~ sandstone_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitPostType=7}] run fill ~ ~ ~ ~ ~1 ~ nether_brick_wall[east=none,west=none,north=none,south=none] replace


###Lights##
fill ~-1 ~2 ~-1 ~1 ~5 ~1 air replace #nitk:lampost_blocks
#Torch
execute if entity @s[scores={nitLightType=1,nitPostType=1}] run setblock ~ ~2 ~ oak_fence[east=false,west=false,north=false,south=false] replace
execute if entity @s[scores={nitLightType=1,nitPostType=2}] run place template nitk:town/power_station/light_torch_fancy ~ ~2 ~-1
execute if entity @s[scores={nitLightType=1,nitPostType=3}] run setblock ~ ~2 ~ cobblestone_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=1,nitPostType=4}] run setblock ~ ~2 ~ brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=1,nitPostType=5}] run setblock ~ ~2 ~ stone_brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=1,nitPostType=6}] run setblock ~ ~2 ~ sandstone_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=1,nitPostType=7}] run setblock ~ ~2 ~ nether_brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=1,nitPostType=1}] run setblock ~ ~3 ~ torch
execute if entity @s[scores={nitLightType=1,nitPostType=3..7}] run setblock ~ ~3 ~ torch

#Lantern
execute if entity @s[scores={nitLightType=2,nitPostType=1}] run setblock ~ ~2 ~ oak_fence[east=false,west=false,north=false,south=false] replace
execute if entity @s[scores={nitLightType=2,nitPostType=2}] run place template nitk:town/power_station/light_lantern_fancy ~ ~2 ~-1
execute if entity @s[scores={nitLightType=2,nitPostType=3}] run setblock ~ ~2 ~ cobblestone_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=2,nitPostType=4}] run place template nitk:town/power_station/light_lantern_bricks ~-1 ~2 ~
execute if entity @s[scores={nitLightType=2,nitPostType=5}] run setblock ~ ~2 ~ stone_brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=2,nitPostType=6}] run setblock ~ ~2 ~ sandstone_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=2,nitPostType=7}] run setblock ~ ~2 ~ nether_brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=2,nitPostType=1}] run setblock ~ ~3 ~ lantern
execute if entity @s[scores={nitLightType=2,nitPostType=3}] run setblock ~ ~3 ~ lantern
execute if entity @s[scores={nitLightType=2,nitPostType=5..7}] run setblock ~ ~3 ~ lantern

#Lamp
execute if entity @s[scores={nitLightType=3,nitPostType=1}] run place template nitk:town/power_station/light_lamp ~-1 ~2 ~-1
execute if entity @s[scores={nitLightType=3,nitPostType=2}] run setblock ~ ~2 ~ oak_fence[east=false,west=false,north=false,south=false] replace
execute if entity @s[scores={nitLightType=3,nitPostType=2}] run place template nitk:town/power_station/light_lamp ~-1 ~3 ~-1
execute if entity @s[scores={nitLightType=3,nitPostType=3..4}] run place template nitk:town/power_station/light_lamp ~-1 ~2 ~-1
execute if entity @s[scores={nitLightType=3,nitPostType=5}] run setblock ~ ~2 ~ stone_brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=3,nitPostType=5}] run place template nitk:town/power_station/light_lamp ~-1 ~3 ~-1
execute if entity @s[scores={nitLightType=3,nitPostType=6}] run place template nitk:town/power_station/light_lamp ~-1 ~2 ~-1
execute if entity @s[scores={nitLightType=3,nitPostType=7}] run place template nitk:town/power_station/light_lamp_nether ~-1 ~2 ~-1

#Candle
execute if entity @s[scores={nitLightType=4,nitPostType=1}] run setblock ~ ~2 ~ oak_planks replace
execute if entity @s[scores={nitLightType=4,nitPostType=2}] run setblock ~ ~2 ~ oak_fence replace
execute if entity @s[scores={nitLightType=4,nitPostType=2}] run setblock ~ ~3 ~ oak_planks replace
execute if entity @s[scores={nitLightType=4,nitPostType=3}] run setblock ~ ~2 ~ cobblestone replace
execute if entity @s[scores={nitLightType=4,nitPostType=4}] run setblock ~ ~2 ~ bricks replace
execute if entity @s[scores={nitLightType=4,nitPostType=5}] run setblock ~ ~2 ~ chiseled_stone_bricks replace
execute if entity @s[scores={nitLightType=4,nitPostType=6}] run setblock ~ ~2 ~ chiseled_sandstone replace
execute if entity @s[scores={nitLightType=4,nitPostType=7}] run setblock ~ ~2 ~ chiseled_nether_bricks replace
execute if entity @s[scores={nitLightType=4,nitPostType=1}] run setblock ~ ~3 ~ candle[candles=4,lit=true]
execute if entity @s[scores={nitLightType=4,nitPostType=2}] run setblock ~ ~4 ~ candle[candles=4,lit=true]
execute if entity @s[scores={nitLightType=4,nitPostType=3..7}] run setblock ~ ~3 ~ candle[candles=4,lit=true]

#Fire
execute if entity @s[scores={nitLightType=5,nitPostType=1}] run place template nitk:town/power_station/light_fire ~-1 ~2 ~-1
execute if entity @s[scores={nitLightType=5,nitPostType=2}] run setblock ~ ~2 ~ oak_fence[east=false,west=false,north=false,south=false] replace
execute if entity @s[scores={nitLightType=5,nitPostType=2}] run place template nitk:town/power_station/light_fire ~-1 ~3 ~-1
execute if entity @s[scores={nitLightType=5,nitPostType=3}] run place template nitk:town/power_station/light_fire ~-1 ~2 ~-1
execute if entity @s[scores={nitLightType=5,nitPostType=4}] run setblock ~ ~2 ~ brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=5,nitPostType=4}] run place template nitk:town/power_station/light_fire_bricks ~-1 ~3 ~-1
execute if entity @s[scores={nitLightType=5,nitPostType=5..6}] run place template nitk:town/power_station/light_fire ~-1 ~2 ~-1
execute if entity @s[scores={nitLightType=5,nitPostType=7}] run setblock ~ ~2 ~ nether_brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=5,nitPostType=7}] run place template nitk:town/power_station/light_fire_nether ~-1 ~3 ~-1
execute if entity @s[scores={nitLightType=5}] run fill ~ ~3 ~ ~ ~4 ~ air replace redstone_block

#Glowstone
execute if entity @s[scores={nitLightType=6,nitPostType=1}] run setblock ~ ~2 ~ glowstone
execute if entity @s[scores={nitLightType=6,nitPostType=1}] run setblock ~ ~3 ~ oak_trapdoor
execute if entity @s[scores={nitLightType=6,nitPostType=2}] run setblock ~ ~2 ~ oak_fence[east=false,west=false,north=false,south=false] replace
execute if entity @s[scores={nitLightType=6,nitPostType=2}] run place template nitk:town/power_station/light_glowstone_fancy ~-1 ~3 ~-1
execute if entity @s[scores={nitLightType=6,nitPostType=3..4}] run setblock ~ ~2 ~ glowstone
execute if entity @s[scores={nitLightType=6,nitPostType=3..4}] run setblock ~ ~3 ~ oak_trapdoor
execute if entity @s[scores={nitLightType=6,nitPostType=5}] run place template nitk:town/power_station/light_glowstone_fancy ~-1 ~2 ~-1
execute if entity @s[scores={nitLightType=6,nitPostType=6}] run place template nitk:town/power_station/sandstone_lamppost_glow ~ ~ ~
execute if entity @s[scores={nitLightType=6,nitPostType=7}] run setblock ~ ~2 ~ nether_brick_wall[east=none,west=none,north=none,south=none] replace
execute if entity @s[scores={nitLightType=6,nitPostType=7}] run place template nitk:town/power_station/light_glowstone_nether ~-1 ~3 ~-1

#Sea Lantern
execute if entity @s[scores={nitLightType=7,nitPostType=1}] run setblock ~ ~2 ~ sea_lantern
execute if entity @s[scores={nitLightType=7,nitPostType=2}] run setblock ~ ~2 ~ oak_fence[east=false,west=false,north=false,south=false] replace
execute if entity @s[scores={nitLightType=7,nitPostType=2}] run setblock ~ ~3 ~ sea_lantern
execute if entity @s[scores={nitLightType=7,nitPostType=3..5}] run setblock ~ ~2 ~ sea_lantern
execute if entity @s[scores={nitLightType=7,nitPostType=6}] run place template nitk:town/power_station/sandstone_lamppost_sea ~ ~ ~
execute if entity @s[scores={nitLightType=7,nitPostType=7}] run setblock ~ ~2 ~ sea_lantern

kill @e[type=item,distance=..3,tag=!smithed.entity,tag=!smithed.strict]