advancement revoke @s only nitk:power_station/lights_lantern
clear @s lantern[custom_data={nitk_light:2b}]
scoreboard players set @e[tag=nitLightSeller,limit=1,sort=nearest] nitLightType 2

###Performs update###
function nitk:recurs/power_station/lights_update