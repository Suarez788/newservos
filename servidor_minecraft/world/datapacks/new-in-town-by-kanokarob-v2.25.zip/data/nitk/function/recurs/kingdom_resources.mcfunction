###Performs item and fish distribution###
execute if entity @s[tag=nitLumberer] at @e[tag=nitLumberStor,limit=1,sort=nearest] run function nitk:recurs/daily_lumber
execute if entity @s[tag=nitMiner] at @e[tag=nitStoneStor,limit=1,sort=nearest] run function nitk:recurs/daily_stone
execute if entity @s[tag=nitFisherman] at @e[tag=nitFishPond,limit=1,sort=nearest] unless entity @e[type=cod,distance=..8] run function nitk:recurs/fish_spawn
execute if entity @s[tag=nitFarmhand] as @e[tag=nitFarmStor,limit=1,sort=nearest] at @s run function nitk:recurs/daily_farm

execute if entity @s[tag=nitFarmhandNurse] as @e[tag=nitFarmStor,limit=1,sort=nearest] at @s run function nitk:recurs/daily_farm_nursery

###Announces the event###
execute if entity @s[tag=nitLumberer] run tag @a[tag=nitCitizen] add nitInform
execute if entity @s[tag=nitMiner] run tag @a[tag=nitCitizen] add nitInform