###Removes bounty###
execute as @e[type=item,distance=..4,predicate=nitk:on_ground,predicate=nitk:item_gold_ingot_stack] at @s run function nitk:recurs/town_square/item_consume
execute anchored eyes run particle happy_villager ^ ^ ^ 0.3 0.3 0.3 0 5 normal
playsound entity.witch.celebrate neutral @a ~ ~ ~ 3 1

###Removes visitor###
particle witch ~ ~ ~ 0.5 0.5 0.5 0 20 normal
tellraw @a[distance=..10] [{"translate":"nitk.town_square.witch","fallback":"[Witch Coven]","color":"dark_purple","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.witch.thanks","fallback":"We thank you for your gifts of gold. May you and your village grow happily old!","color":"white","bold":false}]
scoreboard players set @e[tag=nitTownSquare,limit=1,sort=nearest] nitResourceSpawn 0
tp @s ~ -100 ~
kill @s