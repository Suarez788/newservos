###Cleanup###
tag @s remove nitRaidPiglin
bossbar set nitk:town_square_raid visible false

###Announce victory###
tellraw @a[tag=nitCitizen,distance=..100] [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.town_square.piglin.defeat","fallback":"The Piglin Posse is retreating to the Nether! They're in such a hurry, some items were left behind at the Town Square!","color":"gold","bold":false}]
execute at @e[tag=nitTownSquare,limit=1,sort=nearest] run loot spawn ~ ~1 ~ loot nitk:command/piglin_reward

###Cosmetics###
playsound ui.toast.challenge_complete player @a ~ ~ ~ 10 1
playsound entity.firework_rocket.launch player @a ~ ~ ~ 10 1
execute at @a[tag=nitCitizen,distance=..100] run particle totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.3 20 normal