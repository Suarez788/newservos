execute unless entity @a[distance=..30] run particle large_smoke ~ ~15 ~ 0.3 15 0.3 0 5 force
particle smoke ~ ~-1 ~ 1.5 1.5 1.5 0 20 normal

execute if entity @a[distance=..2.5] run kill @s