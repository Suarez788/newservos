advancement revoke @s only nitk:power_station/lights_candle
clear @s candle[custom_data={nitk_light:4b}]
scoreboard players set @e[tag=nitLightSeller,limit=1,sort=nearest] nitLightType 4

###Performs update###
function nitk:recurs/power_station/lights_update