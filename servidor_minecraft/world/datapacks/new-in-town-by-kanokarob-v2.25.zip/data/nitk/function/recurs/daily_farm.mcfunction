loot insert ~ ~ ~ loot nitk:command/farm_daily
execute if entity @s[tag=nitWindmillDouble] run loot insert ~ ~ ~ loot nitk:command/farm_daily