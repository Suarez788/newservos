advancement revoke @s only nitk:power_station/post_sandstone
clear @s sandstone_wall[custom_data={nitk_post:6b}]
scoreboard players set @e[tag=nitPostSeller,limit=1,sort=nearest] nitPostType 6

###Performs update###
function nitk:recurs/power_station/posts_update