summon minecraft:item ~ ~0.4 ~ {Item:{id:"minecraft:oak_log",count:12}}
execute if entity @s[tag=nitAtSilo] run summon minecraft:item ~ ~0.4 ~ {Item:{id:"minecraft:oak_log",count:12}}