###Performs item distribution###
execute if entity @s[tag=nitGoldStor] run function nitk:recurs/castle_taxes
execute if entity @s[tag=nitDrillStor] run loot insert ~ ~ ~ loot nitk:command/drill_daily
execute if entity @s[tag=nitBarnStor] run loot insert ~ ~ ~ loot nitk:command/barn_daily
execute if entity @s[tag=nitOutpost] run loot insert ~ ~ ~ loot nitk:command/outpost_daily
execute if entity @s[tag=nitBrickChest] run loot insert ~ ~ ~ loot nitk:command/bricks_daily
execute if entity @s[tag=nitDoompump] run loot insert ~ ~ ~ loot nitco:command/doompump_daily
execute if entity @s[tag=nitDragonStor] run loot insert ~ ~ ~ loot nitref:command/dragonologist_daily

###Performs doubled item distribution###
execute if entity @s[tag=nitDrillStor,tag=nitWindmillDouble] run loot insert ~ ~ ~ loot nitk:command/drill_daily
execute if entity @s[tag=nitBarnStor,tag=nitWindmillDouble] run loot insert ~ ~ ~ loot nitk:command/barn_daily
execute if entity @s[tag=nitOutpost,tag=nitWindmillDouble] run loot insert ~ ~ ~ loot nitk:command/outpost_daily