
function nitk:id_match_self
execute as @e[tag=nitkLampPost,tag=nitID_match] at @s run function nitk:recurs/power_station/lamppost_update
execute if entity @e[tag=nitPostSeller,distance=..10,scores={nitPostType=1..7}] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.lamp_posts.inform","fallback":"New lamp posts have been installed in your town.","color":"white","bold":false}]