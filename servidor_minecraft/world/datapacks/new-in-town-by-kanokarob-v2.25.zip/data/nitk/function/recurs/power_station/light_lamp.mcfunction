advancement revoke @s only nitk:power_station/lights_lamp
clear @s redstone_lamp[custom_data={nitk_light:3b}]
scoreboard players set @e[tag=nitLightSeller,limit=1,sort=nearest] nitLightType 3

###Performs update###
function nitk:recurs/power_station/lights_update