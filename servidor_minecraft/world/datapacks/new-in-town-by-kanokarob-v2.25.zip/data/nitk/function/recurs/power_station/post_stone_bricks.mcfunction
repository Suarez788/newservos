advancement revoke @s only nitk:power_station/post_stone_bricks
clear @s stone_brick_wall[custom_data={nitk_post:5b}]
scoreboard players set @e[tag=nitPostSeller,limit=1,sort=nearest] nitPostType 5

###Performs update###
function nitk:recurs/power_station/posts_update