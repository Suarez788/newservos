###Initial Wave###
execute if entity @s[tag=!nitInitialWave,scores={nitResourceTime=1}] run playsound block.respawn_anchor.set_spawn block @a ~ ~ ~ 7 0.75
execute if entity @s[tag=!nitInitialWave,scores={nitResourceTime=1}] as @a[gamemode=survival,distance=..80] run function nitk:attacks/beacon_effect
tag @s[scores={nitResourceTime=1}] add nitInitialWave

###Timer###
scoreboard players add @s nitResourceTime 0
scoreboard players add @s nitResourceSpawn 0
scoreboard players add @s nitResourceTime 1
scoreboard players add @s[scores={nitResourceTime=141..}] nitResourceSpawn 1
scoreboard players set @s[scores={nitResourceTime=141..}] nitResourceTime 0

###Spawn forces###
execute if score @s nitResourceSpawn matches 2 run tag @s add nitEffect
execute if entity @s[tag=nitEffect] run playsound block.respawn_anchor.set_spawn block @a ~ ~ ~ 7 0.75
execute if entity @s[tag=nitEffect] as @a[gamemode=survival,distance=..80] run function nitk:attacks/beacon_effect
tag @s remove nitEffect
scoreboard players set @s[scores={nitResourceSpawn=2..}] nitResourceSpawn 0

###Clear Condition###
execute unless block ~ ~ ~ beacon run tag @s add nitCleared
execute if entity @s[tag=nitCleared] run kill @e[type=item,predicate=nitk:item_beacon,distance=..2]
execute if entity @s[tag=nitCleared] run playsound entity.generic.explode block @a ~ ~ ~ 1 1
execute if entity @s[tag=nitCleared] run particle explosion ~ ~ ~ 0 0 0 0.05 4 normal
execute if entity @s[tag=nitCleared] run loot spawn ~ ~ ~ loot nitk:entities/beacon
execute if entity @s[tag=nitCleared] run setblock ~ ~ ~ air
execute if entity @s[tag=nitCleared] run advancement grant @a[distance=..30] only nitk:nitk/dark_beacon
execute if entity @s[tag=nitCleared] run kill @s