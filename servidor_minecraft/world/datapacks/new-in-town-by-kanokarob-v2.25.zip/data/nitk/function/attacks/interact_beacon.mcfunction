advancement revoke @s only nitk:interact_beacon
tag @e[tag=nitTyrantBeacon,distance=..10] add nitCleared