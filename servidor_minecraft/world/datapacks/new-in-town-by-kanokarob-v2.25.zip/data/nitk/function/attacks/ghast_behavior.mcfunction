###Movement Behavior###
scoreboard players add @s nitResourceTime 0
execute if score @s nitResourceTime matches 100..199 if predicate nitk:boss/chance_1 run tag @s add nitStrafing
execute if entity @s[tag=nitStrafing] facing entity @p[gamemode=!creative,gamemode=!spectator,distance=16..] feet if block ^ ^ ^3.4 air run tp @s ^ ^ ^0.4 facing entity @p[gamemode=!creative,gamemode=!spectator,distance=16..] feet

###Altitude Control###
execute positioned over motion_blocking unless block ~ ~ ~ #nitk:air if entity @s[distance=45..] run tag @s add nitAltitude
execute if entity @s[tag=nitAltitude] run data modify entity @s Motion[1] set value -0.45

###Score Resets###
scoreboard players add @s nitResourceTime 1
execute positioned over motion_blocking if entity @s[distance=..44] if predicate nitk:boss/chance_1 run tag @s remove nitAltitude
execute positioned over motion_blocking if entity @s[distance=..8] run tag @s remove nitAltitude
execute if score @s nitResourceTime matches 200 run tag @s remove nitStrafing
execute if score @s nitResourceTime matches 200 run scoreboard players reset @s nitResourceTime