###Effects and player cosmetics###
effect give @s darkness 15 0 false
effect give @s wither 5 0 false
execute at @s run particle soul_fire_flame ~ ~1 ~ 0.3 0.5 0.3 0.05 10 normal

###Beacon cosmetics###
execute rotated ~0 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~30 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~60 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~90 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~120 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~150 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~180 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~210 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~240 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~270 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~300 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~330 0 run particle soul_fire_flame ^ ^ ^4 0.1 0.1 0.1 0 1 normal
execute rotated ~15 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~45 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~75 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~105 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~135 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~165 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~195 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~225 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~255 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~285 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~315 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal
execute rotated ~345 0 run particle dust{color:[0.118f,0.71f,0.788f],scale:3.0f} ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal