###Initial Wave###
execute if entity @s[tag=!nitInitialWave,scores={nitResourceTime=1}] run function nitk:spawns/tyrant_warrior
scoreboard players set @s[tag=!nitInitialWave,scores={nitResourceTime=1}] nitSpreadLim 5
tag @s[scores={nitResourceTime=1}] add nitInitialWave

###Timer###
scoreboard players add @s nitResourceTime 0
scoreboard players add @s nitResourceSpawn 0
scoreboard players add @s nitResourceTime 1
scoreboard players add @s[scores={nitResourceTime=141..}] nitResourceSpawn 1
scoreboard players set @s[scores={nitResourceTime=141..}] nitResourceTime 0

###Particles and sounds##
execute if block ~ ~-2.5 ~-1 obsidian run particle dust{color:[0.553f,0.09f, 0.694f],scale:1.0f} ~ ~ ~ 0.1 1.2 1 0 30 normal
execute if block ~-1 ~-2.5 ~ obsidian run particle dust{color:[0.553f,0.09f, 0.694f],scale:1.0f} ~ ~ ~ 1 1.2 0.1 0 30 normal
execute if score @s nitResourceTime matches 140 run playsound block.portal.ambient block @a ~ ~ ~ 1 1

###Spawn forces###
execute if score @s nitResourceSpawn matches 3 if score @s nitSpreadLim matches 1.. positioned ~ ~-1.5 ~ run function nitk:spawns/tyrant_warrior
execute if score @s nitResourceSpawn matches 3 if score @s nitSpreadLim matches 1.. run scoreboard players remove @s nitSpreadLim 1
scoreboard players set @s[scores={nitResourceSpawn=3..}] nitResourceSpawn 0

###Clear Condition###
execute unless entity @e[tag=nitTyrantFire,distance=..6] run tag @s add nitCleared
execute if entity @s[tag=nitCleared] run playsound block.glass.break block @a ~ ~ ~ 1 1
execute if entity @s[tag=nitCleared] run playsound entity.generic.explode block @a ~ ~ ~ 1 1
execute if entity @s[tag=nitCleared] run particle explosion ~ ~ ~ 0 0 0 0.05 4 normal
execute if entity @s[tag=nitCleared] run kill @s