###Clear the previous attack###
kill @s[tag=nitAttackTrigger]
tag @s[tag=nitAttackTrigger] remove nitAttackTrigger

###Trigger attack if it's your turn###
function nitk:id_match_self
execute if entity @s[scores={nitHellAttacks=1..},tag=nitHellSite1] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=2..},tag=nitHellSite2] unless entity @e[tag=nitHellSite1,tag=nitID_match] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=4..},tag=nitHellSite3] unless entity @e[tag=nitHellSite2,tag=nitID_match] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=6..},tag=nitHellSite4] unless entity @e[tag=nitHellSite3,tag=nitID_match] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=7..},tag=nitHellSite5] unless entity @e[tag=nitHellSite4,tag=nitID_match] run tag @s add nitAttackTrigger
execute if entity @s[scores={nitHellAttacks=9..},tag=nitHellSite6] unless entity @e[tag=nitHellSite5,tag=nitID_match] run tag @s add nitAttackTrigger

###Move if there's a site too close###
scoreboard players set @s nitSpreadLim 0
execute if entity @s[tag=nitAttackTrigger] at @s positioned ~-12 ~ ~-12 if entity @e[tag=nitSite,dx=24,dz=24,y=-64,dy=312] run function nitk:spread_hell_2
execute if entity @s[tag=nitAttackTrigger] at @s run function nitk:special/special_gen_ground

###Scout Portal on 1st structure###
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite1] at @s run place template nitk:attacks/scout_portal ~-4 ~-1 ~-4
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite1] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.hell_attack.portal","fallback":"A Nether Portal has opened nearby!","color":"dark_red"},{"translate":"nitk.hell_attack.portal.desc","fallback":" Put out the Soul Fires to stop the Scouts from coming through!","color":"white"}]


###Double Portals on 2nd structure###
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite2] at @s run place template nitk:attacks/dual_portal ~-6 ~-1 ~-7
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite2] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.hell_attack.double_portal","fallback":"Two Nether Portals have opened nearby!","color":"dark_red"},{"translate":"nitk.hell_attack.double_portal.desc","fallback":" Put out the Soul Fires to halt the Tyrant's Scouts!","color":"white"}]


###Sky Portals on 4th structure###
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite3] at @e[tag=nitSite,distance=..140,limit=2,sort=random] run place template nitk:attacks/sky_portal ~-5 ~32 ~-9
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite3] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.hell_attack.ghast_attack","fallback":"Two Nether Portals have opened in the sky above your town!","color":"dark_red"},{"translate":"nitk.hell_attack.ghast_attack.desc","fallback":" Kill the Ghasts that guard them to thwart the attack!","color":"white"}]


###Dark Beacon on 6th structure###
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite4] at @s run place template nitk:attacks/dark_beacon ~-9 ~-1 ~-9
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite4] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.hell_attack.dark_beacon","fallback":"A Dark Beacon has come through a large Nether Portal!","color":"dark_red"},{"translate":"nitk.hell_attack.dark_beacon.desc","fallback":" Close the portal and destroy the Tyrant's Beacon!","color":"white"}]


###Grand Sky Portals on 7th structure###
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite5] run tag @e[tag=nitSite,distance=..140,limit=1,sort=random] add nitAttacked
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite5] run tag @e[tag=nitSite,distance=..140,limit=1,sort=random,tag=!nitAttacked] add nitAttacked
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite5] run tag @e[tag=nitSite,distance=..140,limit=1,sort=random,tag=!nitAttacked] add nitAttackedBig
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite5] at @e[tag=nitAttacked,distance=..140,limit=2] run place template nitk:attacks/sky_portal ~-5 ~32 ~-9
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite5] at @e[tag=nitAttackedBig,distance=..140,limit=1] run place template nitk:attacks/sky_portal_big ~-5 ~32 ~-9
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite5] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.hell_attack.ghast_invasion","fallback":"Three Nether Portals have opened over your town!","color":"dark_red"},{"translate":"nitk.hell_attack.ghast_invasion.desc","fallback":" Kill the Ghasts that guards them and defend the town!","color":"white"}]
tag @e[distance=..140] remove nitAttacked
tag @e[distance=..140] remove nitAttackedBig


###Tyrant Arena on 9th structure###
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite6] at @s run place template nitk:attacks/tyrant_arena ~-12 ~-11 ~-12
execute if entity @s[tag=nitAttackTrigger,tag=nitHellSite6] run tellraw @a[distance=..200] ["",{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.hell_attack.tyrant_arena","fallback":"The Tyrant has sent an arena of Nether Portals!","color":"dark_red"},{"translate":"nitk.hell_attack.tyrant_arena.desc","fallback":" He is preparing to enter the Overworld himself! Close the portals and push back his forces!","color":"white"}]


###Remove entity###
execute if entity @s[tag=nitAttackTrigger,tag=!nitHellSite3,tag=!nitHellSite5] at @s run summon minecraft:lightning_bolt ~ ~ ~
execute if entity @s[tag=nitAttackTrigger] at @e[tag=nitTyrantSkyPortal,limit=1,sort=random] run playsound entity.lightning_bolt.thunder weather @a ~ ~ ~ 5 1