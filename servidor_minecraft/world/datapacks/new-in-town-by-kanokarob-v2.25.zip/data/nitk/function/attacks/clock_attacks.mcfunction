###Beacon for objectives###
execute if entity @s[tag=nitTyrantObjective,tag=!nitTyrantGhast,tag=!nitTyrantBeacon] unless entity @p[distance=..30] run particle dust{color:[0.659f,0.224f,0.945f],scale:1.0f} ~ ~30 ~ 0.3 10 0.3 0 100 force

###Individual entity behaviors##
execute if entity @s[tag=nitTyrantPortal] run function nitk:attacks/portal
execute if entity @s[tag=nitTyrantFire] run function nitk:attacks/fires
execute if entity @s[tag=nitTyrantBeacon] run function nitk:attacks/beacon
execute if entity @s[tag=nitTyrantSkyPortal] run function nitk:attacks/sky_portal
execute if entity @s[tag=nitWitherPortal] run function nitk:attacks/wither_portal

###Handle cleared status###
execute if entity @s[tag=nitHellBase,tag=!nitHellFactory,tag=nitGenerated,tag=!nitCleared] unless entity @e[tag=nitBaseObjective,distance=..30] run function nitco:bases/cleared_status

###Base Objectives###
execute if entity @s[tag=nitBaseObjective] run function nitco:bases/objective