particle soul ~ ~1 ~ 0.2 0.2 0.2 0.01 1 normal
execute unless block ~ ~ ~ #nitk:soul_fire run kill @s