###Initial Wave###
execute if entity @s[tag=!nitInitialWave,tag=!nitBigPortal,scores={nitResourceTime=1}] run function nitk:spawns/tyrant_scout
execute if entity @s[tag=!nitInitialWave,tag=!nitBigPortal,scores={nitResourceTime=1}] run spreadplayers ~ ~ 10 10 false @e[tag=nitTyrantScout,limit=1,distance=..8]
execute if entity @s[tag=!nitInitialWave,tag=nitBigPortal,scores={nitResourceTime=1}] positioned ~-4 ~-2 ~-6 run function nitk:spawns/tyrant_ghast
execute if entity @s[tag=!nitInitialWave,tag=nitBigPortal,scores={nitResourceTime=1}] positioned ~-4 ~-2 ~6 run function nitk:spawns/tyrant_ghast
scoreboard players set @s[tag=!nitInitialWave,tag=!nitBigPortal,scores={nitResourceTime=1}] nitSpreadLim 10
scoreboard players set @s[tag=!nitInitialWave,tag=nitBigPortal,scores={nitResourceTime=1}] nitSpreadLim 3
tag @s[scores={nitResourceTime=1}] add nitInitialWave

###Timer###
scoreboard players add @s nitResourceTime 0
scoreboard players add @s nitResourceSpawn 0
scoreboard players add @s nitResourceTime 1
scoreboard players add @s[scores={nitResourceTime=141..}] nitResourceSpawn 1
scoreboard players set @s[scores={nitResourceTime=141..}] nitResourceTime 0

###Particles and sounds##
particle dust{color:[0.553f,0.09f, 0.694f],scale:1.0f} ~ ~ ~ 0.1 1.5 1.5 0 40 normal
particle dust{color:[0.702f,0.122f, 0.878f],scale:1.0f} ~ ~ ~ 0.1 1.5 1.5 0 15 normal
particle portal ~ ~ ~ 0.1 1.5 1.5 0.05 10 normal
execute if score @s nitResourceTime matches 140 run playsound block.portal.ambient block @a ~ ~ ~ 1 1
execute at @s run tp @e[tag=nitTyrantGhast,tag=nitTyrantObjective,distance=..15,limit=1,sort=nearest] ~-4.5 ~-2 ~

###Spawn forces###
execute if score @s[tag=!nitBigPortal] nitResourceSpawn matches 2 if score @s nitSpreadLim matches 1.. positioned ~ ~-1.5 ~ run function nitk:spawns/tyrant_scout
execute if score @s[tag=!nitBigPortal] nitResourceSpawn matches 2 run spreadplayers ~ ~ 10 10 false @e[tag=nitTyrantScout,limit=1,distance=..8]
execute if score @s[tag=!nitBigPortal] nitResourceSpawn matches 2 if score @s nitSpreadLim matches 1.. run scoreboard players remove @s nitSpreadLim 1
scoreboard players set @s[tag=!nitBigPortal,scores={nitResourceSpawn=2..}] nitResourceSpawn 0

execute if score @s[tag=nitBigPortal] nitResourceSpawn matches 3 if score @s nitSpreadLim matches 1.. positioned ~-4 ~-2 ~-6 run function nitk:spawns/tyrant_ghast
execute if score @s[tag=nitBigPortal] nitResourceSpawn matches 3 if score @s nitSpreadLim matches 1.. run scoreboard players remove @s nitSpreadLim 1
scoreboard players set @s[tag=nitBigPortal,scores={nitResourceSpawn=3..}] nitResourceSpawn 0

###Clear Condition###
execute unless entity @e[tag=nitTyrantGhast,tag=nitTyrantObjective,distance=..10] run tag @s add nitCleared
execute if entity @s[tag=nitCleared] run playsound block.glass.break block @a ~ ~ ~ 5 1
execute if entity @s[tag=nitCleared] run playsound entity.generic.explode block @a ~ ~ ~ 5 1
execute if entity @s[tag=nitCleared] run particle explosion ~ ~ ~ 2 0.5 0 0.05 15 normal
execute if entity @s[tag=nitCleared] run fill ~-3 ~-6 ~-9 ~3 ~6 ~9 air
execute if entity @s[tag=nitCleared] run kill @s