scoreboard players enable @s nitContract
gamerule minecraft:send_command_feedback false

execute if predicate nitk:particle_type_1 align xyz positioned ~0.5 ~0.1 ~0.5 run function nitk:tutorial/contract_particles_1
execute if predicate nitk:particle_type_2 align xyz positioned ~0.5 ~0.1 ~0.5 run function nitk:tutorial/contract_particles_2
execute if predicate nitk:particle_type_3 align xyz positioned ~5.5 ~0.1 ~0.5 run function nitk:tutorial/contract_particles_1
execute if predicate nitk:particle_type_4 align xyz positioned ~0.5 54.1 ~0.5 run function nitdim:tutorial/contract_particles_4
execute if predicate nitk:particle_type_5 align xyz positioned ~4.5 ~0.1 ~0.5 run function nitdim:tutorial/contract_particles_5
execute if predicate nitk:particle_type_6 align xyz positioned ~10.5 ~0.1 ~0.5 run function nitdim:tutorial/contract_particles_4