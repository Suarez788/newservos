###Checks Location###
execute if entity @s[tag=nitkFounder] run tellraw @s [{"text":"[回] ","color":"blue","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.contract.warning.founder","fallback":"You have already started a settlement. You cannot found another.","color":"white","bold":false}]
execute unless entity @s[predicate=nitk:in_overworld] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.contract.warning.dimension","fallback":"You must settle in the Overworld.","color":"white","bold":false}]
execute if entity @e[type=minecraft:villager,tag=nitKTP,distance=..500] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.contract.warning.distance","fallback":"You cannot settle within 500 blocks of another town. Venture out farther!","color":"white","bold":false}]
execute unless entity @s[tag=nitkFounder] if entity @s[predicate=nitk:in_overworld] unless entity @e[type=minecraft:villager,tag=nitKTP,distance=..500] run tag @s add nitClearCondition

###Builds Wagon if clear###
execute if entity @s[tag=nitClearCondition] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.contract.begin","fallback":"You begin to unpack your wagon...","color":"white","bold":false}]
execute if entity @s[tag=nitClearCondition] run function nitk:contract

###Reset Trigger###
tag @s remove nitClearCondition
scoreboard players reset @s nitContract