execute as @e[tag=nitTicking] at @s run function nitk:clock_scheduled
execute as @a at @s run function nitk:player_scheduled
schedule function nitk:scheduler 4s