tp @s ~ -1000 ~
execute at @s run kill @s