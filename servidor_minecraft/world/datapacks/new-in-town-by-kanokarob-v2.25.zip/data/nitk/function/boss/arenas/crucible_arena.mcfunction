###Scoreboard Prep###
scoreboard players add @s nitResourceSpawn 0

###State Change###
execute if score @s nitResourceSpawn matches 0 unless block ~ ~ ~ diamond_block run function nitk:boss/arenas/crucible_start
execute if score @s nitResourceSpawn matches 1 unless block ~ ~ ~ diamond_block run function nitk:boss/arenas/crucible_active
execute if score @s nitResourceSpawn matches 1 unless entity @a[distance=..30] run function nitk:boss/arenas/crucible_reset