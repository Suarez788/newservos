###Tell###
execute if entity @s[tag=nitTyrantEasy] if score @s nitBossTime matches ..59 run function nitk:boss/cosmetic/tyrant/launch_tell
execute if entity @s[tag=nitTyrantMed] if score @s nitBossTime matches ..39 run function nitk:boss/cosmetic/tyrant/launch_tell
execute if entity @s[tag=nitTyrantHard] if score @s nitBossTime matches ..19 run function nitk:boss/cosmetic/tyrant/launch_tell

###Attack###
execute if entity @s[tag=nitTyrantEasy] if score @s nitBossTime matches 60 run function nitk:boss/attacks/tyrant/launch_effect
execute if entity @s[tag=nitTyrantMed] if score @s nitBossTime matches 40 run function nitk:boss/attacks/tyrant/launch_effect
execute if entity @s[tag=nitTyrantHard] if score @s nitBossTime matches 20 run function nitk:boss/attacks/tyrant/launch_effect