###Tell###
execute if score @s nitBossTime matches ..39 run function nitk:boss/cosmetic/ancient_builder/dash_tell

###Attack###
execute if score @s nitBossTime matches 40..60 run function nitk:boss/attacks/ancient_builder/dash_effect

###Attack###
execute if score @s nitBossTime matches 61.. run function nitk:boss/attacks/ancient_builder/dash_expire