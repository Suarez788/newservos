###Distributes Arena-specific functions###
execute if entity @s[tag=nitWitherHold] run function nitk:boss/arenas/tyrant_arena_overworld
execute if entity @s[tag=nitHellFactory,tag=nitGenerated,tag=!nitCleared] run function nitk:boss/arenas/tyrant_arena_nether
execute if entity @s[tag=nitRWither,tag=nitArenaStart] run function nitk:boss/arenas/tyrant_arena_end
execute if entity @s[tag=nitCrucibleArena] run function nitk:boss/arenas/crucible_arena
execute if entity @s[tag=nitWithermawArena] run function nitk:boss/arenas/withermaw_arena