###Cleanup###
execute as @e[tag=nitAncientBuilder,distance=..30] run function nitk:boss/boss_remove
kill @e[tag=nitBossEntity,distance=..30]
bossbar remove nitk:ancient_builder
setblock ~ ~ ~ soul_fire
setblock ~ ~-1 ~ soul_soil

###Score Update###
scoreboard players set @s nitResourceSpawn 0