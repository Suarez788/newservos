###Cleanup###
data modify entity @s NoAI set value 0b
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack2