###Position traps respecting the roof###
data modify entity @s Pos[1] set from entity @e[tag=nitTyrant,limit=1,sort=nearest] Pos[1]
execute at @s run tp ~ ~-4 ~