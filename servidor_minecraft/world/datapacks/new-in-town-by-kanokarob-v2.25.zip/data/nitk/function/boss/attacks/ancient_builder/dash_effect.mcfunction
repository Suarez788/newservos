###Cosmetic###
execute rotated ~ 0 run particle small_flame ^ ^0.25 ^-0.5 0.3 0.2 0.3 0.05 5 normal
execute rotated ~ 0 run particle smoke ^ ^0.25 ^-0.5 0.3 0.2 0.3 0.05 10 normal
execute rotated ~ 0 run particle lava ^ ^0.25 ^-0.5 0.3 0.2 0.3 0.01 1 normal
execute if score @s nitBossTime matches 42 run playsound entity.wither_skeleton.hurt hostile @a ~ ~ ~ 2 0.8
execute if score @s nitBossTime matches 42 run playsound entity.blaze.shoot hostile @a ~ ~ ~ 2 1.3

###Movement###
execute rotated ~ 0 run function nitk:boss/attacks/ancient_builder/dash_movement