###Summon Skulls###
execute unless entity @s[tag=nitTyrantMed] at @s run summon wither_skull ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitTyrantSkull,nitBossEntity,smithed.entity,smithed.strict]}
execute unless entity @s[tag=nitTyrantEasy] at @s anchored eyes rotated ~15 0 positioned ^ ^ ^0.5 run summon wither_skull ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitTyrantSkull,nitBossEntity,smithed.entity,smithed.strict]}
execute unless entity @s[tag=nitTyrantEasy] at @s anchored eyes rotated ~-15 0 positioned ^ ^ ^0.5 run summon wither_skull ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitTyrantSkull,nitBossEntity,smithed.entity,smithed.strict]}

###Tag Skulls###
execute if entity @s[tag=nitTyrantEasy] at @s run tag @e[tag=nitTyrantSkull,limit=1,sort=nearest] add nitTyrantEasy
execute if entity @s[tag=nitTyrantMed] at @s run tag @e[tag=nitTyrantSkull,limit=2,sort=nearest] add nitTyrantMed
execute if entity @s[tag=nitTyrantHard] at @s run tag @e[tag=nitTyrantSkull,limit=3,sort=nearest] add nitTyrantHard

###Cosmetics###
playsound entity.wither.ambient hostile @a ~ ~ ~ 3 0.7