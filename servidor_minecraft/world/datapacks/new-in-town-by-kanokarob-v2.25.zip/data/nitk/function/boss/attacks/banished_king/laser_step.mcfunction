###Cosmetic###
execute anchored eyes positioned ^ ^ ^2 run particle bubble ~ ~ ~ 0.25 0.25 0.25 0.01 5 normal
execute anchored eyes positioned ^ ^ ^2 run particle crit ~ ~ ~ 0.25 0.25 0.25 0.01 3 normal
execute anchored eyes positioned ^ ^ ^2 run particle end_rod ~ ~ ~ 0.25 0.25 0.25 0.01 1 normal

###Damage###
execute unless block ~ ~ ~ #nitk:water run tag @s add nitBlocked
execute unless entity @s[tag=nitBlocked] as @e[type=!elder_guardian,distance=..1.25,gamemode=!creative,gamemode=!spectator] run damage @s 2.0 minecraft:magic