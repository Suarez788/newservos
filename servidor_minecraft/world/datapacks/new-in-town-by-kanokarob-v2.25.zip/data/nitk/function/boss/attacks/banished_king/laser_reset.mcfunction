###Reset###
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack3