###Cleanup###
bossbar remove nitk:ancient_builder
kill @e[tag=nitBossEntity,distance=..30]
advancement grant @a[distance=..30] only nitco:nitco/defeat_ancient_builder

###Score Update###
scoreboard players set @s nitResourceSpawn 2