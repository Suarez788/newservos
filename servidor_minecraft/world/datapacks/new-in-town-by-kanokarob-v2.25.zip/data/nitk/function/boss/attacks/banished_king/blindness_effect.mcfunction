###Cosmetics###
particle bubble ~ ~1 ~ 1.5 1.5 1.5 0.5 30
particle splash ~ ~1 ~ 1.5 1.5 1.5 0.7 50
particle elder_guardian ~ ~1 ~ 1.5 1.5 1.5 0 1 normal @a[distance=..10]
playsound entity.elder_guardian.curse hostile @a[distance=..10] ~ ~ ~ 1 1
playsound entity.elder_guardian.hurt hostile @a[distance=10.1..] ~ ~ ~ 3 0.6

###Effects###
effect give @a[distance=..10,gamemode=survival] blindness 10 2 true

###Cleanup###
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack2