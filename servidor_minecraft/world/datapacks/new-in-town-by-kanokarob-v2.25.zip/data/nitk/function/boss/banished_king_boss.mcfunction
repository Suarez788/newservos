###General Behavior###
scoreboard players add @s nitResourceTime 0
scoreboard players add @s nitBossTime 0
tp @s ~ ~ ~ facing entity @p[gamemode=!creative,gamemode=!spectator,distance=..30] feet
execute store result bossbar nitk:banished_king value run data get entity @s Health

###Random Attack Selection###
execute if entity @s[tag=!nitAttacking] if predicate nitk:boss/chance_1 run tag @s add nitBossAttack
execute if entity @s[tag=!nitAttacking] if score @s nitBossTime matches 100.. run tag @s add nitBossAttack
execute if entity @s[tag=nitBossAttack] run function nitk:boss/attacks/generic_attack_select

###Perform Attacks###
execute if entity @s[tag=nitAttack1] run function nitk:boss/attacks/banished_king/minions
execute if entity @s[tag=nitAttack2] run function nitk:boss/attacks/banished_king/blindness
execute if entity @s[tag=nitAttack3] run function nitk:boss/attacks/banished_king/laser

###Chat Lines###
execute if score @s nitResourceTime matches 200..300 if predicate nitk:boss/chance_1 run function nitk:boss/chat/banished_king

###Increment Scores###
scoreboard players add @s nitResourceTime 1
scoreboard players add @s nitBossTime 1
execute if score @s nitResourceTime matches 301 run scoreboard players reset @s nitResourceTime