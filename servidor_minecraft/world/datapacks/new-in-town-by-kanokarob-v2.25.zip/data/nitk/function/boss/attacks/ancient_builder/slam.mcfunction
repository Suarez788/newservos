###Tell###
execute if score @s nitBossTime matches 2 run function nitk:boss/cosmetic/ancient_builder/slam_tell

###Landing###
execute if score @s nitBossTime matches 10.. if predicate nitk:on_ground run function nitk:boss/attacks/ancient_builder/slam_land