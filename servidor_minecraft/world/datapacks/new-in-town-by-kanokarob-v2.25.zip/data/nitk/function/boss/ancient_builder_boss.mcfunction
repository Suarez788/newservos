###General Behavior###
scoreboard players add @s nitResourceTime 0
scoreboard players add @s nitBossTime 0
execute store result bossbar nitk:ancient_builder value run data get entity @s Health

###Random Attack Selection###
execute if entity @s[tag=!nitAttacking] if predicate nitk:boss/chance_1 run tag @s add nitBossAttack
execute if entity @s[tag=!nitAttacking] if score @s nitBossTime matches 100.. run tag @s add nitBossAttack
execute if entity @s[tag=nitBossAttack] run function nitk:boss/attacks/generic_attack_select

###Perform Attacks###
execute if entity @s[tag=nitAttack1] run function nitk:boss/attacks/ancient_builder/dash
execute if entity @s[tag=nitAttack2] run function nitk:boss/attacks/ancient_builder/swing
execute if entity @s[tag=nitAttack3] run function nitk:boss/attacks/ancient_builder/slam

###Chat Lines###
execute if score @s nitResourceTime matches 200..300 if predicate nitk:boss/chance_1 run function nitk:boss/chat/ancient_builder

###Totem of Undying###
execute if predicate nitk:has_fire_res run function nitk:boss/ancient_builder_revive

##Unstuck###
execute unless entity @s[tag=nitAttacking] anchored eyes unless block ^ ^-0.4 ^ #nitk:air run tp @s ^ ^ ^1 facing entity @p[gamemode=!creative,gamemode=!spectator] feet

###Increment Scores###
scoreboard players add @s nitResourceTime 1
scoreboard players add @s nitBossTime 1
execute if score @s nitResourceTime matches 301 run scoreboard players reset @s nitResourceTime