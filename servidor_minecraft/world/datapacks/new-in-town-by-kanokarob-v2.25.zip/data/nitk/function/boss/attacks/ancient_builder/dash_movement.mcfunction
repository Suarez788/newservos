execute unless block ^ ^-0.4 ^1 #nitk:air run tp @s ^ ^ ^1
execute if block ^ ^-0.4 ^1 #nitk:air run tp @s ^ ^-1 ^1
execute unless block ^ ^0.4 ^1 #nitk:air if block ^ ^1.4 ^1 #nitk:air unless block ^ ^2.4 ^1 #nitk:air run tp @s ^ ^1 ^1
execute unless block ^ ^0.4 ^1 #nitk:air unless block ^ ^1.4 ^1 #nitk:air run function nitk:boss/attacks/ancient_builder/dash_expire