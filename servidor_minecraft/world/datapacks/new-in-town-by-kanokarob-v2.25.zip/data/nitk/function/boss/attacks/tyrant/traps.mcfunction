###Set Traps###
execute if score @s nitBossTime matches 1 run kill @e[tag=nitTyrantTrap,limit=5,sort=nearest]
execute if score @s nitBossTime matches 1 run summon marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitTyrantTrap,nitBossEntity,smithed.entity,smithed.strict]}
execute if score @s nitBossTime matches 1 run summon marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitTyrantTrap,nitBossEntity,smithed.entity,smithed.strict]}
execute if score @s nitBossTime matches 1 run summon marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitTyrantTrap,nitBossEntity,smithed.entity,smithed.strict]}
execute if score @s nitBossTime matches 1 run summon marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitTyrantTrap,nitBossEntity,smithed.entity,smithed.strict]}
execute if score @s nitBossTime matches 1 run summon marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitTyrantTrap,nitBossEntity,smithed.entity,smithed.strict]}
execute if score @s nitBossTime matches 1 if entity @s[tag=nitTyrantMed] run tag @e[tag=nitTyrantTrap,limit=5,sort=nearest] add nitTyrantMed
execute if score @s nitBossTime matches 1 if entity @s[tag=nitTyrantHard] run tag @e[tag=nitTyrantTrap,limit=5,sort=nearest] add nitTyrantHard
execute if score @s nitBossTime matches 1 run spreadplayers ~ ~ 2 8 false @e[tag=nitTyrantTrap,limit=5,sort=nearest]
execute if score @s nitBossTime matches 1 if entity @s[tag=nitTyrantMed] as @e[tag=nitTyrantTrap,limit=5,sort=nearest] run function nitk:boss/attacks/tyrant/traps_set

###Cleanup###
execute if score @s nitBossTime matches 1 run playsound entity.wither.spawn hostile @a ~ ~ ~ 3 1.6
execute if score @s[tag=nitTyrantMed] nitBossTime matches 100.. run function nitk:boss/attacks/tyrant/traps_cleanup
execute if score @s[tag=nitTyrantHard] nitBossTime matches 200.. run function nitk:boss/attacks/tyrant/traps_cleanup
execute if score @s nitBossTime matches 60.. run function nitk:boss/attacks/tyrant/traps_reset