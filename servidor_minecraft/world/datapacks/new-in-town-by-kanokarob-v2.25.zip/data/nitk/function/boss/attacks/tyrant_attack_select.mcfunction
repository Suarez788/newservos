tag @s add nitAttacking
tag @s remove nitBossAttack
execute if entity @s[tag=nitTyrantEasy] store result score @s nitRandom run random value 1..3
execute if entity @s[tag=nitTyrantMed] store result score @s nitRandom run random value 1..4
execute if entity @s[tag=nitTyrantHard] store result score @s nitRandom run random value 1..5

execute if score @s nitRandom matches 1 run tag @s add nitAttack1
execute if score @s nitRandom matches 2 run tag @s add nitAttack2
execute if score @s nitRandom matches 3 run tag @s add nitAttack3
execute if score @s nitRandom matches 4 run tag @s add nitAttack4
execute if score @s nitRandom matches 5 run tag @s add nitAttack5

scoreboard players reset @s nitRandom
scoreboard players reset @s nitBossTime