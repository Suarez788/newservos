tag @s add nitAttacking
tag @s remove nitBossAttack
execute store result score @s nitRandom run random value 1..3

execute if score @s nitRandom matches 1 run tag @s add nitAttack1
execute if score @s nitRandom matches 2 run tag @s add nitAttack2
execute if score @s nitRandom matches 3 run tag @s add nitAttack3

scoreboard players reset @s nitRandom
scoreboard players reset @s nitBossTime