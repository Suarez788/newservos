###Cosmetics###
particle squid_ink ^ ^ ^-0.2 0.2 0.2 0.2 0 1 normal
particle soul ^ ^ ^-0.2 0.2 0.2 0.2 0.01 2 normal

###Skull Motion###
execute if score @s nitBossTime matches 1 run tp @s ~ ~ ~ ~180 ~
execute if entity @s[tag=nitLaunched,tag=nitTyrantEasy] run tp @s ^ ^ ^0.45
execute if entity @s[tag=nitLaunched,tag=nitTyrantMed] run tp @s ^ ^ ^0.65
execute if entity @s[tag=nitLaunched,tag=nitTyrantHard] run tp @s ^ ^ ^0.9

###Collision###
execute if entity @s[tag=nitLaunched] at @s if entity @e[type=!wither_skull,type=!wither,type=!marker,distance=..1.5] run function nitk:boss/attacks/tyrant/skull_collision
execute if entity @s[tag=nitLaunched] at @s positioned ~ ~-1 ~ if entity @e[type=!wither_skull,type=!wither,type=!marker,distance=..1.5] run function nitk:boss/attacks/tyrant/skull_collision
execute if entity @s[tag=nitLaunched] at @s unless block ~ ~ ~ #nitk:air run function nitk:boss/attacks/tyrant/skull_collision

###Expiration Timer###
scoreboard players add @s nitBossTime 0
execute if entity @s[tag=nitLaunched] run scoreboard players add @s nitBossTime 1
execute if score @s nitBossTime matches 200.. run function nitk:boss/attacks/tyrant/skull_collision