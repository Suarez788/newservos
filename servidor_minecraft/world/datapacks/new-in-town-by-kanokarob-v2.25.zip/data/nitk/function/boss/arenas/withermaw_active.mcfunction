###General Operation###
tp @e[tag=nitAncientBuilder,distance=16..] ~ ~ ~
bossbar set nitk:ancient_builder players @a[distance=..20]
execute unless entity @e[tag=nitAncientBuilder,distance=..30] run function nitk:boss/arenas/withermaw_cleared

###Initial Chat Line/Attack###
scoreboard players add @s nitResourceTime 0
scoreboard players add @s nitResourceTime 1
execute if score @s nitResourceTime matches 40 as @e[tag=nitBoss,limit=1,sort=nearest,distance=..20] run function nitk:boss/arenas/generic_boss_initiate