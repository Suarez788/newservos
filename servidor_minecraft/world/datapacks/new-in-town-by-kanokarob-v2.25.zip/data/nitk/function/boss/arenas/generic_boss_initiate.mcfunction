tag @s add nitBossAttack
execute if entity @s[tag=nitTyrant] run function nitk:boss/chat/tyrant
execute if entity @s[tag=nitBanKing] run function nitk:boss/chat/banished_king
execute if entity @s[tag=nitAncientBuilder] run function nitk:boss/chat/ancient_builder