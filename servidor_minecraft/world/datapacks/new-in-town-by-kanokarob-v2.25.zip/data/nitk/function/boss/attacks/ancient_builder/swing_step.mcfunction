###Cosmetic###
playsound entity.player.attack.sweep hostile @a ~ ~ ~ 0.4 0.8
particle sweep_attack ~ ~ ~ 0.2 0 0.2 0 1 normal
particle crit ~ ~ ~ 0.2 0 0.2 0.01 5 normal
particle smoke ~ ~ ~ 0.2 0 0.2 0. 3 normal

###Damage###
execute as @a[gamemode=!creative,gamemode=!spectator,predicate=nitk:on_ground,distance=..1] run damage @s 8.0 minecraft:mob_attack