###Particles###
execute if score @s nitBossTime matches 0 run function nitk:boss/cosmetic/tyrant/wave_tell_particles
execute if score @s nitBossTime matches 9 run function nitk:boss/cosmetic/tyrant/wave_tell_particles
execute if score @s nitBossTime matches 19 run function nitk:boss/cosmetic/tyrant/wave_tell_particles
execute if score @s nitBossTime matches 29 run function nitk:boss/cosmetic/tyrant/wave_tell_particles
execute if score @s nitBossTime matches 39 run function nitk:boss/cosmetic/tyrant/wave_tell_particles
execute if score @s nitBossTime matches 49 run function nitk:boss/cosmetic/tyrant/wave_tell_particles
execute if score @s nitBossTime matches 59 run function nitk:boss/cosmetic/tyrant/wave_tell_particles
execute if score @s nitBossTime matches 69 run function nitk:boss/cosmetic/tyrant/wave_tell_particles
execute if score @s nitBossTime matches 79 run function nitk:boss/cosmetic/tyrant/wave_tell_particles

###Sounds###
execute if score @s nitBossTime matches 0 run playsound entity.wither.spawn hostile @a ~ ~ ~ 3 1
execute if score @s nitBossTime matches 19 run playsound entity.wither.spawn hostile @a ~ ~ ~ 3 1
execute if score @s nitBossTime matches 39 run playsound entity.wither.spawn hostile @a ~ ~ ~ 3 1
execute if score @s nitBossTime matches 59 run playsound entity.wither.spawn hostile @a ~ ~ ~ 3 1
execute if score @s nitBossTime matches 79 run playsound entity.wither.spawn hostile @a ~ ~ ~ 3 1