###Setup###
function nitk:spawns/ancient_builder
bossbar add nitk:ancient_builder {"translate":"nitk.name.ancient_builder","fallback":"Ancient Builder","color":"dark_red","bold":true}
bossbar set nitk:ancient_builder color red
bossbar set nitk:ancient_builder max 250
bossbar set nitk:ancient_builder visible true

###Cosmetics###
playsound item.firecharge.use hostile @a ~ ~ ~ 3 0.8
playsound entity.wither.spawn hostile @a ~ ~ ~ 3 1.3
particle dust{color:[0.38f,0.0f, 0.541f],scale:2.0f} ~ ~ ~ 1 1 1 0.05 30 normal
particle falling_obsidian_tear ~ ~ ~ 1 1 1 0.05 20 normal
particle lava ~ ~ ~ 1 1 1 0.05 10 normal

###Score Update###
scoreboard players set @s nitResourceSpawn 1