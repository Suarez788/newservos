###General Operation###
tp @e[tag=nitBanKing,distance=..30] ~ ~ ~
tp @e[type=axolotl,distance=..8] ~ -1000 ~
bossbar set nitk:banished_king players @a[distance=..30]
effect give @a[distance=..30] water_breathing 1 0 true
effect clear @a[distance=..30] mining_fatigue
execute unless entity @e[tag=nitBanKing,distance=..30] run function nitk:boss/arenas/crucible_cleared

###Initial Chat Line/Attack###
scoreboard players add @s nitResourceTime 0
scoreboard players add @s nitResourceTime 1
execute if score @s nitResourceTime matches 40 as @e[tag=nitBoss,limit=1,sort=nearest,distance=..30] run function nitk:boss/arenas/generic_boss_initiate