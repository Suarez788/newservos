###Remove Traps###
kill @e[tag=nitTyrantTraps,limit=5,sort=nearest]
function nitk:boss/attacks/tyrant/traps_reset