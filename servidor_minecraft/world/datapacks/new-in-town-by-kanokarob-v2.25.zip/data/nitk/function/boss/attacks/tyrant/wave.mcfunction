###Tell###
execute if entity @s[tag=nitTyrantEasy] if score @s nitBossTime matches ..79 run function nitk:boss/cosmetic/tyrant/wave_tell
execute if entity @s[tag=nitTyrantMed] if score @s nitBossTime matches ..59 run function nitk:boss/cosmetic/tyrant/wave_tell
execute if entity @s[tag=nitTyrantHard] if score @s nitBossTime matches ..39 run function nitk:boss/cosmetic/tyrant/wave_tell

###Attack###
execute if entity @s[tag=nitTyrantEasy] if score @s nitBossTime matches 89 run function nitk:boss/attacks/tyrant/wave_effect
execute if entity @s[tag=nitTyrantMed] if score @s nitBossTime matches 69 run function nitk:boss/attacks/tyrant/wave_effect
execute if entity @s[tag=nitTyrantHard] if score @s nitBossTime matches 49 run function nitk:boss/attacks/tyrant/wave_effect