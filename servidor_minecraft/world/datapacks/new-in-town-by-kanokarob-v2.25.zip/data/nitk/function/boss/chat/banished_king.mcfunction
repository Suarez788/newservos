###Scoreboard Handling###
scoreboard players add @s nitResourceSpawn 0
scoreboard players add @s nitResourceSpawn 1
scoreboard players reset @s nitResourceTime
execute if score @s nitResourceSpawn matches ..6 run playsound minecraft:entity.elder_guardian.hurt hostile @a ~ ~ ~ 2 1.4

execute if score @s nitResourceSpawn matches 1 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.banished_king","fallback":"Banished King","bold":true,"color":"dark_blue"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.banished_king.1","fallback":"Ah, a new school for me to rule.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 2 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.banished_king","fallback":"Banished King","bold":true,"color":"dark_blue"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.banished_king.2","fallback":"No matter where I find myself, I am still a King.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 3 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.banished_king","fallback":"Banished King","bold":true,"color":"dark_blue"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.banished_king.3","fallback":"If you will not submit, then this crucible shall be your tomb, too.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 4 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.banished_king","fallback":"Banished King","bold":true,"color":"dark_blue"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.banished_king.4","fallback":"I will flood your home as I have others before you.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 5 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.banished_king","fallback":"Banished King","bold":true,"color":"dark_blue"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.banished_king.5","fallback":"Drown in the might that is my majesty!","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 6 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.banished_king","fallback":"Banished King","bold":true,"color":"dark_blue"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.banished_king.6","fallback":"Banishment has done nothing to quench my thirst for power!","color":"white","bold":false}]
