###Cleanup###
bossbar remove nitk:banished_king
kill @e[tag=nitBossEntity,distance=..30]
advancement grant @a[distance=..30] only nitk:nitk/defeat_banished_king

###Score Update###
scoreboard players set @s nitResourceSpawn 2