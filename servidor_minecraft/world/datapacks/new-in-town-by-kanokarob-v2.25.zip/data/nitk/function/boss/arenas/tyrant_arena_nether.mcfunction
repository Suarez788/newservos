###Prepare Scores###
scoreboard players add @s nitSuccess 0
scoreboard players add @s nitResourceTime 0
kill @e[type=wither_skull,distance=..20,tag=!nitEntity]

##Spawn Tyrant if portals are destroyed###
execute unless entity @e[tag=nitBaseObjective,distance=..40] if score @s nitSuccess matches 0 run scoreboard players add @s nitResourceTime 1
execute if score @s nitResourceTime matches 1..199 run particle soul ~ ~4.75 ~ 0.4 0.75 0.4 0.01 10 normal
execute if score @s nitResourceTime matches 1..199 run playsound minecraft:ambient.soul_sand_valley.mood hostile @a ~ ~ ~ 1 1
execute if score @s nitResourceTime matches 200 if score @s nitSuccess matches 0 run stopsound @a hostile ambient.soul_sand_valley.mood
execute if score @s nitResourceTime matches 200 if score @s nitSuccess matches 0 run playsound entity.wither.spawn hostile @a ~ ~ ~ 5 1
execute if score @s nitResourceTime matches 200 if score @s nitSuccess matches 0 run function nitk:spawns/tyrant_nether
execute if score @s nitResourceTime matches 240 run scoreboard objectives add nitBossTime dummy
execute if score @s nitResourceTime matches 240 as @e[tag=nitTyrant,distance=..10] run function nitk:boss/arenas/generic_boss_initiate
execute if score @s nitResourceTime matches 240 run kill @e[tag=nitBossEntity,distance=..30]

###Control Tyrant and Skulls###
execute at @s run tp @e[type=wither,distance=..10,tag=nitTyrant] ~ ~4 ~
execute if entity @e[tag=nitTyrant,distance=..10] run scoreboard players set @s nitSuccess 1

###Clear Condition###
execute if score @s nitSuccess matches 1.. unless entity @e[type=wither,distance=..10] run tag @s add nitCleared
execute if entity @s[tag=nitCleared] run advancement grant @p only nitk:nitk/tyrant_defeat
execute if entity @s[tag=nitCleared] run playsound entity.generic.explode hostile @a ~ ~ ~ 2 1
execute if entity @s[tag=nitCleared] run playsound entity.wither.death hostile @a ~ ~ ~ 7 1
execute if entity @s[tag=nitCleared] run particle explosion ~ ~ ~ 1 1 1 0 10 normal
execute if entity @s[tag=nitCleared] run particle soul ~ ~1.5 ~ 1 1 1 0.1 30 normal
execute if entity @s[tag=nitCleared] run kill @e[tag=nitBossEntity,distance=..30]
execute if entity @s[tag=nitCleared] run function nitco:bases/cleared_status