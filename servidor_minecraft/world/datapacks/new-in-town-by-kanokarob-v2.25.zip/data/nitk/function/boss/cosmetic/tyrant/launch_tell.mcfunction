###Particles###
particle large_smoke ~ ~1 ~ 1.5 1.5 1.5 0.01 10
particle soul ~ ~1 ~ 1.5 1.5 1.5 0.05 5

###Sound Effects###
execute if score @s nitBossTime matches 0 run playsound entity.wither.ambient hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 9 run playsound entity.wither.ambient hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 19 run playsound entity.wither.ambient hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 29 run playsound entity.wither.ambient hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 39 run playsound entity.wither.ambient hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 49 run playsound entity.wither.ambient hostile @a ~ ~ ~ 1 2