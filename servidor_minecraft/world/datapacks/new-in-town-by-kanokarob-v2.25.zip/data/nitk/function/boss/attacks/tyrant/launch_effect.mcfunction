###Cosmetics###
particle explosion ~ ~1 ~ 1.5 1.5 1.5 0 30
particle large_smoke ~ ~1 ~ 1.5 1.5 1.5 0.7 50
particle soul ~ ~1 ~ 1.5 1.5 1.5 0.1 20
playsound entity.wither.break_block hostile @a ~ ~ ~ 3 1

###Effects###
execute if entity @s[tag=nitTyrantEasy] as @a[distance=..10,gamemode=survival,predicate=nitk:on_ground] at @s run function nitk:boss/attacks/tyrant/launch_players_easy
execute if entity @s[tag=nitTyrantMed] as @a[distance=..10,gamemode=survival,predicate=nitk:on_ground] at @s run function nitk:boss/attacks/tyrant/launch_players_med
execute if entity @s[tag=nitTyrantHard] as @a[distance=..10,gamemode=survival,predicate=nitk:on_ground] at @s run function nitk:boss/attacks/tyrant/launch_players_hard

###Cleanup###
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack3