###Cosmetic###
playsound entity.iron_golem.hurt hostile @a ~ ~ ~ 3 1.4
playsound entity.iron_golem.death hostile @a ~ ~ ~ 1 0.7
function nitk:boss/cosmetic/ancient_builder/slam_particles

###Damage###
execute as @a[gamemode=!creative,gamemode=!spectator,distance=..8,predicate=nitk:on_ground] run damage @s 6.0 minecraft:fall

###Cleanup###
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack3