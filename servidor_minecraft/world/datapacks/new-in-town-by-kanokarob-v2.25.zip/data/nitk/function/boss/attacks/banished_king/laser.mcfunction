###Tell###
execute if score @s nitBossTime matches ..59 run function nitk:boss/cosmetic/banished_king/laser_tell

###Attack###
execute if score @s nitBossTime matches 60..90 run function nitk:boss/attacks/banished_king/laser_effect

###Expire###
execute if score @s nitBossTime matches 91.. run function nitk:boss/attacks/banished_king/laser_reset