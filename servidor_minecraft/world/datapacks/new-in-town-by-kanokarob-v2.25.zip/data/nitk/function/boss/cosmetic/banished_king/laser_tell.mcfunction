###Cosmetic###
execute anchored eyes positioned ^ ^-0.5 ^2 run particle bubble ~ ~ ~ 0.5 0.5 0.5 0.01 10 normal
execute anchored eyes positioned ^ ^-0.5 ^2 run particle crit ~ ~ ~ 0.5 0.5 0.5 0.01 5 normal
execute anchored eyes positioned ^ ^-0.5 ^2 run particle end_rod ~ ~ ~ 0.5 0.5 0.5 0.01 2 normal
playsound entity.guardian.attack hostile @a ~ ~ ~ 1 2