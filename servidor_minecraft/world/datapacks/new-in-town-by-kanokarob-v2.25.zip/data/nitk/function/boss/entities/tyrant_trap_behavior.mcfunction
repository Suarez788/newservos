###Cosmetics###
particle falling_dust{block_state:"minecraft:purple_concrete_powder"} ~ ~1.5 ~ 0 0 0 0 1 normal
particle falling_dust{block_state:"minecraft:purple_concrete_powder"} ~ ~1.25 ~ 0.05 0.25 0.05 0 1 normal
particle falling_dust{block_state:"minecraft:purple_concrete_powder"} ~ ~1 ~ 0.1 0.25 0.1 0 4 normal
particle falling_dust{block_state:"minecraft:purple_concrete_powder"} ~ ~0.75 ~ 0.15 0.25 0.15 0 9 normal
particle falling_dust{block_state:"minecraft:purple_concrete_powder"} ~ ~0.5 ~ 0.2 0.25 0.2 0 12 normal

###Active Timer###
scoreboard players add @s nitBossTime 0
scoreboard players add @s nitBossTime 1

###Effects###
execute if score @s nitBossTime matches 30.. run effect give @a[gamemode=!creative,gamemode=!spectator,distance=..1.5] slowness 1 5 true
execute if score @s nitBossTime matches 30.. if entity @s[tag=nitTyrantMed] run effect give @a[gamemode=!creative,gamemode=!spectator,distance=..1.5,predicate=!nitk:has_wither] wither 1 2 true
execute if score @s nitBossTime matches 30.. if entity @s[tag=nitTyrantHard] run effect give @a[gamemode=!creative,gamemode=!spectator,distance=..1.5,predicate=!nitk:has_wither] wither 2 3 true
execute if score @s nitBossTime matches 300.. run kill @s