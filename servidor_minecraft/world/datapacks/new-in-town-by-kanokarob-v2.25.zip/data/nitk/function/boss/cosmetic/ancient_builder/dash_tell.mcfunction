###Cosmetic###
execute rotated ~ 0 run particle small_flame ^ ^1 ^-0.5 0.3 0.5 0.3 0.01 5 normal
execute rotated ~ 0 run particle smoke ^ ^1 ^-0.5 0.3 0.5 0.3 0.01 10 normal
execute if score @s nitBossTime matches 2 run playsound entity.blaze.ambient hostile @a ~ ~ ~ 3 0.7