###Cosmetics###
execute rotated ~90 0 positioned ^ ^ ^4 run function nitk:boss/cosmetic/banished_king/minion_bubbles
execute rotated ~-90 0 positioned ^ ^ ^4 run function nitk:boss/cosmetic/banished_king/minion_bubbles

###Stages###
execute if score @s nitBossTime matches 2 run playsound block.bubble_column.whirlpool_ambient hostile @a ~ ~ ~ 3 2
execute if score @s nitBossTime matches 100.. run function nitk:boss/attacks/banished_king/minions_spawn