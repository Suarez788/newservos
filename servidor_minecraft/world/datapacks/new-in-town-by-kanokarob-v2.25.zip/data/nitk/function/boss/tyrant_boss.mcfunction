###General Behavior###
scoreboard players add @s nitResourceTime 0
scoreboard players add @s nitBossTime 0
execute unless data entity @s {HurtTime:0s} run function nitk:boss/cosmetic/tyrant/damage

###Random Attack Selection###
execute if entity @s[tag=!nitTyrantHard,tag=!nitAttacking] if predicate nitk:boss/chance_1 run tag @s add nitBossAttack
execute if entity @s[tag=nitTyrantHard,tag=!nitAttacking] if score @s nitBossTime matches 40.. if predicate nitk:boss/chance_1 run tag @s add nitBossAttack
execute if score @s[tag=!nitAttacking] nitBossTime matches 71.. run tag @s add nitBossAttack
execute if entity @s[tag=nitBossAttack] run function nitk:boss/attacks/tyrant_attack_select

###Perform Attacks###
execute if entity @s[tag=nitAttack1] run function nitk:boss/attacks/tyrant/wave
execute if entity @s[tag=nitAttack2] run function nitk:boss/attacks/tyrant/skull
execute if entity @s[tag=nitAttack3] run function nitk:boss/attacks/tyrant/launch
execute if entity @s[tag=nitAttack4] run function nitk:boss/attacks/tyrant/traps
execute if entity @s[tag=nitAttack5] run function nitk:boss/attacks/tyrant/minions

###Chat Lines###
execute if score @s nitResourceTime matches 200..300 if predicate nitk:boss/chance_1 run function nitk:boss/chat/tyrant

###Increment Scores###
scoreboard players add @s nitResourceTime 1
scoreboard players add @s nitBossTime 1
execute if score @s nitResourceTime matches 301 run scoreboard players reset @s nitResourceTime