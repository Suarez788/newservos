###Cosmetic###
particle dust{color:[0.38f,0.0f, 0.541f],scale:2.0f} ~ ~0.25 ~ 0.2 0.4 0.2 0.01 5 normal
particle dust{color:[0.592f,0.082f, 0.812f],scale:2.0f} ~ ~0.25 ~ 0.2 0.4 0.2 0.01 5 normal
particle dragon_breath ~ ~0.25 ~ 0.2 0.4 0.2 0.01 5 normal
particle squid_ink ~ ~0.25 ~ 0.2 0.4 0.2 0.01 1 normal
playsound minecraft:ambient.soul_sand_valley.mood hostile @a[distance=..2] ~ ~ ~ 0.5 1