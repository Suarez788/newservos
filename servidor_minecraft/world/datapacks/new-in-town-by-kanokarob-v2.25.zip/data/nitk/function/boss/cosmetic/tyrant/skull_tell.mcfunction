###Rotate Skulls###
execute unless entity @s[tag=nitTyrantMed] anchored eyes positioned ^ ^-0.5 ^0.75 facing entity @p feet run tp @e[tag=nitTyrantSkull,limit=1,sort=nearest] ~ ~ ~ ~180 ~
execute unless entity @s[tag=nitTyrantEasy] anchored eyes rotated ~15 0 positioned ^ ^-0.5 ^0.75 facing entity @p feet run tp @e[tag=nitTyrantSkull,limit=1,sort=nearest] ~ ~ ~ ~180 ~
execute unless entity @s[tag=nitTyrantEasy] anchored eyes rotated ~-15 0 positioned ^ ^-0.5 ^0.75 facing entity @p feet run tp @e[tag=nitTyrantSkull,limit=1,sort=nearest] ~ ~ ~ ~180 ~