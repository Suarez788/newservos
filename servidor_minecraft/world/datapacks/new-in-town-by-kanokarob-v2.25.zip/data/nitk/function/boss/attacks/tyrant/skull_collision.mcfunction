###Effects###
execute if entity @s[tag=nitTyrantEasy] run effect give @a[distance=..1.9] wither 1 4 false
execute if entity @s[tag=nitTyrantEasy] as @a[distance=..1.9] run damage @s 5.0 minecraft:wither_skull
execute if entity @s[tag=nitTyrantMed] run effect give @a[distance=..1.9] wither 1 8 false
execute if entity @s[tag=nitTyrantMed] as @a[distance=..1.9] run damage @s 8.0 minecraft:wither_skull
execute if entity @s[tag=nitTyrantHard] run effect give @a[distance=..1.9] wither 2 8 false
execute if entity @s[tag=nitTyrantHard] as @a[distance=..1.9] run damage @s 12.0 minecraft:wither_skull

###Cosmetics###
playsound entity.generic.explode hostile @a ~ ~ ~ 2 1
particle explosion ~ ~ ~ 1 1 1 0 20 normal
particle soul ~ ~ ~ 0.5 0.5 0.5 0.05 20 normal
particle smoke ~ ~ ~ 0.5 0.5 0.5 0.01 10 normal
kill @s