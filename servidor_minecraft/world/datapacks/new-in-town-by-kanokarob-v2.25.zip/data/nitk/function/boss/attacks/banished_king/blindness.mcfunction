###Tell###
execute if score @s nitBossTime matches ..59 run function nitk:boss/cosmetic/banished_king/blindness_tell

###Attack###
execute if score @s nitBossTime matches 60 run function nitk:boss/attacks/banished_king/blindness_effect