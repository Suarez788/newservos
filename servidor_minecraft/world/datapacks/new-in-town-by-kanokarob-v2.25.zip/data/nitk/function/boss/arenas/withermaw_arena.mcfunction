###Scoreboard Prep###
scoreboard objectives add nitBossTime dummy
scoreboard players add @s nitResourceSpawn 0

###State Change###
execute if score @s nitResourceSpawn matches 0 if block ~ ~ ~ soul_fire run function nitk:boss/arenas/withermaw_idle
execute if block ~ ~ ~ lava run setblock ~ ~ ~ soul_fire
execute if score @s nitResourceSpawn matches 0 if block ~ ~ ~ air run function nitk:boss/arenas/withermaw_start
execute if score @s nitResourceSpawn matches 1 if block ~ ~ ~ air run function nitk:boss/arenas/withermaw_active
execute if score @s nitResourceSpawn matches 1 unless entity @a[distance=..20] run function nitk:boss/arenas/withermaw_reset