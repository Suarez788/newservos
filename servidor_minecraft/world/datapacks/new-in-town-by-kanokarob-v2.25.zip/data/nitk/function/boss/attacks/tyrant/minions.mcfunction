###Cosmetics###
execute positioned ~3 ~ ~3 run function nitk:boss/cosmetic/tyrant/minion_portal
execute positioned ~3 ~ ~-3 run function nitk:boss/cosmetic/tyrant/minion_portal
execute positioned ~-3 ~ ~3 run function nitk:boss/cosmetic/tyrant/minion_portal
execute positioned ~-3 ~ ~-3 run function nitk:boss/cosmetic/tyrant/minion_portal

###Stages###
execute if score @s nitBossTime matches 2 run playsound block.portal.trigger hostile @a ~ ~ ~ 3 1
execute if score @s nitBossTime matches 100.. run function nitk:boss/attacks/tyrant/minions_spawn