###Cleanup###
execute as @e[tag=nitBanKing,distance=..30] run function nitk:boss/boss_remove
kill @e[tag=nitBossEntity,distance=..30]
bossbar remove nitk:banished_king
setblock ~ ~ ~ diamond_block

###Score Update###
scoreboard players set @s nitResourceSpawn 0