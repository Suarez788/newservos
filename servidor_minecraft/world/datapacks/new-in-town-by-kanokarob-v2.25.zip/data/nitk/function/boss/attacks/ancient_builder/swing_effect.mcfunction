###Cosmetic###
execute if score @s nitBossTime matches 41 run playsound entity.wither_skeleton.hurt hostile @a ~ ~ ~ 3 1.3

###Movement###
tp @s ~ ~ ~ ~9 0

###Attack###
execute at @s rotated ~ 0 positioned ^ ^0.75 ^0.5 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^1.0 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^1.5 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^2.0 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^2.5 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^3.0 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^3.5 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^4.0 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^4.5 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^5.0 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^5.5 run function nitk:boss/attacks/ancient_builder/swing_step
execute at @s rotated ~ 0 positioned ^ ^0.75 ^6.0 run function nitk:boss/attacks/ancient_builder/swing_step