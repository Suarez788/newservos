###Tell###
execute if score @s nitBossTime matches ..39 run function nitk:boss/cosmetic/ancient_builder/swing_tell

###Attack###
execute if score @s nitBossTime matches 40..79 run function nitk:boss/attacks/ancient_builder/swing_effect

###Attack###
execute if score @s nitBossTime matches 80.. run function nitk:boss/attacks/ancient_builder/swing_expire