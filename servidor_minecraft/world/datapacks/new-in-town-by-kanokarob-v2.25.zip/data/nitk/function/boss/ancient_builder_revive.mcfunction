effect clear @s
data modify entity @s Health set value 150