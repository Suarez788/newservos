###Cosmetics###
function nitk:boss/cosmetic/tyrant/wave_particles
execute positioned ~ ~-0.5 ~ run function nitk:boss/cosmetic/tyrant/wave_particles
execute positioned ~ ~-1.25 ~ run function nitk:boss/cosmetic/tyrant/wave_particles

###Effects###
playsound entity.wither.ambient hostile @a ~ ~ ~ 3 1
playsound entity.player.attack.sweep hostile @a ~ ~ ~ 3 0.4
execute if entity @s[tag=nitTyrantEasy] run effect give @a[distance=..6.9] wither 4 1 false
execute if entity @s[tag=nitTyrantEasy] as @a[distance=..6.9] run damage @s 2.0 minecraft:wither
execute if entity @s[tag=nitTyrantMed] run effect give @a[distance=..6.9] wither 8 2 false
execute if entity @s[tag=nitTyrantMed] as @a[distance=..6.9] run damage @s 4.0 minecraft:wither
execute if entity @s[tag=nitTyrantHard] run effect give @a[distance=..6.9] wither 4 3 false
execute if entity @s[tag=nitTyrantHard] as @a[distance=..6.9] run damage @s 6.0 minecraft:wither

###Reset###
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack1