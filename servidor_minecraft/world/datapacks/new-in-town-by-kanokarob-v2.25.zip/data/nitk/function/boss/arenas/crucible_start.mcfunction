###Setup###
scoreboard objectives add nitBossTime dummy
function nitk:spawns/banished_king
bossbar add nitk:banished_king {"translate":"nitk.name.banished_king","fallback":"Banished King","color":"dark_blue","bold":true}
bossbar set nitk:banished_king color blue
bossbar set nitk:banished_king max 160
bossbar set nitk:banished_king visible true
kill @e[type=item,limit=1,sort=nearest,predicate=nitk:item_diamond_block]
execute as @a[distance=..3] at @s run tp ^ ^ ^-3

###Cosmetics###
playsound block.bubble_column.whirlpool_inside hostile @a ~ ~ ~ 3 0.6
playsound entity.elder_guardian.ambient hostile @a ~ ~ ~ 3 0.8
particle bubble ~ ~ ~ 1 1 1 0.05 30 normal
particle end_rod ~ ~ ~ 1 1 1 0.05 20 normal
particle glow_squid_ink ~ ~ ~ 1 1 1 0.05 10 normal

###Score Update###
scoreboard players set @s nitResourceSpawn 1