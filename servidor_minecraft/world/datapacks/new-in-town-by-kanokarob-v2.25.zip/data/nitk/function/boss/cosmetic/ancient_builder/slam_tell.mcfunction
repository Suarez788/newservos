playsound entity.iron_golem.attack hostile @a ~ ~ ~ 3 1
data modify entity @s Motion[1] set value 0.8d