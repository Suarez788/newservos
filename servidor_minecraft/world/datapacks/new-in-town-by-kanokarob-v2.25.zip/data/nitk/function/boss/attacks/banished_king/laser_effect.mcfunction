###General Cosmetic###
execute if score @s nitBossTIme matches 60 run playsound entity.guardian.attack hostile @a ~ ~ ~ 3 1
execute if score @s nitBossTIme matches 60 run playsound entity.elder_guardian.hurt hostile @a ~ ~ ~ 3 1.3

###Steps###
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^1.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^2.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^2.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^3.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^3.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^4.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^4.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^5.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^5.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^6.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^6.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^7.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^7.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^8.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^8.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^9.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^9.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^10.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^10.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^11.0 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^11.5 run function nitk:boss/attacks/banished_king/laser_step
execute unless entity @s[tag=nitBlocked] anchored eyes positioned ^ ^-0.5 ^12.0 run function nitk:boss/attacks/banished_king/laser_step
tag @s remove nitBlocked