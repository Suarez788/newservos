###Particles###
particle nautilus ~ ~1 ~ 1.5 1.5 1.5 0.05 10
particle dust{color:[0.224f,0.725f, 0.91f],scale:1.5f} ~ ~1 ~ 1.5 1.5 1.5 0 5

###Sound Effects###
execute if score @s nitBossTime matches 0 run playsound block.conduit.deactivate hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 9 run playsound block.conduit.deactivate hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 19 run playsound block.conduit.deactivate hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 29 run playsound block.conduit.deactivate hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 39 run playsound block.conduit.deactivate hostile @a ~ ~ ~ 1 2
execute if score @s nitBossTime matches 49 run playsound block.conduit.deactivate hostile @a ~ ~ ~ 1 2