particle dust{color:[0.553f,0.09f, 0.694f],scale:1.0f} ~ ~ ~ 0.3 0.75 0.3 0 20 normal
particle dust{color:[0.702f,0.122f, 0.878f],scale:1.0f} ~ ~ ~ 0.3 0.75 0.3 0 8 normal
particle portal ~ ~ ~ 0.3 0.75 0.3 0.05 5 normal