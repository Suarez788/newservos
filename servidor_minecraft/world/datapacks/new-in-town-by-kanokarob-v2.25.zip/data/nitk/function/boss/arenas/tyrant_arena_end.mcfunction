###Operating behavior###
scoreboard players add @s nitResourceTime 0
execute if entity @e[tag=nitTyrant,distance=..10] run scoreboard players add @s nitResourceTime 1
execute if score @s nitResourceTime matches 120 run scoreboard objectives add nitBossTime dummy
execute if score @s nitResourceTime matches 120 as @e[tag=nitTyrant,distance=..10] run function nitk:boss/arenas/generic_boss_initiate
tp @e[type=wither,distance=..10,tag=nitTyrant] ~ ~4 ~
kill @e[type=wither_skull,distance=..20,tag=!nitEntity]

###Clear Condition###
execute unless entity @e[type=wither,distance=..10] run advancement grant @a[predicate=nitref:end_dimension] only nitref:nitref/root