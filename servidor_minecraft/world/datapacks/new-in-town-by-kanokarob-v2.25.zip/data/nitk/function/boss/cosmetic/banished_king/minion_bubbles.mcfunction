particle dust{color:[0.318f,0.761f, 0.882f],scale:2.0f} ~ ~ ~ 0.3 0.75 0.3 0 5 normal
particle dust{color:[0.267f,0.22f, 0.682f],scale:2.0f} ~ ~ ~ 0.3 0.75 0.3 0 8 normal
particle bubble ~ ~ ~ 0.3 0.75 0.3 0.05 20 normal