###Setup###
execute if score @s nitBossTime matches 1 run data modify entity @s NoAI set value 1b
execute if score @s nitBossTime matches 1 run playsound entity.wither_skeleton.ambient hostile @a ~ ~ ~ 3 0.4

###Cosmetic###
particle crit ~ ~1 ~ 0.3 0.5 0.3 0.05 10 normal
particle smoke ~ ~1 ~ 0.3 0.5 0.3 0.05 5 normal

###Movement###
tp @s ~ ~ ~ ~12 0