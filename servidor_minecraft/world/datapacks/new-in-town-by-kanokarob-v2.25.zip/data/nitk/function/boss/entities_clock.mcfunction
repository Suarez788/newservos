###Distributes boss-adjacent entity functions for projectiles and similar###
execute if entity @s[tag=nitTyrantSkull] run function nitk:boss/entities/tyrant_skull_behavior
execute if entity @s[tag=nitTyrantTrap] positioned ~ ~2 ~ run function nitk:boss/entities/tyrant_trap_behavior