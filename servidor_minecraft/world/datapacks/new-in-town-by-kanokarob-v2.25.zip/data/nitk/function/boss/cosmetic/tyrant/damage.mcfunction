data modify entity @s HurtTime set value 0s
playsound entity.wither.hurt hostile @a ~ ~ ~ 1 1