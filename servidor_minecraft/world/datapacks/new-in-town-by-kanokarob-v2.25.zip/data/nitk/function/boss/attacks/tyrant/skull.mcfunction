###Summon Skulls###
execute if score @s nitBossTime matches 2 anchored eyes positioned ^ ^ ^0.65 run function nitk:boss/attacks/tyrant/skull_summon

###Tell###
execute if entity @s[tag=nitTyrantEasy] if score @s nitBossTime matches ..59 run function nitk:boss/cosmetic/tyrant/skull_tell
execute if entity @s[tag=nitTyrantMed] if score @s nitBossTime matches ..39 run function nitk:boss/cosmetic/tyrant/skull_tell
execute if entity @s[tag=nitTyrantHard] if score @s nitBossTime matches ..19 run function nitk:boss/cosmetic/tyrant/skull_tell

###Attack###
execute if entity @s[tag=nitTyrantEasy] if score @s nitBossTime matches 60 run function nitk:boss/attacks/tyrant/skull_effect
execute if entity @s[tag=nitTyrantMed] if score @s nitBossTime matches 40 run function nitk:boss/attacks/tyrant/skull_effect
execute if entity @s[tag=nitTyrantHard] if score @s nitBossTime matches 20 run function nitk:boss/attacks/tyrant/skull_effect