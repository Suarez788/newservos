###Cosmetics###
particle smoke ~ ~0.2 ~ 0.3 0.2 0.3 0.05 20
particle soul ~ ~1 ~ 0.3 0.2 0.3 0.05 10
playsound entity.player.hurt player @a ~ ~ ~ 1 1

###Effects###
effect give @s levitation 1 11 true
effect give @s wither 2 5 false
damage @s 12.0 minecraft:wither