###Spawn Minions###
execute positioned ~3 ~ ~3 run function nitk:spawns/tyrant_minion
execute positioned ~3 ~ ~-3 run function nitk:spawns/tyrant_minion
execute positioned ~-3 ~ ~3 run function nitk:spawns/tyrant_minion
execute positioned ~-3 ~ ~-3 run function nitk:spawns/tyrant_minion

###Cleanup###
playsound block.portal.travel hostile @a ~ ~ ~ 1 1
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack5