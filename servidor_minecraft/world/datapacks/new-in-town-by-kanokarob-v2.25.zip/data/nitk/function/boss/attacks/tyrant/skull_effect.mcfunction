###Launch Skulls###
tag @e[tag=nitTyrantSkull,tag=!nitLaunched,limit=3,sort=nearest] add nitLaunched
playsound entity.wither.shoot master @a ~ ~ ~ 2 1

###Cleanup###
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack2