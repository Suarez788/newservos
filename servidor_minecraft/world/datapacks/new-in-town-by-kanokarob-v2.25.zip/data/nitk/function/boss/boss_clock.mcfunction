###Distributes Boss-specific Functions###
execute if entity @s[tag=nitTyrant] if entity @a[distance=..25] run function nitk:boss/tyrant_boss
execute if entity @s[tag=nitBanKing] run function nitk:boss/banished_king_boss
execute if entity @s[tag=nitAncientBuilder] run function nitk:boss/ancient_builder_boss