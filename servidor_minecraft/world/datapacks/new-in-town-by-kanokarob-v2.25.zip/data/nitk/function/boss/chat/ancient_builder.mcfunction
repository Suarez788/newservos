###Scoreboard Handling###
scoreboard players add @s nitResourceSpawn 0
scoreboard players add @s nitResourceSpawn 1
scoreboard players reset @s nitResourceTime
execute if score @s nitResourceSpawn matches ..6 run playsound entity.wither_skeleton.ambient hostile @a ~ ~ ~ 2 1.4

execute if score @s nitResourceSpawn matches 1 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.ancient_builder","fallback":"Ancient Builder","bold":true,"color":"dark_red"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.ancient_builder.1","fallback":"You will pay for my sins.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 2 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.ancient_builder","fallback":"Ancient Builder","bold":true,"color":"dark_red"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.ancient_builder.2","fallback":"We who haunt are ourselves haunted.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 3 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.ancient_builder","fallback":"Ancient Builder","bold":true,"color":"dark_red"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.ancient_builder.3","fallback":"Forgive me for what I have wrought, and for what I must do to atone.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 4 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.ancient_builder","fallback":"Ancient Builder","bold":true,"color":"dark_red"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.ancient_builder.4","fallback":"My soul cannot rest in this wretched place.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 5 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.ancient_builder","fallback":"Ancient Builder","bold":true,"color":"dark_red"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.ancient_builder.5","fallback":"His tyranny knows no bounds. We were fools to tempt fate.","color":"white","bold":false}]

execute if score @s nitResourceSpawn matches 6 run tellraw @a[distance=..30] ["",{"text":"[","color":"white","bold":false},{"translate":"nitk.name.ancient_builder","fallback":"Ancient Builder","bold":true,"color":"dark_red"},{"text":"]: ","color":"white","bold":false},{"translate":"nitk.dialogue.ancient_builder.6","fallback":"Release me, mortal, and fulfill my wish of peace and life.","color":"white","bold":false}]