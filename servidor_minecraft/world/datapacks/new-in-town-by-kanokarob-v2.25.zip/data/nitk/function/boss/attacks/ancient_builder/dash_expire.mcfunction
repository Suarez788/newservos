###Cosmetic###
playsound entity.blaze.death hostile @a ~ ~ ~ 2 1.3
particle large_smoke ~ ~1 ~ 0.5 0.5 0.5 0.1 20 normal

###Cleanup###
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack1