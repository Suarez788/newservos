###Spawn Minions###
execute rotated ~90 0 positioned ^ ^ ^4 run function nitk:spawns/guardian_minion
execute rotated ~-90 0 positioned ^ ^ ^4 run function nitk:spawns/guardian_minion

###Cleanup###
playsound block.bubble_column.whirlpool_inside hostile @a ~ ~ ~ 3 0.8
scoreboard players reset @s nitBossTime
tag @s remove nitAttacking
tag @s remove nitAttack1