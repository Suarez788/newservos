scoreboard objectives add nitContract trigger
loot spawn ~ ~ ~ loot nitk:command/getbook