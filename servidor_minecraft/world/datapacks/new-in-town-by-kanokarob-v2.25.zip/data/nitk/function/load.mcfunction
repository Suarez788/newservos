###Sets scoreboards used for advancements, attacks, and resource spawning###
scoreboard objectives add nitTutorialStatus dummy
scoreboard objectives add nitTutorial trigger

###Gamerules###
gamerule minecraft:command_block_output false

###Starts the Scheduled Functions###
function nitk:scheduler