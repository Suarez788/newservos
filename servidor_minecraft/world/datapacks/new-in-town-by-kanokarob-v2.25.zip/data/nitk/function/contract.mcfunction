###Sets scoreboards used for advancements, attacks, and resource spawning###
scoreboard objectives add nitSiteCraft dummy
scoreboard objectives add nitCastleCraft dummy
scoreboard objectives add nitHellAttacks dummy
scoreboard objectives add nitResourceTime dummy
scoreboard objectives add nitBossTime dummy
scoreboard objectives add nitResourceSpawn dummy
scoreboard objectives add nitTaxSpawn dummy
scoreboard objectives add nitID dummy
scoreboard objectives add nitTemp dummy
scoreboard objectives add nitSpreadLim dummy
scoreboard objectives add nitRoadType dummy
scoreboard objectives add nitLightType dummy
scoreboard objectives add nitPostType dummy
scoreboard objectives add nitRaidProg dummy
scoreboard objectives add nitSuccess dummy
scoreboard objectives add nitPosx dummy
scoreboard objectives add nitPosy dummy
scoreboard objectives add nitPosz dummy
scoreboard objectives add nitRandom dummy
tag @s add nitkFounder
gamerule minecraft:command_blocks_work true

###Create the settler wagon###
place template nitk:wagon ~-7 ~-3 ~-7
tp @s ~ ~2 ~

###Place siteplanners at borders###
place template nitk:siteplanner_e ~7 ~ ~
place template nitk:siteplanner_w ~-7 ~ ~
place template nitk:siteplanner_n ~ ~ ~-7
place template nitk:siteplanner_s ~ ~ ~7

###Remove the charter###
clear @s written_book[custom_data={nitContractBook:1b,nit_particleType:1b}]

###Assigns the town's ID###
tag @a[distance=..20] add nitCitizen
execute store result score @s nitID run data get entity @s UUID[0]
scoreboard players operation @e[tag=nitResourceHopper,limit=2,sort=nearest,distance=..10] nitID = @s nitID

###Assigns wagon color###
execute at @s run function nitk:wagon_color

###Summons markers for hell attacks###
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellSite1,nitHellSite,smithed.entity,smithed.strict],Invulnerable:1b}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellSite2,nitHellSite,smithed.entity,smithed.strict],Invulnerable:1b}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellSite3,nitHellSite,smithed.entity,smithed.strict],Invulnerable:1b}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellSite4,nitHellSite,smithed.entity,smithed.strict],Invulnerable:1b}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellSite5,nitHellSite,smithed.entity,smithed.strict],Invulnerable:1b}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHellSite6,nitHellSite,smithed.entity,smithed.strict],Invulnerable:1b}
scoreboard players operation @e[tag=nitHellSite,limit=6,sort=nearest] nitID = @s nitID

###Spreads the hell attack markers for this town###
function nitk:id_match_self
scoreboard players set @s nitSpreadLim 0
function nitk:spread_hell

###Summons markers for natural structures###
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitEndVault,nitKSpecialFeature,smithed.entity,smithed.strict],Invulnerable:1b,NoGravity:1b}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitCrucible,nitKSpecialFeature,smithed.entity,smithed.strict],Invulnerable:1b,NoGravity:1b}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitHaroldCage,nitKSpecialFeature,smithed.entity,smithed.strict],Invulnerable:1b,NoGravity:1b}
summon minecraft:marker ~ ~ ~ {Tags:[nitEntity,nitTicking,nitEntityTechnical,nitSundial,nitKSpecialFeature,smithed.entity,smithed.strict],Invulnerable:1b,NoGravity:1b}
scoreboard players operation @e[tag=nitKSpecialFeature,limit=4,sort=nearest] nitID = @s nitID

###Spreads and builds the natural structures for this town###
function nitk:id_match_self
scoreboard players set @s nitSpreadLim 0
function nitk:spread_features

execute as @s[tag=nitDistanceWarn] run tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.natural_features.warning","fallback":"Beware, some features may not have spawned due to lack of terrain.","color":"red","bold":false}]
tag @s remove nitDistanceWarn

###Summons the town planner###
execute as @e[tag=nitTownPlanner,limit=1,sort=nearest] at @s run summon villager ~ ~ ~ {VillagerData:{profession:cartographer,level:4,type:"plains"},Invulnerable:1b,PersistenceRequired:1b,NoAI:1b,CustomName:{"translate":"nitk.name.town_planner","fallback":"Town Planner"},Offers:{Recipes:[{buy:{id:"minecraft:feather",count:1},sell:{id:"minecraft:written_book",count:1},maxUses:9999999},{buy:{id:gold_ingot,count:4},sell:{id:"minecraft:paper",count:1,components:{"minecraft:custom_model_data": {floats:[8601000.0f]}, "minecraft:item_name": {"color":"blue","fallback":"Building Permit","italic":false,"translate":"nitk.item.building_permit"}, "minecraft:lore": [{"color":"gray","fallback":"The final ingredient","italic":false,"translate":"nitk.item.building_permit.desc.1"}, {"color":"gray","fallback":"in new town structures.","italic":false,"translate":"nitk.item.building_permit.desc.2"}], "minecraft:enchantment_glint_override": 1b, "minecraft:custom_data": {nitk_buildingPermit: 1b}}},maxUses:9999999},{buy:{id:gold_ingot,count:24},buyB:{id:"minecraft:paper",count:1,components:{"minecraft:custom_model_data": {floats:[8601000.0f]}, "minecraft:item_name": {"color":"blue","fallback":"Building Permit","italic":false,"translate":"nitk.item.building_permit"}, "minecraft:lore": [{"color":"gray","fallback":"The final ingredient","italic":false,"translate":"nitk.item.building_permit.desc.1"}, {"color":"gray","fallback":"in new town structures.","italic":false,"translate":"nitk.item.building_permit.desc.2"}], "minecraft:enchantment_glint_override": 1b, "minecraft:custom_data": {nitk_buildingPermit: 1b}}},sell:{id:"minecraft:paper",count:6,components:{"minecraft:custom_model_data": {floats:[8601001.0f]}, "minecraft:item_name": {"color":"blue","fallback":"Castle Permit","italic":false,"translate":"nitk.item.castle_permit"}, "minecraft:lore": [{"color":"gray","fallback":"For preparing sites","italic":false,"translate":"nitk.item.castle_permit.desc.1"}, {"color":"gray","fallback":"for a unified fortress.","italic":false,"translate":"nitk.item.castle_permit.desc.2"}], "minecraft:enchantment_glint_override": 1b, "minecraft:custom_data": {nitk_castlePermit: 1b}}},maxUses:1}]},Tags:[nitCitizen,nitKTP,smithed.entity,smithed.strict,nitEntity,nitTicking]}
scoreboard players operation @e[type=minecraft:villager,tag=nitKTP,limit=1,sort=nearest] nitID = @s nitID
scoreboard players operation @e[tag=nitTownPlanner,limit=1,sort=nearest] nitID = @s nitID
function nitk:debug/update_all

###Informs of completion###
tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.contract.success","fallback":"You have successfully settled at this location!","color":"white","bold":false}]