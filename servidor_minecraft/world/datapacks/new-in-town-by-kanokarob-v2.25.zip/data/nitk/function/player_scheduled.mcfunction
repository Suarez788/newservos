###Starts the settlement if the player used a Charter Book###
execute if score @s nitContract matches 15 run function nitk:use_charter
execute if score @s nitContract matches 31 run function nitco:contract_test
execute if score @s nitContract matches 63 run function nitref:contract_test

###Handles scheduled Tutorial features###
scoreboard players enable @s nitTutorial
execute if score @s nitTutorialStatus matches 1.. run function nitk:tutorial/location_check

###Checks if there isn't an Ender Dragon and gives the appropriate advancement###
execute if entity @s[predicate=nitref:end_dimension,advancements={nitco:nitco/summon_tyrant=true,nitref:nitref/invasion=false}] run function nitref:invasion_grant

###Adds nearby Endermen to the team friendly to the player###
execute if entity @s[team=nitFriendEnd,predicate=nitref:end_dimension] as @e[type=enderman,tag=!smithed.entity,tag=!smithed.strict,distance=..10] run function nitref:team_handle