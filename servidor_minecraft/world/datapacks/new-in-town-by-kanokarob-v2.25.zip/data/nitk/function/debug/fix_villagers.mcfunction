tag @e[tag=nitMiner] add nitTicking
tag @e[tag=nitLumberer] add nitTicking
tag @e[type=minecraft:villager,tag=nitDenizen] add nitTicking
tag @e[tag=nitChorister] add nitTicking
tag @e[tag=nitEndstoneer] add nitTicking
tag @e[tag=nitShroomer] add nitTicking