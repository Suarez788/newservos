###Revokes all quests from player###
advancement revoke @s from nitk:adventure/technical_kill_quest
advancement revoke @s from nitk:adventure/technical_location_quest
advancement revoke @s from nitk:adventure/technical_loot_quest
advancement revoke @s from nitk:adventure/technical_other_quest

###Informs player###
tellraw @s [{"text":"[۩]","color":"green","bold":true},{"text":": ","color":"white","bold":false},{"translate":"nitk.adventure.abandon","fallback":"Your current quest(s) has been abandoned. Visit the Adventurer for a new quest.","color":"blue","bold":true}]