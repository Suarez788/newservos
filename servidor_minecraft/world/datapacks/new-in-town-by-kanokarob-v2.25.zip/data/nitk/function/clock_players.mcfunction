###Triggers###
execute if entity @s[predicate=nitk:contract] run function nitk:contract_enable
execute if score @s nitTutorial matches 1 run function nitk:tutorial/toggle
execute if score @s nitTutorial matches 2 run function nitk:tutorial/enable
execute if score @s nitTutorial matches 3 run function nitk:tutorial/disable

###Anounces daily resources###
execute if entity @s[tag=nitInform] run function nitk:recurs/daily_inform

###Keeps the final advancement from being achieved until the last moment###
advancement revoke @s[advancements={nitk:nitk/tyrant_defeat=false}] only nitk:nitk/enter_nether to-nether

###Clears Lamp Post items periodically###
clear @s oak_fence[custom_data={nitk_post:1b}]
clear @s oak_fence[custom_data={nitk_post:2b}]
clear @s cobblestone_wall[custom_data={nitk_post:3b}]
clear @s brick_wall[custom_data={nitk_post:4b}]
clear @s stone_brick_wall[custom_data={nitk_post:5b}]
clear @s sandstone_wall[custom_data={nitk_post:6b}]
clear @s nether_brick_wall[custom_data={nitk_post:7b}]
clear @s torch[custom_data={nitk_light:1b}]
clear @s lantern[custom_data={nitk_light:2b}]
clear @s redstone_lamp[custom_data={nitk_light:3b}]
clear @s candle[custom_data={nitk_light:4b}]
clear @s campfire[custom_data={nitk_light:5b}]
clear @s glowstone[custom_data={nitk_light:6b}]
clear @s sea_lantern[custom_data={nitk_light:7b}]