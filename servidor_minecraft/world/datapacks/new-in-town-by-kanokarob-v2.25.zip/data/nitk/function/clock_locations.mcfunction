###Performs once-per-day functions###
execute if predicate nitk:time/evening run function nitk:time_evening
execute if predicate nitk:time/noon run function nitk:time_noon
execute if entity @s[tag=nitFestival] if predicate nitk:time/festival run function nitk:recurs/festival
execute if entity @s[tag=nitTownSquare] if predicate nitk:time/visitor_arrive run function nitk:recurs/town_square/visitor_check
execute if entity @s[tag=nitObservatory] if predicate nitk:time/midnight if entity @a[tag=nitCitizen,distance=..12] run function nitk:recurs/observatory/spawn_meteor

###Handles Siteplanner behavior###
execute if entity @s[tag=nitSitePlanner] run function nitk:siteplanner/behavior

###Performs functions for some town, fortress, and city structures###
execute if entity @s[tag=nitPowerElectricity] facing entity @e[tag=nitPowerElectricity,sort=furthest,limit=1,distance=..10] feet run function nitk:recurs/electricity_cosmetic
execute if entity @s[tag=nitRaid] run function nitk:recurs/town_square/raid_clock
execute if entity @s[tag=nitWizardTower] run function nitk:recurs/wizard_tower
execute if entity @s[tag=nitGateLever] run function nitk:recurs/gate_lever
execute if entity @s[tag=nitMeteor,tag=nitGenerated] run function nitk:recurs/observatory/meteor_particles
execute if entity @s[tag=nitMagicFarm] as @e[type=item,distance=..7,tag=!smithed.entity] unless data entity @s Thrower run function nitco:recurs/magic_farm
execute if entity @s[tag=nitHeartPiston] run function nitk:recurs/heart_door
execute if entity @s[tag=nitEndstoneGen] run function nitref:recurs/endstone_generator
execute if entity @s[tag=nitGCarrot] as @e[type=item,predicate=nitref:item_gcarrot,distance=..9,tag=!smithed.entity] unless data entity @s Thrower run function nitref:recurs/gold_carrot_farm
execute if entity @s[tag=nitDragonCrystalAura] unless entity @e[tag=nitDragonCrystal,distance=..4] run function nitref:recurs/dragonology/crystal_aura

###Runs the special functions for some natural structures###
execute if entity @s[tag=nitAlignPuz] run function nitk:special/puzzleclock
execute if entity @s[tag=nitTyrantEntity] run function nitk:attacks/clock_attacks
execute if entity @s[tag=nitBoss] run function nitk:boss/boss_clock
execute if entity @s[tag=nitBossArena] run function nitk:boss/arena_clock
execute if entity @s[tag=nitBossEntity] run function nitk:boss/entities_clock
execute if entity @s[tag=nitBoxMarker,scores={nitBoxProg=..6}] unless block ~ ~ ~ minecraft:trapped_chest run function nitco:special/paradox_box/box_reset
execute if entity @s[tag=nitTyrantGhast,tag=!nitTyrantObjective] run function nitk:attacks/ghast_behavior

###Alters the town planner and makes him sparkle, revealing new End recipes###
execute if entity @s[tag=nitKTP] run function nitref:planner_update/clock

###Performs checks for the portal banners used during invasion###
execute if entity @s[tag=nitInvasionPortal] run function nitref:invasion/banners