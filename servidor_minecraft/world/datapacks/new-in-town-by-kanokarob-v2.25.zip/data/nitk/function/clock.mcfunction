###Searches for all NiT entitites to attempt to run the appropriate tick and location-based functions###
execute as @e[tag=nitTicking] at @s run function nitk:clock_locations

###Executes player functions###
execute as @a at @s run function nitk:clock_players