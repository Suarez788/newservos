place template namespace:town/castle/ft_template ~-5 ~-1 ~-5

function nitk:siteplanner/castleplanner/castle_cleanup