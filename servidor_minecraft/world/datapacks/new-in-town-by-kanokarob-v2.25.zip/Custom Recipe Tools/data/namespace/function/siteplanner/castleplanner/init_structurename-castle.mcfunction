advancement revoke @s only namespace:recipes/castle/recipe_structurename

execute as @e[tag=nitKCastlePlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function namespace:siteplanner/castleplanner/build_structurename