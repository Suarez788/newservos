advancement revoke @s only namespace:recipes/recipe_structurename

execute as @e[tag=nitCKeepPlanner,limit=1,sort=nearest,distance=..3] at @s positioned ~ ~-1 ~ run function namespace:siteplanner/keep/build_structurename