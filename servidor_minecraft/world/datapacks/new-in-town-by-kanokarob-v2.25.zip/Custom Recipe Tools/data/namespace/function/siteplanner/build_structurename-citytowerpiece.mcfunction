place template namespace:city/structurename ~-7 ~ ~-8
setblock ~ 255 ~-1 minecraft:barrier

###Places the siteplanner on top###
place template nitref:siteplanner ~ ~8 ~

function nitref:siteplanner/cleanup