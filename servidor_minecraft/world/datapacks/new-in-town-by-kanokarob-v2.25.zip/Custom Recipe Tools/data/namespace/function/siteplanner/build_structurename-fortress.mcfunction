execute if entity @s[tag=nitSiteEast] run place template namespace:fortress/structurename ~1 ~-6 ~-7

execute if entity @s[tag=nitSiteWest] run place template namespace:fortress/structurename ~-15 ~-6 ~-7

execute if entity @s[tag=nitSiteNorth] run place template namespace:fortress/structurename ~-7 ~-6 ~-15

execute if entity @s[tag=nitSiteSouth] run place template namespace:fortress/structurename ~-7 ~-6 ~1

function nitco:siteplanner/new_sites_check