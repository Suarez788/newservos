place template namespace:city/structurename ~-7 ~ ~-8
setblock ~ 255 ~-1 minecraft:barrier

function nitref:siteplanner/cleanup