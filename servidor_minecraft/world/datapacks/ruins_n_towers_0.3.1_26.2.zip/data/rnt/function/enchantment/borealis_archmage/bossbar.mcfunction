bossbar add rnt:borealis_archmage "Borealis Archmage"
bossbar set rnt:borealis_archmage color blue
bossbar set rnt:borealis_archmage style notched_10
bossbar set rnt:borealis_archmage max 100
tag @s remove rnt.bossbar_pending
