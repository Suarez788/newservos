scoreboard players add @s rnt.ability.cd 1
execute if score @s rnt.ability.cd matches 600.. run return run function rnt:enchantment/slime_wizard/slime/to_small
execute if score @s rnt.ability.cd matches ..200 if predicate rnt:chance/0_1 run function rnt:enchantment/slime_wizard/slime/ignore
