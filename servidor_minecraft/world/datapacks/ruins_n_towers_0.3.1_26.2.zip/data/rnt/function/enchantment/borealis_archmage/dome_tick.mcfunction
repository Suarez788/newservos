execute as @s[tag=rnt.bool] run return run tag @s remove rnt.bool

rotate @s ~3 ~
function rnt:enchantment/borealis_archmage/draw_dome
scoreboard players remove @s rnt.dmg.cd 1
tag @s add rnt.bool

execute at @s positioned ~-3 ~-1 ~-3 as @a[dx=5,dy=3,dz=5] positioned ~3 ~1 ~3 as @a[distance=..3] run function rnt:enchantment/borealis_archmage/dome_attack
execute as @a[tag=rnt.under_effect,distance=3.5..32] run function rnt:enchantment/borealis_archmage/dome_exit
execute if score @s rnt.dmg.cd matches ..0 run function rnt:enchantment/borealis_archmage/dome_end
