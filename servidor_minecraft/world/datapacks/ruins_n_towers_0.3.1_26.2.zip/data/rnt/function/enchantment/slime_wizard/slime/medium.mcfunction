execute unless entity @n[type=minecraft:slime,tag=rnt.minion,distance=..24,scores={rnt.boss.stat=4..}] run scoreboard players add @s rnt.ability.cd 1
execute if score @s rnt.ability.cd matches 900.. run return run function rnt:enchantment/slime_wizard/slime/to_big
execute if score @s rnt.ability.cd matches ..200 if predicate rnt:chance/0_1 run function rnt:enchantment/slime_wizard/slime/ignore
