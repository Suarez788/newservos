summon minecraft:area_effect_cloud ~ ~ ~ {Radius:1.5,Duration:60,potion_contents:{potion:"minecraft:healing"}}
scoreboard players set @s rnt.ability.cd -200
