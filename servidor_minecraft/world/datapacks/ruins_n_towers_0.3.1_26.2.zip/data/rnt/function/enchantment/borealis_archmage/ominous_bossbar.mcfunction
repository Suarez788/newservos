bossbar add rnt:borealis_archmage "Ominous Borealis Archmage"
bossbar set rnt:borealis_archmage color blue
bossbar set rnt:borealis_archmage style notched_12
bossbar set rnt:borealis_archmage max 120
tag @s remove rnt.bossbar_pending
