$summon falling_block ~$(x) ~$(y) ~$(z) {BlockState:{Name:"minecraft:ice"},DropItem:0b,CancelDrop:1b,HurtEntities:1b,FallHurtMax:40,fall_distance:$(fall)f,FallHurtAmount:0.2f}
