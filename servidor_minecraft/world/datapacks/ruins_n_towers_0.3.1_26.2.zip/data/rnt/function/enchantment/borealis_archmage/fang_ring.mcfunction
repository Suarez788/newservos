playsound minecraft:entity.evoker.prepare_wololo hostile
scoreboard players add @s rnt.ability.cd 40
effect give @s minecraft:instant_damage 1 1
# Ring 1
execute positioned ~1.25 ~ ~0.0 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.3863 ~ ~1.1888 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.0113 ~ ~0.7347 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.0113 ~ ~-0.7347 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.3863 ~ ~-1.1888 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
# Ring 2
execute positioned ~-0.0 ~ ~2.125 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.6614 ~ ~1.3249 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-2.0717 ~ ~-0.4729 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-0.922 ~ ~-1.9146 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.922 ~ ~-1.9146 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~2.0717 ~ ~-0.4729 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~1.6614 ~ ~1.3249 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
# Ring 3
execute positioned ~-3.0 ~ ~-0.0 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-2.5238 ~ ~-1.6219 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.2462 ~ ~-2.7289 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.4269 ~ ~-2.9695 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~1.9646 ~ ~-2.2672 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~2.8785 ~ ~-0.8452 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~2.8785 ~ ~0.8452 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~1.9646 ~ ~2.2672 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.4269 ~ ~2.9695 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.2462 ~ ~2.7289 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-2.5238 ~ ~1.6219 if block ~ ~ ~ #rnt:unobstructed run summon minecraft:evoker_fangs ~ ~ ~