summon minecraft:area_effect_cloud ~ ~ ~ {Radius:2.25,Duration:70,potion_contents:{potion:"minecraft:harming"}}
scoreboard players set @s rnt.dmg.cd -100
