bossbar add rnt:slime_wizard "Slime Wizard"
bossbar set rnt:slime_wizard color green
bossbar set rnt:slime_wizard style notched_10
bossbar set rnt:slime_wizard max 100
tag @s remove rnt.bossbar_pending

function rnt:enchantment/slime_wizard/slime/summon
function rnt:enchantment/slime_wizard/sleep
