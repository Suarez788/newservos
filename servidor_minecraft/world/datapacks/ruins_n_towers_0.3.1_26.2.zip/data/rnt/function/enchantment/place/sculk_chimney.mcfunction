place structure rnt:unlocatable/sculk_chimney
kill @s
