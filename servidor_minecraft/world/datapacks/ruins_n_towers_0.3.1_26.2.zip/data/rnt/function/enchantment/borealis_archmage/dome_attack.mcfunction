execute as @s[tag=rnt.under_effect] run return run damage @s 0.5 minecraft:freeze

attribute @s minecraft:attack_speed modifier add rnt:freezed -0.4 add_multiplied_total
attribute @s minecraft:jump_strength modifier add rnt:freezed -0.5 add_multiplied_total
attribute @s minecraft:movement_speed modifier add rnt:freezed -0.8 add_multiplied_total
effect give @n[type=minecraft:skeleton,tag=rnt.boss,distance=..16] minecraft:instant_damage 1 0
tag @s add rnt.under_effect
