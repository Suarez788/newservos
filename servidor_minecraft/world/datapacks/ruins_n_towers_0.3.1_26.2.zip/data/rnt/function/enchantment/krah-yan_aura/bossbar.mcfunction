bossbar add rnt:krah-yan_shadow "Krah-Yan's Shadow"
bossbar set rnt:krah-yan_shadow color yellow
bossbar set rnt:krah-yan_shadow style notched_10
bossbar set rnt:krah-yan_shadow max 100
tag @s remove rnt.bossbar_pending
