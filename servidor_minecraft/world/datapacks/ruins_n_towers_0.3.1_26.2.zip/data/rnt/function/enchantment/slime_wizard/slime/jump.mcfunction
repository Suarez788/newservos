tag @s add rnt.b.jump
effect give @s minecraft:jump_boost 4 2 true
attribute @s minecraft:explosion_knockback_resistance base set 1
