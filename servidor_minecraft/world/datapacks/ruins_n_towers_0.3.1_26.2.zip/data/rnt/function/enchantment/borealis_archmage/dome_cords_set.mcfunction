$execute positioned over world_surface positioned ~$(x) ~ ~$(z) run function rnt:enchantment/borealis_archmage/dome_cords_check
