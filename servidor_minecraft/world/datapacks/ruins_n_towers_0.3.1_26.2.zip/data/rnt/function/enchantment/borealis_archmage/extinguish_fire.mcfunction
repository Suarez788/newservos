data modify entity @s Fire set value 1
playsound minecraft:entity.wind_charge.wind_burst hostile @a[distance=..16] ~ ~ ~ 1.8 0.5
particle minecraft:cloud ~-0.5 ~-0.25 ~-0.5 1 1 1 0.5 40

fill ~8 ~1 ~8 ~-8 ~-1 ~-8 minecraft:air replace #minecraft:fire
fill ~6 ~2 ~6 ~-6 ~ ~-6 minecraft:powder_snow replace minecraft:water[level=0]
fill ~6 ~2 ~6 ~-6 ~ ~-6 minecraft:blackstone replace minecraft:lava[level=0]
fill ~5 ~1 ~5 ~-5 ~-1 ~-5 minecraft:campfire[lit=false] replace minecraft:campfire[lit=true]
fill ~5 ~1 ~5 ~-5 ~-1 ~-5 minecraft:soul_campfire[lit=false] replace minecraft:soul_campfire[lit=true]
fill ~0.125 ~4 ~0.125 ~-0.125 ~-1 ~-0.125 minecraft:air replace minecraft:iron_bars destroy

execute at @s positioned ~-8 ~-1 ~-8 as @a[dx=15,dy=4,dz=15] positioned ~8 ~1 ~8 as @a[distance=..5] run damage @s 1 minecraft:freeze
execute at @s positioned ~-2 ~-1 ~-2 as @a[dx=3,dy=4,dz=3] positioned ~2 ~1 ~2 as @a[distance=..3] run damage @s 2 minecraft:freeze
effect give @s minecraft:instant_damage 1 0
 