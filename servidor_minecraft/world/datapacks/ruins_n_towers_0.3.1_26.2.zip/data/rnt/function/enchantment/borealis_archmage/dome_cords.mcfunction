execute store result storage rnt:borealis x float 0.2 run random value -20..20
execute store result storage rnt:borealis z float 0.2 run random value -20..20

return run function rnt:enchantment/borealis_archmage/dome_cords_set with storage rnt:borealis

execute store result storage rnt:borealis x float 0.5 run random value -6..6
execute store result storage rnt:borealis z float 0.5 run random value -6..6

execute at @s as @r[distance=..11] at @s run function rnt:enchantment/borealis_archmage/dome_cords_set with storage rnt:borealis
