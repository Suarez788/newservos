tag @s remove rnt.b.dome
tag @s remove rnt.b.exfire
tag @s remove rnt.b.fang_ring
tag @s remove rnt.b.ice_knives
tag @s remove rnt.b.ice_rain

function rnt:enchantment/borealis_archmage/set_attack
scoreboard players set @s rnt.ability.cd -120
execute if score @s rnt.mob.health matches ..60 run scoreboard players add @s rnt.ability.cd 40

execute as @s[tag=rnt.b.ice_knives] at @s run return run function rnt:enchantment/borealis_archmage/summon_ice_knives
execute as @s[tag=rnt.b.ice_rain] at @s run return run function rnt:enchantment/borealis_archmage/ice_rain
execute as @s[tag=rnt.b.dome] at @s run return run function rnt:enchantment/borealis_archmage/dome_cords
execute as @s[tag=rnt.b.fang_ring] at @s run return run function rnt:enchantment/borealis_archmage/fang_ring
execute as @s[tag=rnt.b.exfire] at @s run return run function rnt:enchantment/borealis_archmage/extinguish_fire
