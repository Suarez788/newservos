execute as @a[tag=rnt.under_effect,distance=..160] run function rnt:enchantment/borealis_archmage/dome_exit

kill
