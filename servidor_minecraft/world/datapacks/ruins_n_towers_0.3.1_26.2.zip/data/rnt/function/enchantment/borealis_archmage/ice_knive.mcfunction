execute unless block ~ ~ ~ minecraft:air run return run function rnt:enchantment/borealis_archmage/ice_knive_end
execute unless entity @n[type=minecraft:skeleton,distance=..11] run return run function rnt:enchantment/borealis_archmage/ice_knive_end

execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0] run return run function rnt:enchantment/borealis_archmage/ice_knive_end

function rnt:enchantment/borealis_archmage/ice_knive_step with storage rnt:borealis
