playsound minecraft:entity.evoker.prepare_wololo hostile
scoreboard players add @s rnt.ability.cd 40
effect give @s minecraft:instant_damage 1 2
# Ring 1
execute positioned ~1.25 ~ ~0.0 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.3863 ~ ~1.1888 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.0113 ~ ~0.7347 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.0113 ~ ~-0.7347 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.3863 ~ ~-1.1888 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
# Ring 2
execute positioned ~-0.0 ~ ~2.125 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.6614 ~ ~1.3249 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-2.0717 ~ ~-0.4729 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-0.922 ~ ~-1.9146 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.922 ~ ~-1.9146 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~2.0717 ~ ~-0.4729 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~1.6614 ~ ~1.3249 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
# Ring 3
execute positioned ~-3.0 ~ ~-0.0 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-2.5238 ~ ~-1.6219 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.2462 ~ ~-2.7289 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.4269 ~ ~-2.9695 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~1.9646 ~ ~-2.2672 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~2.8785 ~ ~-0.8452 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~2.8785 ~ ~0.8452 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~1.9646 ~ ~2.2672 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~0.4269 ~ ~2.9695 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-1.2462 ~ ~2.7289 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~
execute positioned ~-2.5238 ~ ~1.6219 unless block ~ ~-1 ~ minecraft:air run summon minecraft:evoker_fangs ~ ~ ~