execute at @s run summon minecraft:slime ~ ~ ~ {Size:4,Tags:["rnt.minion"],active_effects:[{id:"minecraft:resistance",amplifier:2,duration:-1,show_particles:false}]}
