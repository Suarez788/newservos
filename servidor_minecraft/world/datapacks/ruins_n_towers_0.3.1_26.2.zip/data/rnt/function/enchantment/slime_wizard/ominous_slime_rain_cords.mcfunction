execute positioned ~ ~ ~ run function rnt:enchantment/slime_wizard/summon_ominous_slime_rain
execute positioned ^ ^ ^2.5 run function rnt:enchantment/slime_wizard/summon_ominous_slime_rain
execute positioned ^ ^ ^1 run function rnt:enchantment/slime_wizard/summon_ominous_slime_rain
execute positioned ^ ^ ^-1 run function rnt:enchantment/slime_wizard/summon_ominous_slime_rain

particle minecraft:sneeze ~ ~ ~ 1 0.5 1 0.05 30
playsound minecraft:block.trial_spawner.about_to_spawn_item master @a[distance=..16] ~ ~ ~ 1 1.33 1
