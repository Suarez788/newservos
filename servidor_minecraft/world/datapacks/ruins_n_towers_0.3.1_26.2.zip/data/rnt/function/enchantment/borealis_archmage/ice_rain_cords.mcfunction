execute store result storage rnt:borealis x int 1 run random value -2..2
execute store result storage rnt:borealis y int 1 run random value 9..12
execute store result storage rnt:borealis z int 1 run random value -2..2
execute store result storage rnt:borealis fall int 1 run random value 80..110

execute at @r[distance=..10] align xyz positioned ~.5 ~ ~.5 run function rnt:enchantment/borealis_archmage/summon_ice_rain with storage rnt:borealis
