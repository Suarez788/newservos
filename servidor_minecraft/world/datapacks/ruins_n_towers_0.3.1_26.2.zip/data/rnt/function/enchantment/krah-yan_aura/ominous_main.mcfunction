# rnt.boss.stat   = Amount of minions
# rnt.dmg.cd      = Time till next attack
# rnt.ability.cd  = Unused

execute store result score @s rnt.mob.health run data get entity @s Health
execute store result bossbar rnt:krah-yan_shadow value run scoreboard players get @s rnt.mob.health
bossbar set rnt:krah-yan_shadow players @a[distance=..48]

execute at @s unless entity @n[type=player,distance=..16] run return fail

execute store result score @s rnt.boss.stat if entity @e[type=minecraft:husk,tag=rnt.minion,distance=..20]
scoreboard players add @s rnt.dmg.cd 1

execute if score @s[tag=!rnt.halfed] rnt.mob.health matches ..60 run function rnt:enchantment/krah-yan_aura/fase2
