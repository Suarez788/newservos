execute at @s as @a[distance=..16] positioned ~-8 ~-3 ~-8 as @s[dx=15,dy=11,dz=15] at @s run function rnt:enchantment/slime_wizard/slime_rain_cords
scoreboard players set @s rnt.ability.cd -720
