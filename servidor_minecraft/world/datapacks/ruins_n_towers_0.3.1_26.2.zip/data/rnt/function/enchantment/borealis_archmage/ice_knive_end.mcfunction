particle minecraft:explosion ~-0.5 ~-0.5 ~-0.5 1 1 1 1 5
playsound minecraft:entity.generic.explode hostile
execute positioned ~-0.5 ~-1.25 ~-0.5 as @a[dx=0,dy=2,dz=0] run damage @s 6 minecraft:freeze

kill
