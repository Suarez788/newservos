function rnt:enchantment/borealis_archmage/ice_rain_cords
function rnt:enchantment/borealis_archmage/ice_rain_cords
function rnt:enchantment/borealis_archmage/ice_rain_cords
function rnt:enchantment/borealis_archmage/ice_rain_cords
function rnt:enchantment/borealis_archmage/ice_rain_cords
function rnt:enchantment/borealis_archmage/ice_rain_cords
function rnt:enchantment/borealis_archmage/ice_rain_cords
function rnt:enchantment/borealis_archmage/ice_rain_cords
function rnt:enchantment/borealis_archmage/ice_rain_cords
scoreboard players add @s rnt.ability.cd 40
