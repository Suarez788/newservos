bossbar add rnt:krah-yan_shadow "Ominous Krah-Yan's Shadow"
bossbar set rnt:krah-yan_shadow color yellow
bossbar set rnt:krah-yan_shadow style notched_12
bossbar set rnt:krah-yan_shadow max 120
tag @s remove rnt.bossbar_pending
