tag @s remove rnt.minion
