# rnt.boss.stat   = Attack calc
# rnt.dmg.cd      = Dome
# rnt.ability.cd  = Time till next attack

execute store result score @s rnt.mob.health run data get entity @s Health
execute store result bossbar rnt:borealis_archmage value run scoreboard players get @s rnt.mob.health
bossbar set rnt:borealis_archmage players @a[distance=..48]

execute at @s unless entity @n[type=player,distance=..16] run return fail

scoreboard players add @s rnt.ability.cd 1

execute as @e[type=minecraft:item_display,tag=rnt.magic_projectile,distance=..16] at @s run function rnt:enchantment/borealis_archmage/ice_knive
execute as @e[type=minecraft:marker,tag=rnt.area,distance=..16] at @s run function rnt:enchantment/borealis_archmage/dome_tick
