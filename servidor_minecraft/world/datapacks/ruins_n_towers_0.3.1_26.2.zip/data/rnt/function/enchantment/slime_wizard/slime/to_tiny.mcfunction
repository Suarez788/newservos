execute store result score @s rnt.dmg.cd if entity @e[type=minecraft:slime,distance=..16]
execute if score @s rnt.dmg.cd matches 32.. run return run function rnt:enchantment/slime_wizard/slime/reset_groth
data modify entity @s Size set value 1
scoreboard players set @s rnt.ability.cd -200
execute if predicate rnt:chance/25 run function rnt:enchantment/slime_wizard/slime/ignore
effect give @s minecraft:instant_health 1 28
