$tp @s ^ ^ ^$(v)
particle minecraft:dust{color:[0.5,0.5,1],scale:2.2} ~-0.1 ~-0.1 ~-0.1 0.2 0.2 0.2 0.8 4
