# rnt.boss.stat   = Unused
# rnt.dmg.cd      = Unused
# rnt.ability.cd  = Slime Rain Cooldown
#
# bossbar is also used for setup commands

execute store result score @s rnt.mob.health run data get entity @s Health
execute store result bossbar rnt:slime_wizard value run scoreboard players get @s rnt.mob.health
bossbar set rnt:slime_wizard players @a[distance=..48]

execute at @s unless entity @n[type=player,distance=..16] run return fail

scoreboard players add @s rnt.ability.cd 2
execute if score @s rnt.mob.health matches ..70 run scoreboard players add @s rnt.ability.cd 1
execute if score @s rnt.mob.health matches ..40 run scoreboard players add @s rnt.ability.cd 1

execute at @s as @e[type=minecraft:slime,tag=rnt.minion,distance=..16] run function rnt:enchantment/slime_wizard/slime/main
execute at @s unless entity @n[type=minecraft:slime,tag=rnt.minion,distance=..16,scores={rnt.boss.stat=4..}] run function rnt:enchantment/slime_wizard/revive
