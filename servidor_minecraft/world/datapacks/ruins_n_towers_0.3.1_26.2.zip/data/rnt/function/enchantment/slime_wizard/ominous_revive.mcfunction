attribute @s minecraft:movement_speed base set 0.3
data modify entity @s equipment.mainhand.id set value "minecraft:bow"
