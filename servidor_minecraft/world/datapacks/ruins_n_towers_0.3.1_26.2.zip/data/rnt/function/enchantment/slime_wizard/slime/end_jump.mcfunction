summon minecraft:breeze_wind_charge ~1 ~ ~ {Motion:[0d,-1d,0d]}
summon minecraft:breeze_wind_charge ~-1 ~ ~ {Motion:[0d,-1d,0d]}
summon minecraft:breeze_wind_charge ~ ~ ~1 {Motion:[0d,-1d,0d]}
summon minecraft:breeze_wind_charge ~ ~ ~-1 {Motion:[0d,-1d,0d]}

execute at @s as @a[distance=..3] positioned ~-1.5 ~-1 ~-1.5 run damage @s[dx=2,dy=4,dz=2] 3 rnt:smash by @n[type=minecraft:skeleton,tag=rnt.boss,distance=..48]
execute at @s as @a[distance=..5] positioned ~-2.5 ~-1 ~-2.5 run damage @s[dx=4,dy=4,dz=4] 3 rnt:smash by @n[type=minecraft:skeleton,tag=rnt.boss,distance=..48]
execute at @s as @a[distance=..8] positioned ~-4 ~-1 ~-4 run damage @s[dx=7,dy=4,dz=7] 3 rnt:smash by @n[type=minecraft:skeleton,tag=rnt.boss,distance=..48]

tag @s remove rnt.b.jump
