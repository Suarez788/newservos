scoreboard players set @s rnt.ability.cd 0
execute if predicate rnt:chance/25 run function rnt:enchantment/slime_wizard/slime/ignore
