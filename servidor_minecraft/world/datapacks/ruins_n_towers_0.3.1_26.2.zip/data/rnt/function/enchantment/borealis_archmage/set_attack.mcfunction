# Attack randomizer
execute if predicate rnt:chance/33 run return run tag @s add rnt.b.ice_rain
execute if predicate rnt:chance/40 run return run tag @s add rnt.b.ice_knives
execute if predicate rnt:chance/66 run return run tag @s add rnt.b.dome
execute if predicate rnt:chance/66 run return run tag @s add rnt.b.fang_ring
tag @s add rnt.b.exfire
