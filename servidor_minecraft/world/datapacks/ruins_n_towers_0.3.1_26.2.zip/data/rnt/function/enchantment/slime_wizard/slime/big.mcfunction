tp @n[type=minecraft:skeleton,tag=rnt.boss,distance=..16] @s
execute as @s[tag=rnt.b.jump] unless block ~ ~-1 ~ air run return run function rnt:enchantment/slime_wizard/slime/end_jump
execute if predicate rnt:chance/0_25 run return run function rnt:enchantment/slime_wizard/slime/jump
execute as @s[tag=rnt.ominous] if predicate rnt:chance/0_25 run function rnt:enchantment/slime_wizard/slime/jump
