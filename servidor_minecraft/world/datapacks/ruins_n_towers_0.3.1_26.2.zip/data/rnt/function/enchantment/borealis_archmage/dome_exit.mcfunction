attribute @s minecraft:attack_speed modifier remove rnt:freezed 
attribute @s minecraft:jump_strength modifier remove rnt:freezed 
attribute @s minecraft:movement_speed modifier remove rnt:freezed 
tag @s remove rnt.under_effect
