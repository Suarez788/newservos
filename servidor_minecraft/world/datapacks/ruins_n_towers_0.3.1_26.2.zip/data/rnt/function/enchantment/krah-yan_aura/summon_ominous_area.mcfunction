summon minecraft:area_effect_cloud ~ ~ ~ {Radius:2.4,Duration:70,potion_contents:{potion:"minecraft:strong_harming"}}
scoreboard players set @s rnt.dmg.cd -80
