data modify entity @s Size set value 4
scoreboard players set @s rnt.ability.cd -200
effect give @s minecraft:instant_health 1 28
