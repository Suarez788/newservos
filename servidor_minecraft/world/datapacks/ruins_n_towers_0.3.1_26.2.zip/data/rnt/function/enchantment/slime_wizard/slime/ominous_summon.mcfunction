execute at @s run summon minecraft:slime ~ ~ ~ {Size:4,Tags:["rnt.minion","rnt.ominous"],active_effects:[{id:"minecraft:resistance",amplifier:3,duration:-1,show_particles:false}]}
