# rnt.boss.stat   = Size
# rnt.dmg.cd      = Amount
# rnt.ability.cd  = Size Increase Timer

execute store result score @s rnt.boss.stat run data get entity @s Size
scoreboard players add @s[tag=rnt.ominous] rnt.ability.cd 1
execute as @s[tag=rnt.ominous] if predicate rnt:chance/0_05 run tag @s remove rnt.ominous

# Mini < Tiny < Small < Medium < Big
execute if score @s rnt.boss.stat matches 4.. run return run function rnt:enchantment/slime_wizard/slime/big
scoreboard players add @s rnt.ability.cd 2
execute if score @s rnt.boss.stat matches ..0 run return run function rnt:enchantment/slime_wizard/slime/mini
execute if score @s rnt.boss.stat matches 1 run return run function rnt:enchantment/slime_wizard/slime/tiny
execute if score @s rnt.boss.stat matches 2 run return run function rnt:enchantment/slime_wizard/slime/small
execute if score @s rnt.boss.stat matches 3 run return run function rnt:enchantment/slime_wizard/slime/medium
