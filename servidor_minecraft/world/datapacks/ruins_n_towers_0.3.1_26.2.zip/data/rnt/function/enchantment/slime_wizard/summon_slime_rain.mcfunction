summon minecraft:falling_block ~ ~6 ~ {BlockState:{Name:"minecraft:slime_block"},DropItem:0b,CancelDrop:1b,HurtEntities:1b,FallHurtMax:40,fall_distance:10f,FallHurtAmount:1f}
