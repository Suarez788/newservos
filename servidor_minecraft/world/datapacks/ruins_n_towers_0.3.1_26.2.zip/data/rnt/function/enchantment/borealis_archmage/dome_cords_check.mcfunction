execute unless entity @a[distance=..12] run return fail
execute if block ~ ~ ~ minecraft:air run return run function rnt:enchantment/borealis_archmage/summon_dome
execute if block ~ ~ ~ minecraft:iron_bars unless block ~ ~-1 ~ minecraft:iron_bars run return run function rnt:enchantment/borealis_archmage/summon_dome
