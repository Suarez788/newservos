bossbar add rnt:slime_wizard "Ominous Slime Wizard"
bossbar set rnt:slime_wizard color green
bossbar set rnt:slime_wizard style notched_12
bossbar set rnt:slime_wizard max 120
tag @s remove rnt.bossbar_pending

function rnt:enchantment/slime_wizard/slime/ominous_summon
function rnt:enchantment/slime_wizard/sleep
