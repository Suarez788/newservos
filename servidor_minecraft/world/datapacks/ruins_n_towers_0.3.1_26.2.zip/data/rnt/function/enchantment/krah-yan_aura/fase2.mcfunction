attribute @s minecraft:movement_speed modifier remove rage
scoreboard players set @s rnt.dmg.cd 0
tag @s add rnt.halfed