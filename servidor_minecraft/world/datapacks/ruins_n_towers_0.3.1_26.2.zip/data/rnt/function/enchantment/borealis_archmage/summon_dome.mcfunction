summon minecraft:lightning_bolt ~ ~0.5 ~
summon minecraft:marker ~ ~ ~ {Tags:["rnt.b.left","rnt.area"]}
scoreboard players set @n[type=minecraft:marker,tag=rnt.area,distance=..3] rnt.dmg.cd 80
fill ~2 ~2 ~2 ~-2 ~-2 ~-2 minecraft:air replace #minecraft:fire
