bossbar set rnt:borealis_archmage players None
bossbar set rnt:krah-yan_shadow players None
bossbar set rnt:slime_wizard players None
