# Called by rnt:citem/wild_compass/main_hand

execute if predicate rnt:shifting run return run scoreboard players remove ?prev rnt.math1 1
scoreboard players add ?prev rnt.math1 1
