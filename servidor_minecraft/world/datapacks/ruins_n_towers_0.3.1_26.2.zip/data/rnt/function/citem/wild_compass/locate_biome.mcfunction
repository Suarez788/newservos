# Called by rnt:citem/wild_compass/pre_locate_biome

$execute store result score ?prev rnt.math1 run locate biome #rnt:wild_compass/$(biome)
