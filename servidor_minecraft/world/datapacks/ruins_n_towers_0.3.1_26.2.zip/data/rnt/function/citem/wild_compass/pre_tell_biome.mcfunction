# Called by rnt:citem/wild_compass/main_hand

$function rnt:citem/wild_compass/tell_biome with storage rnt:citem wild_compass.list[$(index)]
