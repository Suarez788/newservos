# Called by rnt:citem/wild_compass/use

$function rnt:citem/wild_compass/locate_biome with storage rnt:citem wild_compass.list[$(index)]
