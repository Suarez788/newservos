execute if predicate rnt:has_item/ice at @s positioned ~ ~1 ~ positioned ^ ^ ^1.5 run return run function rnt:citem/ice_staff/step

title @s times 1s 3s 1s
title @s actionbar {translate:"txt.wu.ice_staff_fail",fallback:"You need ice blocks to cast the spell",color:"red"}
