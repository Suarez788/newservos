# Called by rnt:citem/dropped

execute if data entity @s Item.components."minecraft:custom_data"{citem:"rnt:wild_compass"} run return run function rnt:citem/wild_compass/use
