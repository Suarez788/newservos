# Called by rnt:citem/wild_compass/longitud

execute if score ?d1 rnt.math1 < ?d3 rnt.math1 run return run data modify entity @s \
    Item.components."minecraft:custom_model_data".floats set value [1,-1,0]
execute if score ?d1 rnt.math1 > ?d3 rnt.math1 run return run data modify entity @s \
    Item.components."minecraft:custom_model_data".floats set value [1,1,0]
