# Called by rnt:citem/wild_compass/use

execute if score ?d1 rnt.math1 = ?d2 rnt.math1 run return run function rnt:citem/wild_compass/directions/greenwitch
execute if score ?d1 rnt.math1 < ?d2 rnt.math1 run return run function rnt:citem/wild_compass/directions/west
execute if score ?d1 rnt.math1 > ?d2 rnt.math1 run return run function rnt:citem/wild_compass/directions/east
