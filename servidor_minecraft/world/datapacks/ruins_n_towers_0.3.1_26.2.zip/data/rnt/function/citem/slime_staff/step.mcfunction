# Run if hit entity
# Fail if hit block or out of range

execute unless block ~ ~ ~ #rnt:unobstructed run return run function rnt:empty
execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @n[type=!#rnt:dont_trigger,dx=0] positioned ~0.5 ~0.5 ~0.5 run return run function rnt:citem/slime_staff/action

execute as @s[distance=..48] positioned ^ ^ ^1 run function rnt:citem/slime_staff/step
