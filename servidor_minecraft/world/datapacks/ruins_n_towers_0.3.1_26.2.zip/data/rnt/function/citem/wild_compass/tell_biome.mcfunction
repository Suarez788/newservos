# Called by rnt:citem/wild_compass/pre_tell_biome

title @s times 1s 5s 1s
$title @s actionbar [{translate:"txt.wu.wild_compass_selected_biome",fallback:"Selected Biome: ",color:"dark_green"},{translate:"$(translate)",fallback:"$(fallback)",color:"green"}]
