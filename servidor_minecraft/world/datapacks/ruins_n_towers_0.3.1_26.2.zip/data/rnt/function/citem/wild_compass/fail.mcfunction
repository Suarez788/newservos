# Called by rnt:citem/wild_compass/use

title @s times 1s 3s 1s
title @s actionbar {translate:"txt.wu.wild_compass_fail",fallback:"Insuficient Compass Charge",color:"red"}
