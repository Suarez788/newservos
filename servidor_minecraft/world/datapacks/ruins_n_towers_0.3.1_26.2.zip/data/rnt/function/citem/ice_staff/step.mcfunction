# Run if hit a block or entity
# Fail if out of range

execute unless block ~ ~ ~ #rnt:unobstructed run return run function rnt:citem/ice_staff/action
execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @n[type=!#rnt:dont_trigger,dx=0] positioned ~0.5 ~0.5 ~0.5 run return run function rnt:citem/ice_staff/action

execute as @s[distance=..48] positioned ^ ^ ^1 run function rnt:citem/ice_staff/step
