# Called by advancement

advancement revoke @s only rnt:citem/wild_compass

execute if score @s rnt.1tcd matches ..1 run return run function rnt:citem/wild_compass/still_on_cd
scoreboard players set @s rnt.1tcd 0

execute unless predicate rnt:wild_compass/offhand run return run function rnt:citem/wild_compass/main_hand
execute unless predicate rnt:wild_compass/holding_grass run return run function rnt:citem/wild_compass/show_charge

execute store result score ?amount rnt.math1 run data get entity @s SelectedItem.count
scoreboard players operation ?amount rnt.math1 *= ?100 rnt.math1
item modify entity @s weapon.mainhand rnt:reset_count
execute store result score ?prev rnt.math1 run data get entity @s equipment.offhand.components."minecraft:custom_data".charge
scoreboard players operation ?prev rnt.math1 += ?amount rnt.math1
execute store result storage rnt:citem wild_compass.charge int 1 run scoreboard players get ?prev rnt.math1
item modify entity @s weapon.offhand rnt:wild_compass_set_charge

function rnt:citem/wild_compass/show_charge
