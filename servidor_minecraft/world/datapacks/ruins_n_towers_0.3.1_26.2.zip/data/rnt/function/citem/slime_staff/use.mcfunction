advancement revoke @s only rnt:citem/slime_staff

execute unless score @s rnt.using_item matches 1.. run function rnt:citem/slime_staff/check

advancement revoke @s only rnt:cooldown/slime_staff
scoreboard players set @s rnt.using_item 2
