execute if predicate rnt:has_item/slime_ball at @s positioned ~ ~1 ~ positioned ^ ^ ^1.5 run return run function rnt:citem/slime_staff/step

title @s times 1s 3s 1s
title @s actionbar {translate:"txt.wu.slime_staff_fail",fallback:"You need slime balls to cast the spell",color:"red"}
