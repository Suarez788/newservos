# Called by rnt:citem/dropped_type

execute unless predicate rnt:in_overworld as @a[distance=..5] run return run function rnt:citem/wild_compass/not_in_overworld

execute store result storage rnt:citem wild_compass.index int 1 run data get entity @s Item.components."minecraft:custom_data".biome 1
function rnt:citem/wild_compass/set_biome with storage rnt:citem wild_compass 

function rnt:citem/wild_compass/pre_locate_biome with storage rnt:citem wild_compass
execute store result score ?amount rnt.math1 run data get entity @s Item.components."minecraft:custom_data".charge
execute if score ?prev rnt.math1 > ?amount rnt.math1 as @a[distance=..5] run return run function rnt:citem/wild_compass/fail
scoreboard players operation ?d1 rnt.math1 = ?prev rnt.math1
scoreboard players operation ?d1 rnt.math1 /= ?2 rnt.math1

execute positioned ~ ~ ~10 run function rnt:citem/wild_compass/pre_locate_biome with storage rnt:citem wild_compass
scoreboard players operation ?d2 rnt.math1 = ?prev rnt.math1
scoreboard players operation ?d2 rnt.math1 /= ?2 rnt.math1
execute positioned ~10 ~ ~ run function rnt:citem/wild_compass/pre_locate_biome with storage rnt:citem wild_compass
scoreboard players operation ?d3 rnt.math1 = ?prev rnt.math1
scoreboard players operation ?d3 rnt.math1 /= ?2 rnt.math1

function rnt:citem/wild_compass/directions/longitud

scoreboard players operation ?d1 rnt.math1 /= ?2 rnt.math1
scoreboard players operation ?amount rnt.math1 -= ?d1 rnt.math1
execute store result storage rnt:citem wild_compass.charge int 1 run scoreboard players get ?amount rnt.math1
item modify entity @s container.0 rnt:wild_compass_set_charge
