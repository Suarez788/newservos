advancement revoke @s only rnt:citem/ice_staff

execute unless score @s rnt.using_item matches 1.. run function rnt:citem/ice_staff/check

advancement revoke @s only rnt:cooldown/ice_staff
scoreboard players set @s rnt.using_item 2
