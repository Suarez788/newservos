# Called by rnt:citem/wild_compass/charge

execute store result score ?prev rnt.math1 run data get entity @s SelectedItem.components."minecraft:custom_data".biome
function rnt:citem/wild_compass/change_biome
scoreboard players operation ?prev rnt.math1 %= ?biome_len rnt.math1 
execute store result storage rnt:citem wild_compass.index int 1 run scoreboard players get ?prev rnt.math1
item modify entity @s weapon.mainhand rnt:wild_compass_set_biome

function rnt:citem/wild_compass/pre_tell_biome with storage rnt:citem wild_compass
