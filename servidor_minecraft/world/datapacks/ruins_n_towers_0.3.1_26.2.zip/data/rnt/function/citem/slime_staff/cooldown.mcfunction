scoreboard players remove @s rnt.using_item 1
execute if score @s rnt.using_item matches 1.. run return run advancement revoke @s only rnt:cooldown/slime_staff
scoreboard players reset @s rnt.using_item
