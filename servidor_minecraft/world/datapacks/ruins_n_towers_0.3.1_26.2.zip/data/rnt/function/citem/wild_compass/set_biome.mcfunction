# Called by rnt:citem/wild_compass/use

$data modify entity @s Item.components."minecraft:lore"[0][1] merge from storage rnt:citem wild_compass.list[$(index)]
