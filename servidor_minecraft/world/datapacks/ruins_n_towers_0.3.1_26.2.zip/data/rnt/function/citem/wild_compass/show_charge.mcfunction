#Called by rnt:citem/wild_compass/charge

tellraw @s [{translate:"txt.wu.charge", fallback:"Charge: ", color:"dark_green"}, {nbt:"equipment.offhand.components.'minecraft:custom_data'.charge", entity:"@s", plain:true, color:"green"}]
