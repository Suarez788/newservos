summon minecraft:slime ~ ~ ~ {Size:0,Tags:["rnt.a.suck"],DeathLootTable:"rnt:empty",Health:3,NoAI:1b,active_effects:[{id:"minecraft:wither",amplifier:0,duration:-1,show_particles:false}],attributes:[{"base":3,id:"minecraft:max_health"}]}
ride @n[type=minecraft:slime,tag=rnt.a.suck] mount @s
effect give @s minecraft:poison 6 1 false
