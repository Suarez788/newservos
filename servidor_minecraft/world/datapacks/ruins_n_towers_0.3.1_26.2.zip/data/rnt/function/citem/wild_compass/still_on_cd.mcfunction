# Called by rnt:citem/wild_compass/charge

scoreboard players set @s rnt.1tcd 0
