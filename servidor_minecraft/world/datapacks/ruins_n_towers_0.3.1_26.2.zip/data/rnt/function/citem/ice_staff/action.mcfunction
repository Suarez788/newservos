clear @s minecraft:ice 1

execute as @e[distance=..2.25] run data modify entity @s TicksFrozen set value 500
particle minecraft:snowflake ~ ~ ~ 2 1 2 0.1 160
