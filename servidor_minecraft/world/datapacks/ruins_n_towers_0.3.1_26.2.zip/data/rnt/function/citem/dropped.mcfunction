# Called by advancement

advancement revoke @s only rnt:check/inventory_changed

execute unless score @s rnt.drop_citem matches 1.. run return fail

scoreboard players reset @s rnt.drop_citem 
execute at @s anchored eyes positioned ^ ^ ^ as @e[type=minecraft:item,distance=..1] run function rnt:citem/dropped_type
