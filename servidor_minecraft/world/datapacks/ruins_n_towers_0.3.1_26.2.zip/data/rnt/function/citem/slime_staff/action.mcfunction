clear @s minecraft:slime_ball 1

execute as @e[distance=..2.5] at @s run function rnt:citem/slime_staff/aply
particle minecraft:sneeze ~ ~ ~ 3 1.5 3 0.2 100
