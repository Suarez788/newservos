function rnt:reset_bossbars

schedule function rnt:30s_loop 600t
