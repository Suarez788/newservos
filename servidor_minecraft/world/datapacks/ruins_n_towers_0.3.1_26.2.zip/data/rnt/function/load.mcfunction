scoreboard objectives add rnt.mob.health dummy
scoreboard objectives add rnt.dmg.cd minecraft.custom:minecraft.play_time
scoreboard objectives add rnt.ability.cd minecraft.custom:minecraft.play_time
scoreboard objectives add rnt.boss.stat dummy

scoreboard objectives add rnt.math1 dummy
scoreboard players set ?2 rnt.math1 2
scoreboard players set ?50 rnt.math1 50
scoreboard players set ?100 rnt.math1 100
scoreboard players set ?biome_len rnt.math1 21

scoreboard objectives add rnt.using_item dummy
scoreboard objectives add rnt.drop_citem minecraft.dropped:minecraft.poisonous_potato
scoreboard objectives add rnt.1tcd minecraft.custom:minecraft.play_time

data merge storage rnt:citem {wild_compass:{list:[ \
    {translate:"txt.wu.bg.plains",fallback:"Plains",biome:"plains"}, \
    {translate:"txt.wu.bg.forest",fallback:"Forest",biome:"savanna"}, \
    {translate:"txt.wu.bg.birch",fallback:"Birch Forest",biome:"birch"}, \
    {translate:"txt.wu.bg.taiga",fallback:"Taiga",biome:"taiga"}, \
    {translate:"txt.wu.bg.old_taiga",fallback:"Old Taiga",biome:"old_taiga"}, \
    {translate:"txt.wu.bg.dark",fallback:"Ruffed Forest",biome:"dark"}, \
    {translate:"txt.wu.bg.pale",fallback:"Pale Garden",biome:"pale"}, \ 
    {translate:"txt.wu.bg.savanna",fallback:"Savanna",biome:"savanna"}, \
    {translate:"txt.wu.bg.desert",fallback:"Desert",biome:"desert"}, \
    {translate:"txt.wu.bg.badlands",fallback:"Badlands",biome:"badlands"}, \
    {translate:"txt.wu.bg.jungle",fallback:"Jungle",biome:"jungle"}, \
    {translate:"txt.wu.bg.swamp",fallback:"Swamp",biome:"swamp"}, \
    {translate:"txt.wu.bg.mangrove",fallback:"Mangrove",biome:"mangrove"}, \
    {translate:"txt.wu.bg.dappled",fallback:"Dappled Forest",biome:"dappled"}, \
    {translate:"txt.wu.bg.ocean",fallback:"Ocean",biome:"ocean"}, \
    {translate:"txt.wu.bg.cold_ocean",fallback:"Cold Ocean",biome:"cold_ocean"}, \
    {translate:"txt.wu.bg.mushroom",fallback:"Mushroom Island",biome:"mushroom"}, \
    {translate:"txt.wu.bg.cherry",fallback:"Cherry Grove",biome:"cherry"}, \
    {translate:"txt.wu.bg.mountain",fallback:"Mountains",biome:"mountain"}, \
    {translate:"txt.wu.bg.mountain_snowy",fallback:"Snowy Mountains",biome:"mountain_snowy"}, \
    {translate:"txt.wu.bg.snowy",fallback:"Snowy Plains",biome:"snowy"}, \
    ]}}

function rnt:30s_loop
