execute at @s run kill @e[tag=rnt.b.left,distance=..160]

schedule function rnt:reset_bossbars 80t

advancement revoke @s only rnt:check/killed_boss
