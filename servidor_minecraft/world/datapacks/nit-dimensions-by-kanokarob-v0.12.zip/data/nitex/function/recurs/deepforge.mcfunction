###Smelts valid Hopper contents###
item modify block ~ ~ ~ container.0 nitex:deepforge_smelt
item modify block ~ ~ ~ container.1 nitex:deepforge_smelt
item modify block ~ ~ ~ container.2 nitex:deepforge_smelt
item modify block ~ ~ ~ container.3 nitex:deepforge_smelt
item modify block ~ ~ ~ container.4 nitex:deepforge_smelt

###Cosmetic###
setblock ~ ~ ~-4 minecraft:cauldron
particle minecraft:lava ~ ~ ~0.4 0.3 0.3 0.3 3 10 force
playsound minecraft:block.lava.extinguish block @a ~ ~ ~ 10