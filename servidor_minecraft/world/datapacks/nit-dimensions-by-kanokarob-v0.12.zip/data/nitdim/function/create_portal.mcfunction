###Cosmetics###
playsound minecraft:entity.player.levelup hostile @a[distance=..30] ~ ~ ~ 20
particle minecraft:poof ~ ~ ~ 7 7 7 0.2 2000 normal

###Build the portal###
place template nitdim:in_between/portals/standard ~-5 ~-1 ~-5
tag @e[tag=nitPortal,distance=..7] add nitLinkBetween

###Reset everything###
kill @s