scoreboard objectives add nitDimension dummy
scoreboard objectives add nitRandom dummy
scoreboard objectives add nitPiglinType dummy
scoreboard objectives add nitContract trigger

function nitdim:scheduler