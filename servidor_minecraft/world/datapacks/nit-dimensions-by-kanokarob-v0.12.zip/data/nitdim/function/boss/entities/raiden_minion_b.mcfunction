###Cosmetics###
particle minecraft:poof ~ ~ ~ 0.3 0.7 0.3 0.1 25 normal
playsound entity.zombie.converted_to_drowned hostile @a ~ ~ ~ 1 1

###Spawn###
summon minecraft:drowned ~ ~ ~ {CustomName:[{"translate":"nitsea.name.undead_experiment","fallback":"Undead Experiment"}],Health:17.0,PersistenceRequired:1b,Tags:[smithed.entity,smithed.strict,nitBossEntity],attributes:[{id:"minecraft:max_health",base:17.0F},{id:"minecraft:attack_damage",base:12.0}],DeathLootTable:"nitdim:empty",equipment:{"mainhand":{id:trident,count:1}},drop_chances:{"mainhand":0.0f}}
function nitdim:boss/attacks/reset