data modify entity @s Invulnerable set value 0b
playsound minecraft:block.conduit.activate hostile @a[distance=..20] ~ ~ ~ 3 1
summon splash_potion ~ ~ ~ {Item: {id: "minecraft:splash_potion", count: 1, components: {"potion_contents": "minecraft:regeneration"}}}
function nitdim:boss/attacks/reset