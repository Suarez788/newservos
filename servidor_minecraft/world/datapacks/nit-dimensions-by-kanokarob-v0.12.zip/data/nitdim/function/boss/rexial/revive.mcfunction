###Summons replacement zombie Rexial###
data modify entity @s Health set value 101
summon minecraft:zombie_villager ~ ~ ~ {VillagerData:{type:plains,profession:weaponsmith,level:5},CustomName:[{"translate":"nitex.name.rexial","fallback":"Rexial the Soulless"}],Health:101,Tags:[nitEntity,nitTicking,nitRexialBoss,nitRevived,smithed.entity,smithed.strict,nitBoss],equipment:{"mainhand":{id:netherite_axe,count:1}},drop_chances:{"mainhand":0.0f},attributes:[{id:"minecraft:attack_damage",base:9f},{id:"minecraft:movement_speed",base:0.35f},{id:"minecraft:max_health",base:200F}],DeathLootTable:"nitex:entities/rexial"}
scoreboard players operation @e[tag=nitRexialBoss,tag=nitRevived,limit=1,distance=..1] nitResourceSpawn = @s nitResourceSpawn

tp @s ~ -200 ~
kill @s