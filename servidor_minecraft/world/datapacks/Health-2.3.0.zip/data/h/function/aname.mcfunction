scoreboard objectives setdisplay below_name heart
playsound minecraft:ui.loom.take_result ambient @a
function h:panel
tellraw @p ["",{"text":"Note:","bold":true,"color":"gray"},{"text":" The nametag only appears in multiplayer.","color":"gray"}]