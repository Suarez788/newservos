scoreboard objectives setdisplay list
playsound minecraft:ui.loom.take_result ambient @a
function h:panel