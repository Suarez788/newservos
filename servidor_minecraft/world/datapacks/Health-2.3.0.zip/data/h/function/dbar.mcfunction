scoreboard objectives setdisplay sidebar
playsound minecraft:ui.loom.take_result ambient @a
function h:panel