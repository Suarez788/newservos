scoreboard objectives setdisplay sidebar heart
playsound minecraft:ui.loom.take_result ambient @a
function h:panel
tellraw @p ["",{"text":"Note:","bold":true,"color":"gray"},{"text":" The sidebar may take a while to show up the first time.","color":"gray"}]